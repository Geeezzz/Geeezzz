<?php
/*
Plugin Name: &spades; Tube Ace
Plugin URI: https://tubeace.com
Description: Build an adult video tube site with embedded video import tools from all the major adult video sites or any source with an import file.
Version: 2.7
Author: Tube Ace
Author URI: https://tubeace.com
*/

set_time_limit(0);

function tubeace_enqueue()  { 

  //rotating thumbs
  wp_enqueue_script(
    'thumbs-script', plugins_url() . '/tubeace/js/thumbs.js'
  );  

  wp_register_style('tubeace-style', plugins_url('tubeace-css.php', __FILE__) );
  wp_enqueue_style( 'tubeace-style');
}
add_action('wp_enqueue_scripts', 'tubeace_enqueue');

function tubeace_register_custom_menu_page() {

   add_options_page('My Options', 'Tube Ace', 'manage_options', 'tubeace/tubeace-settings.php');   
   add_menu_page('Mass Import Videos', 'Tube Ace', 'manage_options', 'tubeace/tubeace-import.php', '', 'dashicons-video-alt3');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Import', 'Mass Import Videos', 'manage_options', 'tubeace/tubeace-import.php');

   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Pornhub API Import', 'Pornhub API Import', 'manage_options', 'tubeace/tubeace-pornhub-api.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace RedTube Import', 'RedTube API Import', 'manage_options', 'tubeace/tubeace-redtube-api.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Tube8 API Import', 'Tube8 API Import', 'manage_options', 'tubeace/tubeace-tube8-api.php');  
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace YouPorn API Import', 'YouPorn API Import', 'manage_options', 'tubeace/tubeace-youporn-api.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace xHamster API Import', 'xHamster API Import', 'manage_options', 'tubeace/tubeace-xhamster-api.php');

   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace DrTuber Import', 'DrTuber Import', 'manage_options', 'tubeace/tubeace-drtuber.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Pornhub Import', 'Pornhub Import', 'manage_options', 'tubeace/tubeace-pornhub.php');

   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace PornTube Import', 'PornTube Import', 'manage_options', 'tubeace/tubeace-porntube.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace RedTube Import', 'RedTube Import', 'manage_options', 'tubeace/tubeace-redtube.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace SpankWire Import', 'SpankWire Import', 'manage_options', 'tubeace/tubeace-spankwire.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Sun Porno Import', 'Sun Porno Import', 'manage_options', 'tubeace/tubeace-sunporno.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Tube8 Import', 'Tube8 Import', 'manage_options', 'tubeace/tubeace-tube8.php');
 
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace xHamster Import', 'xHamster Import', 'manage_options', 'tubeace/tubeace-xhamster.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace XTube Import', 'XTube Import', 'manage_options', 'tubeace/tubeace-xtube.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace XVIDEOS Import', 'XVIDEOS Import', 'manage_options', 'tubeace/tubeace-xvideos.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace YouPorn Import', 'YouPorn Import', 'manage_options', 'tubeace/tubeace-youporn.php');

   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Settings', 'Settings', 'manage_options', 'tubeace/tubeace-settings.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Cron Jobs', 'Cron Jobs', 'manage_options', 'tubeace/tubeace-cron.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Remove Inactive Videos', 'Remove Inactive Videos', 'manage_options', 'tubeace/tubeace-remove-inactive.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Quality Control', 'Quality Control', 'manage_options', 'tubeace/tubeace-quality-control.php');
   add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Test Server', 'Test Server', 'manage_options', 'tubeace/tubeace-test-server.php');

   if( get_site_option('tubeace_pending_thumb_upgrade') == 1 ){
      add_submenu_page('tubeace/tubeace-import.php', 'Tube Ace Upgrade Thumbs', 'Upgrade Thumbs', 'manage_options', 'tubeace/tubeace-upgrade-thumbs.php');
   }
   
   // hide from menu
   add_submenu_page('null','Edit RedTube Cron Job', 'Tube Ace', 'manage_options', 'tubeace/tubeace-cron-redtube-edit.php');
   add_submenu_page('null','Edit Pornhub Cron Job', 'Tube Ace', 'manage_options', 'tubeace/tubeace-cron-pornhub-edit.php');
   add_submenu_page('null','Edit Tube8 Cron Job', 'Tube Ace', 'manage_options', 'tubeace/tubeace-cron-tube8-edit.php');
   add_submenu_page('null','Edit YouPorn Cron Job', 'Tube Ace', 'manage_options', 'tubeace/tubeace-cron-youporn-edit.php'); 
}
add_action('admin_menu', 'tubeace_register_custom_menu_page');

//delete thumbs of deleted post
function tubeace_delete_thumb( $postid ) {

  $upload_dir = wp_upload_dir();
  $subPath = tubeace_sub_dir_path($postid); 

  $saved_thmb = get_post_meta( $postid,'saved_thmb',true);

  for($i=1;$i<=$saved_thmb;$i++){

    $thumb = $upload_dir['basedir']."/tubeace-thumbs/".$subPath."/".$postid."_".$i.".jpg";

    if(file_exists($thumb)){
      unlink($thumb);
    }

  }
}
add_action( 'before_delete_post', 'tubeace_delete_thumb' );

//register performer taxonomy
function tubeace_performers_taxonomy() {

  $labels = array(
    'name' => _x( 'Performers', 'taxonomy general name' ),
    'singular_name' => _x( 'Performer', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Performers' ),
    'popular_items' => __( 'Popular Performers' ),
    'all_items' => __( 'All Performers' ),
    'parent_item' => null,
    'parent_item_colon' => null,
    'edit_item' => __( 'Edit Performers' ), 
    'update_item' => __( 'Update Performer' ),
    'add_new_item' => __( 'Add New Performer' ),
    'new_item_name' => __( 'New Performer Name' ),
    'separate_items_with_commas' => __( 'Separate Performers with commas' ),
    'add_or_remove_items' => __( 'Add or remove Performers' ),
    'choose_from_most_used' => __( 'Choose from the most used Performers' ),
    'menu_name' => __( 'Performers' ),
  ); 

  register_taxonomy('performer','post',array(
    'hierarchical' => false,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var' => true,
    'rewrite' => array( 'slug' => 'performer' ),
  ));
}
add_action( 'init', 'tubeace_performers_taxonomy', 0 );

//on activation
function tubeace_activate(){

    //add settings options
    $flowplayer7_code = '<script src="{plugin_url}/libs/fp7/flowplayer.min.js"></script>';
    $flowplayer7_code.= '<link rel="stylesheet" type="text/css" href="{plugin_url}/libs/fp7/skin/skin.css" />';
    $flowplayer7_code.= '<div class="flowplayer" data-poster="{thumb_url}"><video><source type="video/mp4" src="{video_file}"></video></div>';

    $videojs_code = '<link href="https://vjs.zencdn.net/5.8.8/video-js.css" rel="stylesheet">';
    $videojs_code.= '<video id="my-video" class="video-js vjs-4-3 vjs-big-play-centered" controls preload="auto" width="640" height="264" poster="{thumb_url}" data-setup="{}">';
    $videojs_code.= '<source src="{video_file}" type="video/mp4">';
    $videojs_code.= '</video><script src="https://vjs.zencdn.net/5.8.8/video.js"></script>';

    $video_player_wrapper_css = ".flex-video {\n\tposition: relative;\n\tpadding-top: 25px;\n\tpadding-bottom: 67.5%;\n\theight: 0;\n\toverflow: hidden;\n}\n\n";
    $video_player_wrapper_css.= ".flex-video iframe,.flex-video object,.flex-video embed {\n\tposition: absolute;\n\ttop: 0;\n\tleft: 0;\n\twidth: 100%;\n\theight: 100%;\n}\n\n";
    $video_player_wrapper_css.= "@media \nonly screen and (max-device-width: 800px), \nonly screen and (device-width: 1024px) and (device-height: 600px), \nonly screen and (width: 1280px) and (orientation: landscape), \nonly screen and (device-width: 800px), \nonly screen and (max-width: 767px) {\n.flex-video { \npadding-top: 0; \n}}";

    $redtube_code = '<iframe src="https://embed.redtube.com/?id={video_id}&bgcolor=000000" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $drtuber_code = '<iframe src="https://www.drtuber.com/embed/{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';
            
    $keezmovies_code = '<iframe src="https://www.keezmovies.com/embed/{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $porntube_code = '<iframe src="https://www.porntube.com/embed/{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $pornhub_code = '<iframe src="https://www.pornhub.com/embed/{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $spankwire_code = '<iframe src="https://www.spankwire.com/EmbedPlayer.aspx?ArticleId={video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $sunporno_code = '<iframe src="https://embeds.sunporno.com/embed/{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $tube8_code = '<iframe src="https://www.tube8.com/embed/category/title/{video_id}/" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $youporn_code = '<iframe src="https://www.youporn.com/embed/{video_id}/" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $xhamster_code = '<iframe src="https://xhamster.com/xembed.php?video={video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $xtube_code = '<iframe src="https://www.xtube.com/video-watch/embedded/-{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    $xvideos_code = '<iframe src="https://flashservice.xvideos.com/embedframe/{video_id}" frameborder="0" scrolling="no" allowfullscreen></iframe>';

    add_site_option('tubeace_pornhub_api_thumb_size', 'large');
    add_site_option('tubeace_pornhub_api_def_thumb_only', 0);
    add_site_option('tubeace_pornhub_api_use_def_thumb', 1);    
    add_site_option('tubeace_pornhub_api_num_thumbs', 16);
    add_site_option('tubeace_pornhub_api_def_thumb', 15);
    add_site_option('tubeace_pornhub_api_save_thumbs', 0);

    add_site_option('tubeace_redtube_api_thumb_size', 'medium2');
    add_site_option('tubeace_redtube_api_def_thumb_only', 0);
    add_site_option('tubeace_redtube_api_use_def_thumb', 1);
    add_site_option('tubeace_redtube_api_num_thumbs', 16);
    add_site_option('tubeace_redtube_api_def_thumb', 15);
    add_site_option('tubeace_redtube_api_save_thumbs', 0);

    add_site_option('tubeace_tube8_api_thumb_size', 'big');
    add_site_option('tubeace_tube8_api_def_thumb_only', 0);
    add_site_option('tubeace_tube8_api_use_def_thumb', 1);    
    add_site_option('tubeace_tube8_api_num_thumbs', 16);
    add_site_option('tubeace_tube8_api_def_thumb', 15);
    add_site_option('tubeace_tube8_api_save_thumbs', 0);

    add_site_option('tubeace_youporn_api_thumb_size', 'medium2');
    add_site_option('tubeace_youporn_api_def_thumb_only', 0);
    add_site_option('tubeace_youporn_api_use_def_thumb', 1);
    add_site_option('tubeace_youporn_api_num_thumbs', 16);
    add_site_option('tubeace_youporn_api_def_thumb', 15);
    add_site_option('tubeace_youporn_api_save_thumbs', 0);

    add_site_option('tubeace_xhamster_api_thumb_size', 4);
    add_site_option('tubeace_xhamster_api_def_thumb_only', 0);
    add_site_option('tubeace_xhamster_api_use_def_thumb', 1);    
    add_site_option('tubeace_xhamster_api_num_thumbs', 10);
    add_site_option('tubeace_xhamster_api_def_thumb', 9);
    add_site_option('tubeace_xhamster_api_save_thumbs', 0);

    add_site_option('tubeace_drtuber_dump_num_thumbs', 16);
    add_site_option('tubeace_drtuber_dump_def_thumb', 15);

    add_site_option('tubeace_keezmovies_dump_num_thumbs', 16);
    add_site_option('tubeace_keezmovies_dump_def_thumb', 15);

    add_site_option('tubeace_pornhub_dump_num_thumbs', 16);
    add_site_option('tubeace_pornhub_dump_def_thumb', 15);

    add_site_option('tubeace_porntube_dump_num_thumbs', 10);
    add_site_option('tubeace_porntube_dump_def_thumb', 9);

    add_site_option('tubeace_redtube_dump_num_thumbs', 16);
    add_site_option('tubeace_redtube_dump_def_thumb', 15);

    add_site_option('tubeace_spankwire_dump_num_thumbs', 10);
    add_site_option('tubeace_spankwire_dump_def_thumb', 9);

    add_site_option('tubeace_sunporno_dump_num_thumbs', 1);
    add_site_option('tubeace_sunporno_dump_def_thumb', 1);

    add_site_option('tubeace_tube8_dump_num_thumbs', 16);
    add_site_option('tubeace_tube8_dump_def_thumb', 15);

    add_site_option('tubeace_xhamster_dump_num_thumbs', 10);
    add_site_option('tubeace_xhamster_dump_def_thumb', 1);

    add_site_option('tubeace_xtube_dump_num_thumbs', 15);
    add_site_option('tubeace_xtube_dump_def_thumb', 12);

    add_site_option('tubeace_xvideos_dump_num_thumbs', 1);
    add_site_option('tubeace_xvideos_dump_def_thumb', 1);

    add_site_option('tubeace_youporn_dump_num_thumbs', 16);
    add_site_option('tubeace_youporn_dump_def_thumb', 15);

    add_site_option('tubeace_flowplayer7_code', $flowplayer7_code);
    add_site_option('tubeace_videojs_code', $videojs_code);
    add_site_option('tubeace_filter_video_position', 'above');
    add_site_option('tubeace_default_video_player', 'flowplayer7');
    add_site_option('tubeace_video_player_wrapper_css', $video_player_wrapper_css);
    add_site_option('tubeace_redtube_video_player_code', $redtube_code);
    add_site_option('tubeace_drtuber_video_player_code', $drtuber_code);
    add_site_option('tubeace_keezmovies_video_player_code', $keezmovies_code);
    add_site_option('tubeace_porntube_video_player_code', $porntube_code);
    add_site_option('tubeace_pornhub_video_player_code', $pornhub_code);
    add_site_option('tubeace_spankwire_video_player_code', $spankwire_code);
    add_site_option('tubeace_sunporno_video_player_code', $sunporno_code);
    add_site_option('tubeace_tube8_video_player_code', $tube8_code);
    add_site_option('tubeace_youporn_video_player_code', $youporn_code);
    add_site_option('tubeace_xhamster_video_player_code', $xhamster_code);
    add_site_option('tubeace_xtube_video_player_code', $xtube_code);
    add_site_option('tubeace_xvideos_video_player_code', $xvideos_code); 
    add_site_option('tubeace_thumb_width', '320');
    add_site_option('tubeace_thumb_height', '240');
    add_site_option('tubeace_schedule_per_day', '0');
    add_site_option('tubeace_split_description_characters', '300');
    add_site_option('tubeace_cron_set_last_page_as_start', 1);
    add_site_option('tubeace_cron_email', get_option('admin_email'));
    add_site_option('tubeace_cron_last_id', 0);
    add_site_option('tubeace_alternate_video_url', '');

    add_site_option('tubeace_version', '2.7');

    // create pages
    $pagesArr = array('Tube' => 'tube', 'Newest' => 'newest', 'Most Viewed' => 'most-viewed', 'Highest Rated' => 'highest-rated', 'Categories' => 'categories', 'Porn Star List' => 'porn-star-list');

    foreach($pagesArr as $key => $value){

      // prevent duplicates
      if( get_page_by_title( $key ) == NULL ){

        if( $value == 'tube' ){
          $content = '<h2><a href="'.get_home_url().'/newest">Newest</a></h2>[tubeace_newest results="12" pagination="true" slug="newest"]';
          $content.= '<h2><a href="'.get_home_url().'/most-viewed">Most Viewed</a></h2>[tubeace_most_viewed results="12" pagination="true" slug="most-viewed"]';
          $content.= '<h2><a href="'.get_home_url().'/highest-rated">Highest Rated</a></h2>[tubeace_highest_rated results="12" pagination="true" slug="highest-rated"]';
        }

        if( $value == 'newest' ){
          $content = '[tubeace_newest results="12" pagination="true"]';
        }

        if( $value == 'most-viewed' ){
          $content = '[tubeace_most_viewed results="12" pagination="true"]';
        }

        if( $value == 'highest-rated' ){
          $content = '[tubeace_highest_rated results="12" pagination="true"]';
        }           

        if( $value == 'porn-star-list' ){
          $content = '[tubeace_porn_star_list]';
        }    

        if( $value == 'categories' ){
          $content = '[tubeace_categories]';
        }    

        $my_post = array(
          'post_type'     => 'page',
          'post_title'    => $key,
          'post_name'     => $value,
          'post_content'  => $content,
          'post_status'   => 'publish',
          'post_author'   => 1,
        );

        // Insert the post into the database
        wp_insert_post( $my_post );  
      }
    }  
}
register_activation_hook( __FILE__, 'tubeace_activate' );

// on deactivation
function tubeace_deactivate(){

    // delete settings options

    delete_site_option('tubeace_redtube_api_num_thumbs');
    delete_site_option('tubeace_redtube_api_def_thumb');
    delete_site_option('tubeace_redtube_api_thumb_size');

    delete_site_option('tubeace_pornhub_api_num_thumbs');
    delete_site_option('tubeace_pornhub_api_def_thumb');
    delete_site_option('tubeace_pornhub_api_thumb_size');

    delete_site_option('tubeace_tube8_api_num_thumbs');
    delete_site_option('tubeace_tube8_api_def_thumb');
    delete_site_option('tubeace_tube8_api_thumb_size');

    delete_site_option('tubeace_xhamster_api_num_thumbs');
    delete_site_option('tubeace_xhamster_api_def_thumb');
    delete_site_option('tubeace_xhamster_api_thumb_size');

    delete_site_option('tubeace_youporn_api_num_thumbs');
    delete_site_option('tubeace_youporn_api_def_thumb');
    delete_site_option('tubeace_youporn_api_thumb_size');    

    delete_site_option('tubeace_drtuber_dump_num_thumbs');
    delete_site_option('tubeace_drtuber_dump_def_thumb');

    delete_site_option('tubeace_keezmovies_dump_num_thumbs');
    delete_site_option('tubeace_keezmovies_dump_def_thumb');

    delete_site_option('tubeace_pornhub_dump_num_thumbs');
    delete_site_option('tubeace_pornhub_dump_def_thumb');

    delete_site_option('tubeace_porntube_dump_num_thumbs');
    delete_site_option('tubeace_porntube_dump_def_thumb');

    delete_site_option('tubeace_redtube_dump_num_thumbs');
    delete_site_option('tubeace_redtube_dump_def_thumb');

    delete_site_option('tubeace_spankwire_dump_num_thumbs');
    delete_site_option('tubeace_spankwire_dump_def_thumb');

    delete_site_option('tubeace_sunporno_dump_num_thumbs');
    delete_site_option('tubeace_sunporno_dump_def_thumb');

    delete_site_option('tubeace_tube8_dump_num_thumbs');
    delete_site_option('tubeace_tube8_dump_def_thumb');

    delete_site_option('tubeace_xhamster_dump_num_thumbs');
    delete_site_option('tubeace_xhamster_dump_def_thumb');

    delete_site_option('tubeace_xtube_dump_num_thumbs');
    delete_site_option('tubeace_xtube_dump_def_thumb');

    delete_site_option('tubeace_xvideos_dump_num_thumbs');
    delete_site_option('tubeace_xvideos_dump_def_thumb');

    delete_site_option('tubeace_youporn_dump_num_thumbs');
    delete_site_option('tubeace_youporn_dump_def_thumb');

    delete_site_option('tubeace_mass_import_save_thumbs');
    delete_site_option('tubeace_import_as_video_post_format');
    delete_site_option('tubeace_ajax_import');
    delete_site_option('tubeace_words_filter');

    delete_site_option('tubeace_flowplayer7_code');
    delete_site_option('tubeace_videojs_code');

    delete_site_option('tubeace_filter_video_position');
    delete_site_option('tubeace_default_video_player');
    delete_site_option('tubeace_video_player_wrapper_css');
    delete_site_option('tubeace_redtube_video_player_code');
    delete_site_option('tubeace_drtuber_video_player_code');
    delete_site_option('tubeace_keezmovies_video_player_code');
    delete_site_option('tubeace_porntube_video_player_code');
    delete_site_option('tubeace_pornhub_video_player_code');
    delete_site_option('tubeace_spankwire_video_player_code');
    delete_site_option('tubeace_sunporno_video_player_code');
    delete_site_option('tubeace_tube8_video_player_code');
    delete_site_option('tubeace_youporn_video_player_code');
    delete_site_option('tubeace_xhamster_video_player_code');
    delete_site_option('tubeace_xtube_video_player_code');
    delete_site_option('tubeace_xvideos_video_player_code');    
    delete_site_option('tubeace_thumb_width');
    delete_site_option('tubeace_thumb_height');
    delete_site_option('tubeace_schedule_per_day');
    delete_site_option('tubeace_split_description_characters');
    delete_site_option('tubeace_cron_email');
    delete_site_option('tubeace_cron_last_id');
    delete_site_option('tubeace_alternate_video_url');
    delete_site_option('tubeace_version');
}
register_deactivation_hook( __FILE__, 'tubeace_deactivate' );

// upgrade
function tubeace_upgrade(){

    $version = get_site_option('tubeace_version');
    if(!empty($version)){

        if (version_compare($version, '1.2', '<')){

            $porntube_code = "<iframe width=\"868\" height=\"688\" type=\"text/html\" src=\"http://embed.porntube.com/{video_id}\" frameborder=\"0\" allowFullScreen id=\"f1289832\" class=\"porntube-player\"></iframe>";
            
            //set porntube video player code
            add_site_option('tubeace_porntube_video_player_code', $porntube_code);

            //update version
            update_site_option('tubeace_version', '1.2');
        }

        if (version_compare($version, '1.3', '<')){

            $pornhub_code = "<iframe src=\"http://www.pornhub.com/embed/{video_id}\" frameborder=\"0\" height=\"688\" width=\"868\" scrolling=\"no\" name=\"ph_embed_video\"></iframe>";

            $xhamster_code = "<iframe width=\"868\" height=\"688\" src=\"http://xhamster.com/xembed.php?video={video_id}\" frameborder=\"0\" scrolling=\"no\"></iframe>";

            //set porntube video player code
            add_site_option('tubeace_pornhub_video_player_code', $pornhub_code);
            add_site_option('tubeace_xhamster_video_player_code', $xhamster_code);

            //update version
            update_site_option('tubeace_version', '1.3');
        }

        if (version_compare($version, '1.4', '<')){

            //create pages
            $pagesArr = array('Newest' => 'newest', 'Most Viewed' => 'most-viewed', 'Highest Rated' => 'highest-rated', 'Categories' => 'categories', 'Porn Star List' => 'porn-star-list');

            foreach($pagesArr as $key => $value){

                $my_post = array(
                  'post_type'     => 'page',
                  'post_title'    => $key,
                  'post_name'     => $value,
                  'post_status'   => 'publish',
                  'post_author'   => 1,
                );

                // Insert the post into the database
                wp_insert_post( $my_post );  
            }         
    
            //update version
            update_site_option('tubeace_version', '1.4');
        }

        if (version_compare($version, '1.5', '<')){

            $keezmovies_code = "<iframe name=\"keezmovies_embed_video\" src=\"http://www.keezmovies.com/embed/-{video_id}\" frameborder=\"0\" width=\"868\" height=\"688\" scrolling=\"no\"></iframe>";

            $spankwire_code = "<iframe src=\"http://www.spankwire.com/EmbedPlayer.aspx?ArticleId={video_id}\" frameborder=\"0\" height=\"688\" width=\"868\" scrolling=\"no\" name=\"spankwire_embed_video\"></iframe>";

            $tube8_code = "<iframe src=\"http://www.tube8.com/embed/category/title/{video_id}/\" frameborder=0 height=\"688\" width=\"868\" scrolling=no name=\"t8_embed_video\"></iframe>";

            $youporn_code = "<iframe src=\"http://www.youporn.com/embed/{video_id}/\" frameborder=\"0\" height=\"868\" width=\"868\" scrolling=\"no\" name=\"yp_embed_video\"></iframe>";

            //set video player codes
            add_site_option('tubeace_keezmovies_video_player_code', $keezmovies_code);
            add_site_option('tubeace_spankwire_video_player_code', $spankwire_code);
            add_site_option('tubeace_tube8_video_player_code', $tube8_code);
            add_site_option('tubeace_youporn_video_player_code', $youporn_code);

            //update version
            update_site_option('tubeace_version', '1.5');
        }

        if (version_compare($version, '1.6', '<')){

            $bangyoulater_code = "<iframe src=\"http://www.bangyoulater.com/embed.php?id={video_id}\" frameborder=\"0\" height=\"688\" width=\"868\" scrolling=\"no\" name=\"byl_embed_video\"></iframe>";

            $sunporno_code = "<iframe src=\"http://embeds.sunporno.com/embed/{video_id}\" frameborder=\"0\" width=\"868\" height=\"688\" scrolling=\"no\"></iframe>";

            //set video player codes
            add_site_option('tubeace_bangyoulater_video_player_code', $bangyoulater_code);
            add_site_option('tubeace_sunporno_video_player_code', $sunporno_code);
    
            //update version
            update_site_option('tubeace_version', '1.6');
        }

        if (version_compare($version, '1.7', '<')){

            $keezmovies_code = "<iframe name=\"keezmovies_embed_video\" src=\"http://www.keezmovies.com/embed/{video_id}\" frameborder=\"0\" width=\"868\" height=\"688\" scrolling=\"no\"></iframe>";

            //update keezmovies video player code
            update_site_option('tubeace_keezmovies_video_player_code', $keezmovies_code);

            //new video player codes
            $drtuber_code = "<iframe src=\"http://www.drtuber.com/embed/{video_id}\" frameborder=\"0\" width=\"868\" height=\"688\" scrolling=\"no\"></iframe>";
            $xvideos_code = "<iframe src=\"http://flashservice.xvideos.com/embedframe/{video_id}\" frameborder=\"0\" width=\"868\" height=\"688\" scrolling=\"no\"></iframe>";

            //set video player codes
            add_site_option('tubeace_drtuber_video_player_code', $drtuber_code);
            add_site_option('tubeace_xvideos_video_player_code', $xvideos_code);

            //update version
            update_site_option('tubeace_version', '1.7');
        }  

        if (version_compare($version, '1.8', '<')){
            //update version

            add_site_option('tubeace_alternate_video_url', '');

            update_site_option('tubeace_version', '1.8');
        }  

        if (version_compare($version, '2.0', '<')){

            delete_site_option('tubeace_bangyoulater_video_player_code');
            delete_site_option('tubeace_flowplayer3_code');
            delete_site_option('tubeace_flowplayer5_code');
            delete_site_option('tubeace_ffmpeg_path');
            delete_site_option('tubeace_frames_option');
            delete_site_option('tubeace_frames_value');
            delete_site_option('tubeace_def_thmb');

            update_site_option('tubeace_default_video_player', 'flowplayer7');

            // to show Thumb Upgrade page in WP admin menu until all posts finished copying featured image
            add_site_option('tubeace_pending_thumb_upgrade', 1);

            //update version
            update_site_option('tubeace_version', '2.0');
        }  

        if (version_compare($version, '2.0.1', '<')){
            //update version

            add_site_option('tubeace_import_as_video_post_format', '');

            update_site_option('tubeace_version', '2.0.1');
        }

        if (version_compare($version, '2.0.4', '<')){
            //update version

            add_site_option('tubeace_cron_last_id', '0');

            // if existing cron jobs, assign ids
            $sites = array('redtube','pornhub','tube8','youporn');

            foreach($sites as $site){

                $frequencies = array('hourly','twicedaily','daily');

                foreach($frequencies as $frequency){

                    //get options array
                    $existingCronNames = get_site_option('tubeace_cron_'.$site.'_'.$frequency);

                    if( is_array($existingCronNames) ){

                        foreach($existingCronNames as $name){

                            $existing_cron_jobs = 1; // to create tubeace_detect_stalled_cron

                            $option_values = get_site_option('tubeace_cron_'.$site.'_'.$name.'_'.$frequency);
                            $cronValues = $option_values;

                            // increment
                            $tubeace_cron_last_id = get_site_option('tubeace_cron_last_id');
                            $tubeace_cron_last_id++;

                            $cronValues['cron_id'] = $tubeace_cron_last_id;

                            update_site_option('tubeace_cron_'.$site.'_'.$name.'_'.$frequency, $cronValues);
                            update_site_option('tubeace_cron_last_id', $tubeace_cron_last_id);
                        }

                        if( $existing_cron_jobs == 1 ){

                            // create event
                            if ( ! wp_next_scheduled( 'tubeace_detect_stalled_cron' ) ) {
                              wp_schedule_event( time(), 'hourly', 'tubeace_detect_stalled_cron' );
                            }
                        }
                    }
                }
            }

            update_site_option('tubeace_version', '2.0.4');
        }   


        if (version_compare($version, '2.1', '<')){
            //update version

            add_site_option('tubeace_cron_set_last_page_as_start', 1);

            update_site_option('tubeace_version', '2.1');
        }

        if (version_compare($version, '2.1.1', '<')){
            //update version

            add_site_option('tubeace_xhamster_api_num_thumbs', 10);
            add_site_option('tubeace_xhamster_api_def_thumb', 9);
            add_site_option('tubeace_xhamster_api_thumb_size', 4);

            update_site_option('tubeace_version', '2.1.1');
        }

        if (version_compare($version, '2.1.2', '<')){
            //update version
            update_site_option('tubeace_version', '2.1.2');
        }

        if (version_compare($version, '2.2', '<')){

            // add 'tube' page
            $content = '<h2><a href="'.get_home_url().'/newest">Newest</a></h2>[tubeace_newest results="24"]';
            $content.= '<h2><a href="'.get_home_url().'/most-viewed">Most Viewed</a></h2>[tubeace_most_viewed results="24"]';
            $content.= '<h2><a href="'.get_home_url().'/highest-rated">Highest Rated</a></h2>[tubeace_highest_rated results="24"]';

            $my_post = array(
              'post_type'     => 'page',
              'post_title'    => 'Tube',
              'post_name'     => 'tube',
              'post_content'  => $content,
              'post_status'   => 'publish',
              'post_author'   => 1,
            );

            // Insert the post into the database
            wp_insert_post( $my_post );

            // insert short codes into newest, most viewed, highest rated, porn star list, pages which already exist
            $pagesArr = array('newest', 'most-viewed', 'highest-rated', 'categories', 'porn-star-list');

            foreach($pagesArr as $value){

              // get post id of existing pages
              $args = [
                  'post_type'      => 'page',
                  'posts_per_page' => 1,
                  'post_name__in'  => [''.$value.'']
              ];
              $q = get_posts( $args );

              if( $value == 'newest' ){
                $content = '[tubeace_newest results="24"]';
              }

              if( $value == 'most-viewed' ){
                $content = '[tubeace_most_viewed results="24"]';
              }

              if( $value == 'highest-rated' ){
                $content = '[tubeace_highest_rated results="24"]';
              }           

              if( $value == 'porn-star-list' ){
                $content = '[tubeace_porn_star_list]';
              }    

              if( $value == 'categories' ){
                $content = '[tubeace_categories]';
              }

              $edited_post = array(
                    'ID'           => $q[0]->ID,
                    'post_content' => $content
                );
                wp_update_post( $edited_post);
            }
            
            //update version
            update_site_option('tubeace_version', '2.2');
        }    

        if (version_compare($version, '2.6.4', '<')){
            //update version
            update_site_option('tubeace_version', '2.6.4');
        }         

        if (version_compare($version, '2.6.5', '<')){

            // change 'by_url' to '6969TA'
            // loop through posts _thumbnail_id
            $args = array(
                'posts_per_page'   => -1,
                'post_type'        => 'post',
            );
            $the_query = new WP_Query( $args );

            while ( $the_query->have_posts() ) {
              $the_query->the_post();

              update_post_meta( get_the_ID(), '_thumbnail_id', '6969TA', 'by_url' );

            }
            //update version
            update_site_option('tubeace_version', '2.6.5');
        }      

        if (version_compare($version, '2.6.6', '<')){
            //update version
            update_site_option('tubeace_filter_video_position', 'above');
        }  

        if (version_compare($version, '2.7', '<')){

            update_site_option('tubeace_split_description_characters', '300');

            update_site_option('tubeace_version', '2.7');
        }          
    }
}
add_action('init', 'tubeace_upgrade');

//alternate video url
function tubeace_alt_url_redirect( $url, $post, $leavename ) {
 
  // alternate video URL
  $tubeace_alternate_video_url = get_site_option( 'tubeace_alternate_video_url' );

  if( $tubeace_alternate_video_url != false){

    $url = str_replace('{video_page_url}',$url, $tubeace_alternate_video_url); 
  }

  // link to original source URL
  $tubeace_link_thumb_to_source = get_site_option( 'tubeace_link_thumb_to_source' );

  if( $tubeace_link_thumb_to_source != false ){

    // check for url in post meta
    $check = get_post_meta( $post->ID,'url',true);

    if( !empty($check) ){
      $url = $check;
    }
  }

  return $url;
}
add_filter( 'post_link', 'tubeace_alt_url_redirect', 10, 3 );

function tubeace_header(){

  echo'<a href="https://www.tubeace.com" target="_blank"><img id="tubeace-logo" src="'.plugins_url('/tubeace/images/logo.png').'" alt="Tube Ace"></a>';
}

//autoscheduling for mass importing
function tubeace_auto_sched_next_date($i){

  global $wpdb;

  $currentDay = date("d");
  $currentMonth = date("m");
  $currentYear = date("Y");
  
  $checkDate = date("Y-m-d",mktime(0, 0, 0, $currentMonth, $currentDay+$i, $currentYear));

  $num = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = 'post' AND post_date_gmt BETWEEN '$checkDate 00:00:00' AND '$checkDate 23:59:59'" );

  //if less results exist that to sched per day
  if(get_site_option('tubeace_schedule_per_day') > $num){
    return $checkDate;
  } else {
    $i++;
    return tubeace_auto_sched_next_date($i);     
  } 
}

function tubeace_sub_dir_path($id){

  if($id<10){
    $subPath = 0;
  } else {
    $subPath = substr($id, -2);
  }   
  return $subPath;
}

//import js and css + admin settings page
function tubeace_admin_enqueue($hook) {

    // in javascript, object properties are accessed as ajax_object.ajax_url, ajax_object.we_value
    wp_localize_script( 'tubeace', 'ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

    // css
    wp_register_style( 'prefix-style', plugins_url('tubeace.css', __FILE__) );
    wp_enqueue_style( 'prefix-style' );

    // setting spage
    if ( $hook == 'tubeace/tubeace-settings.php' ) {
      wp_enqueue_script(  'tubeace-admin-settings', plugins_url() . '/tubeace/js/admin-settings.js' );
    }
}
add_action( 'admin_enqueue_scripts', 'tubeace_admin_enqueue' );

function tubeace_get_users_with_role( $roles, $current_selected ) {

  global $wpdb;
  if ( ! is_array( $roles ) )
      $roles = array_walk( explode( ",", $roles ), 'trim' );
  $sql = '
      SELECT  ID, display_name
      FROM        ' . $wpdb->users . ' INNER JOIN ' . $wpdb->usermeta . '
      ON          ' . $wpdb->users . '.ID             =       ' . $wpdb->usermeta . '.user_id
      WHERE       ' . $wpdb->usermeta . '.meta_key        =       \'' . $wpdb->prefix . 'capabilities\'
      AND     (
  ';
  $i = 1;
  foreach ( $roles as $role ) {
      $sql .= ' ' . $wpdb->usermeta . '.meta_value    LIKE    \'%"' . $role . '"%\' ';
      if ( $i < count( $roles ) ) $sql .= ' OR ';
      $i++;
  }
  $sql .= ' ) ';
  $sql .= ' ORDER BY display_name ';

  $results = $wpdb->get_results( $sql);
  foreach ($results as $result){

      unset($selected);

      if($result->ID == $current_selected){
        $selected = "selected =\"selected\"";
      }

      echo "<option value=\"$result->ID\" $selected>$result->display_name</option>\n";
    }
}

$theme_slug =  get_option('stylesheet');

require_once 'inc/customizer/customizer-defaults.php';

// if active theme is not tubeaceplay, only show customizer options in plugin panel
// if active theme is tubeaceplay, only show customizer options in themes panel
if( $theme_slug != 'tubeaceplay' ){
  require_once 'inc/customizer/customizer.php';
}

require_once 'inc/functions/shortcodes.php';
require_once 'inc/functions/widgets.php';
require_once 'inc/functions/actions.php';
require_once 'inc/functions/filters.php';
require_once 'inc/functions/utilities.php';
require_once 'inc/functions/cron.php';
require_once 'inc/functions/posts-custom-columns.php';
require_once 'inc/functions/posts-meta-boxes.php';

// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'EDD_TUBEACE_STORE_URL', 'https://tubeace.com' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

// the name of your product. This should match the download name in EDD exactly
define( 'EDD_TUBEACE_ITEM_NAME', 'Tube Ace WordPress Plugin' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

define( 'EDD_TUBEACE_ITEM_ID', 104 );

// the name of the settings page for the license input to be displayed
define( 'EDD_TUBEACE_PLUGIN_LICENSE_PAGE', 'tubeace-license' );

if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {
  // load our custom updater
  include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

function edd_sl_tubeace_plugin_updater() {

  // retrieve our license key from the DB
  $license_key = trim( get_option( 'edd_tubeace_license_key' ) );

  // setup the updater
  $edd_updater = new EDD_SL_Plugin_Updater( EDD_TUBEACE_STORE_URL, __FILE__, array(
      'version'   => '2.7',         // current version number
      'license'   => $license_key,    // license key (used get_option above to retrieve from DB)
      'item_name' => EDD_TUBEACE_ITEM_NAME,  // name of this plugin
      'item_id'     => EDD_TUBEACE_ITEM_ID,  // download ID on your site
      'author'  => 'Tube Ace',  // author of this plugin
      'beta'    => false
    )
  );

}
add_action( 'admin_init', 'edd_sl_tubeace_plugin_updater', 0 );


/************************************
* the code below is just a standard
* options page. Substitute with
* your own.
*************************************/

function edd_tubeace_license_menu() {
  add_plugins_page( 'Tube Ace License', 'Tube Ace License', 'manage_options', EDD_TUBEACE_PLUGIN_LICENSE_PAGE, 'edd_tubeace_license_page' );
}
add_action('admin_menu', 'edd_tubeace_license_menu');

function edd_tubeace_license_page() {
  $license = get_option( 'edd_tubeace_license_key' );
  $status  = get_option( 'edd_tubeace_license_status' );
  ?>
  <div class="wrap">
    <h2><?php _e('Tube Ace Plugin License Options'); ?></h2>
    <form method="post" action="options.php">

      <?php settings_fields('edd_tubeace_license'); ?>

      <table class="form-table">
        <tbody>
          <tr valign="top">
            <th scope="row" valign="top">
              <?php _e('License Key'); ?>
            </th>
            <td>
              <input id="edd_tubeace_license_key" name="edd_tubeace_license_key" type="text" class="regular-text" value="<?php esc_attr_e( $license ); ?>" />
              <label class="description" for="edd_tubeace_license_key"><?php _e('Enter your license key'); ?></label>
            </td>
          </tr>
          <?php if( false !== $license ) { ?>
            <tr valign="top">
              <th scope="row" valign="top">
                <?php _e('Activate License'); ?>
              </th>
              <td>
                <?php if( $status !== false && $status == 'valid' ) { ?>
                  <span style="color:green;"><?php _e('active'); ?></span>
                  <?php wp_nonce_field( 'edd_tubeace_nonce', 'edd_tubeace_nonce' ); ?>
                  <input type="submit" class="button-secondary" name="edd_license_deactivate" value="<?php _e('Deactivate License'); ?>"/>
                <?php } else {
                  wp_nonce_field( 'edd_tubeace_nonce', 'edd_tubeace_nonce' ); ?>
                  <input type="submit" class="button-secondary" name="edd_license_activate" value="<?php _e('Activate License'); ?>"/>
                <?php } ?>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
      <?php submit_button(); ?>

    </form>
  <?php
}

function edd_tubeace_register_option() {
  // creates our settings in the options table
  register_setting('edd_tubeace_license', 'edd_tubeace_license_key', 'edd_tubeace_sanitize_license' );
}
add_action('admin_init', 'edd_tubeace_register_option');

function edd_tubeace_sanitize_license( $new ) {
  $old = get_option( 'edd_tubeace_license_key' );
  if( $old && $old != $new ) {
    delete_option( 'edd_tubeace_license_status' ); // new license has been entered, so must reactivate
  }
  return $new;
}


/************************************
* this illustrates how to activate
* a license key
*************************************/

function edd_tubeace_activate_license() {

  // listen for our activate button to be clicked
  if( isset( $_POST['edd_license_activate'] ) ) {

    // run a quick security check
    if( ! check_admin_referer( 'edd_tubeace_nonce', 'edd_tubeace_nonce' ) )
      return; // get out if we didn't click the Activate button

    // retrieve the license from the database
    $license = trim( get_option( 'edd_tubeace_license_key' ) );


    // data to send in our API request
    $api_params = array(
      'edd_action' => 'activate_license',
      'license'    => $license,
      'item_name'  => urlencode( EDD_TUBEACE_ITEM_NAME ), // the name of our product in EDD
      'url'        => home_url()
    );

    // Call the custom API.
    $response = wp_remote_post( EDD_TUBEACE_STORE_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

    // make sure the response came back okay
    if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

      if ( is_wp_error( $response ) ) {
        $message = $response->get_error_message();
      } else {
        $message = __( 'An error occurred, please try again.' );
      }

    } else {

      $license_data = json_decode( wp_remote_retrieve_body( $response ) );

      if ( false === $license_data->success ) {

        switch( $license_data->error ) {

          case 'expired' :

            $message = sprintf(
              __( 'Your license key expired on %s.' ),
              date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
            );
            break;

          case 'revoked' :

            $message = __( 'Your license key has been disabled.' );
            break;

          case 'missing' :

            $message = __( 'Invalid license.' );
            break;

          case 'invalid' :
          case 'site_inactive' :

            $message = __( 'Your license is not active for this URL.' );
            break;

          case 'item_name_mismatch' :

            $message = sprintf( __( 'This appears to be an invalid license key for %s.' ), EDD_TUBEACE_ITEM_NAME );
            break;

          case 'no_activations_left':

            $message = __( 'Your license key has reached its activation limit.' );
            break;

          default :

            $message = __( 'An error occurred, please try again.' );
            break;
        }

      }

    }

    // Check if anything passed on a message constituting a failure
    if ( ! empty( $message ) ) {
      $base_url = admin_url( 'plugins.php?page=' . EDD_TUBEACE_PLUGIN_LICENSE_PAGE );
      $redirect = add_query_arg( array( 'sl_activation' => 'false', 'message' => urlencode( $message ) ), $base_url );

      wp_redirect( $redirect );
      exit();
    }

    // $license_data->license will be either "valid" or "invalid"

    update_option( 'edd_tubeace_license_status', $license_data->license );
    wp_redirect( admin_url( 'plugins.php?page=' . EDD_TUBEACE_PLUGIN_LICENSE_PAGE ) );
    exit();
  }
}
add_action('admin_init', 'edd_tubeace_activate_license');


/***********************************************
* Illustrates how to deactivate a license key.
* This will decrease the site count
***********************************************/

function edd_tubeace_deactivate_license() {

  // listen for our activate button to be clicked
  if( isset( $_POST['edd_license_deactivate'] ) ) {

    // run a quick security check
    if( ! check_admin_referer( 'edd_tubeace_nonce', 'edd_tubeace_nonce' ) )
      return; // get out if we didn't click the Activate button

    // retrieve the license from the database
    $license = trim( get_option( 'edd_tubeace_license_key' ) );


    // data to send in our API request
    $api_params = array(
      'edd_action' => 'deactivate_license',
      'license'    => $license,
      'item_name'  => urlencode( EDD_TUBEACE_ITEM_NAME ), // the name of our product in EDD
      'url'        => home_url()
    );

    // Call the custom API.
    $response = wp_remote_post( EDD_TUBEACE_STORE_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

    // make sure the response came back okay
    if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

      if ( is_wp_error( $response ) ) {
        $message = $response->get_error_message();
      } else {
        $message = __( 'An error occurred, please try again.' );
      }

      $base_url = admin_url( 'plugins.php?page=' . EDD_TUBEACE_PLUGIN_LICENSE_PAGE );
      $redirect = add_query_arg( array( 'sl_activation' => 'false', 'message' => urlencode( $message ) ), $base_url );

      wp_redirect( $redirect );
      exit();
    }

    // decode the license data
    $license_data = json_decode( wp_remote_retrieve_body( $response ) );

    // $license_data->license will be either "deactivated" or "failed"
    if( $license_data->license == 'deactivated' ) {
      delete_option( 'edd_tubeace_license_status' );
    }

    wp_redirect( admin_url( 'plugins.php?page=' . EDD_TUBEACE_PLUGIN_LICENSE_PAGE ) );
    exit();

  }
}
add_action('admin_init', 'edd_tubeace_deactivate_license');


/************************************
* this illustrates how to check if
* a license key is still valid
* the updater does this for you,
* so this is only needed if you
* want to do something custom
*************************************/

function edd_tubeace_check_license() {

  global $wp_version;

  $license = trim( get_option( 'edd_tubeace_license_key' ) );

  $api_params = array(
    'edd_action' => 'check_license',
    'license' => $license,
    'item_name' => urlencode( EDD_TUBEACE_ITEM_NAME ),
    'url'       => home_url()
  );

  // Call the custom API.
  $response = wp_remote_post( EDD_TUBEACE_STORE_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

  if ( is_wp_error( $response ) )
    return false;

  $license_data = json_decode( wp_remote_retrieve_body( $response ) );

  if( $license_data->license == 'valid' ) {
    //echo 'valid'; //exit;
    // this license is still valid

  } else {
    //echo 'invalid'; exit;
    // this license is no longer valid
    ?>
    <div class="error notice">
        <p><?php _e( 'Invalid <a href="plugins.php?page=tubeace-license">Tube Ace</a> License. If your license expired, you will need to <a href="https://tubeace.com/pricing" target="_blank">purchase</a> another. <a href="https://tubeace.com/contact" target="_blank">Contact us</a> if problem persists.' ); ?></p>
    </div>
    <?php
    exit;
  }
}

/**
 * This is a means of catching errors from the activation method above and displaying it to the customer
 */
function edd_tubeace_admin_notices() {
  if ( isset( $_GET['sl_activation'] ) && ! empty( $_GET['message'] ) ) {

    switch( $_GET['sl_activation'] ) {

      case 'false':
        $message = urldecode( $_GET['message'] );
        ?>
        <div class="error">
          <p><?php echo $message; ?></p>
        </div>
        <?php
        break;

      case 'true':
      default:
        // Developers can put a custom success message here for when activation is successful if they way.
        break;

    }
  }
}
add_action( 'admin_notices', 'edd_tubeace_admin_notices' );

// returns true or false
function tubeace_license_status(){

  $status  = get_option( 'edd_tubeace_license_status' );

  if( $status == false || $status == 'invalid' ) {
    return false;
  } else{
    return true;
  }

}

// echos message to display warning of limited functionality.
function tubeace_license_status_message($type){

  $status  = get_option( 'edd_tubeace_license_status' );

  if( $status == false || $status == 'invalid' ) { 

    echo '<div class="error notice"><p>';    

    if($type == "hubtraffic_api"){
      _e( 'This demo version of Tube Ace will import only videos from page 1 of the API Import Tool. ');
    } 

    if($type == "xhamster_api"){
      _e( 'This demo version of Tube Ace will import only the first 10 videos from the xHamster API Import Tool. ');
    } 

    if($type == "mass_import"){
      _e( 'This demo version of Tube Ace will import only the first 10 videos from the Mass Import Tool. ');
    } 

    if($type == "dump"){
      _e( 'This demo version of Tube Ace will import only the first 10 videos from the dump file. ');
    }     

     _e( 'To unlock all the full features including unlimited video importing, <a href="https://tubeace.com/pricing" target="_blank">please purchase a license</a>. 

          <br><br>If you have already purchased a license, please <a href="plugins.php?page=tubeace-license">enter the license key</a> or <a href="https://tubeace.com/contact" target="_blank">contact us</a> if problem persists.' ); 

    echo '</p></div>';

  }
}
?>