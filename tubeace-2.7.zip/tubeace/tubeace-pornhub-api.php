<?php
set_time_limit(0);

tubeace_header(1);

tubeace_license_status_message('hubtraffic_api');

$siteArray = tubeace_api_site_array('pornhub');

require_once 'inc/apis/api-import-form.php';
require_once 'inc/apis/api-import-single-populate-form.php';
require_once 'inc/apis/api-import-single-import.php';
require_once 'inc/apis/api-import.php';
require_once 'inc/apis/api-import-cron.php';
