<?php tubeace_header(1); 

edd_tubeace_check_license();

?>
<div class="wrap">
  <h2><?php _e('Upgrade Thumbs from Tube Ace 1.x','tubeace') ?></h2>

  <?php
  if(!empty($_GET['StartThumbUpgrade'])) {

  	if( get_site_option('tubeace_set_pending_thumbs_status') != 1 ){

	  	// set all existing videos without feature imaged as pending until thumb copied and set as featured image
		$args = array( 
			'posts_per_page' => 99999999,
		    'meta_query' => array(
		        array(
		            'key'     => '_thumbnail_id',
		            'compare'   => 'NOT EXISTS',
		        ),
	        
		        array( //make sure tubeace post
		            'key'     => 'saved_thmb',
		            'compare'   => 'EXISTS',
		        ),
		    ),
		);

		$no_featured_image = new WP_Query( $args );
		while ( $no_featured_image->have_posts() ) : $no_featured_image->the_post();

			$my_post = array(
			  'ID'           => get_the_id(),
			  'post_status' => 'pending'
			);
			wp_update_post( $my_post );

			$string = sprintf( __('Set Post id %d status to pending until featured imaged generated.', 'tubeace'), get_the_id() );

			echo $string .'<br>';

		endwhile;
		wp_reset_query();	
			
		_e('Done setting post stauses to pending until featured image copied.','tubeace');

		add_site_option('tubeace_set_pending_thumbs_status', 1);
  	}
 
  	// start/resume copy thumb as featured image, set to publish
	$args = array( 
		'posts_per_page' => 99999999,
		'post_status' => 'pending',
	    'meta_query' => array(
	        array(
	            'key'     => '_thumbnail_id',
	            'compare'   => 'NOT EXISTS',
	        ),
        
	        array( //make sure tubeace post
	            'key'     => 'saved_thmb',
	            'compare'   => 'EXISTS',
	        ),
	    ),
	);

	$no_featured_image = new WP_Query( $args );
	while ( $no_featured_image->have_posts() ) : $no_featured_image->the_post();

	    $subPath = tubeace_sub_dir_path( get_the_id() );

	    //create thumb dir
	    $upload_dir = wp_upload_dir();
	    $create_path = $upload_dir['basedir']."/tubeace-thumbs/".$subPath;
	    wp_mkdir_p($create_path);

	    $def_thmb = get_post_meta(get_the_id(), 'def_thmb', true);

		$thumb_source = $upload_dir['basedir']."/tubeace-thumbs/".$subPath."/".get_the_id()."_".$def_thmb.".jpg";

		// copy thumb
	    tubeace_create_featured_image(get_the_id(), $thumb_source);

		$my_post = array(
		  'ID'           => get_the_id(),
		  'post_status' => 'publish'
		);
		wp_update_post( $my_post );

		$string = sprintf( __('Copied Post id %d featured image and set post status to publish.', 'tubeace'), get_the_id() );

		echo $string .'<br>';

	endwhile;
	wp_reset_query();	

	//once all done, delete site option
	delete_site_option('tubeace_pending_thumb_upgrade');

  } else { ?>


  <?php _e('Video post statuses will be set to \'pending\' until its thumbnail has been created.','tubeaceplay') ?><br>

  <form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-upgrade-thumbs.php') ?>" method="get">
    <input type="submit" value="<?php _e('Start Thumbnail Upgrade','tubeaceplay'); ?>" class="button-primary" name="StartThumbUpgrade">
    <input type="hidden" name="page" value="tubeace/tubeace-upgrade-thumbs.php">
  </form>      

  <?php } ?>  

</div>