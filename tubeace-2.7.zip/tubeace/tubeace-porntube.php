<?php
set_time_limit(0);

tubeace_header(1);

tubeace_license_status_message('dump');

$siteArray = tubeace_dump_site_array('porntube');
?>

<div class="wrap">
	<?php
	require_once 'inc/dumps/dump-import-form.php';
	require_once 'inc/dumps/dump-import.php';
	?>
</div>