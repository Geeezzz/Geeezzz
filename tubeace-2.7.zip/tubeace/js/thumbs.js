// rotating thumb functions
var rotateThumbs = new Array();

// saved thumbs
function changeThumb(index, i, num_thumbs, path){
	if (rotateThumbs[index]){
		if(i<=num_thumbs){
			
			//strip index
			//indexStr = index.replace(/[^0-9]/g, ''); 			

			var thumbsArr = index.split('-');

			document.getElementById(index).src = path + thumbsArr[1] + '_' + i + ".jpg";
			i++;
			setTimeout("changeThumb('" + index + "'," + i + ", " + num_thumbs + ", '" + path + "')", 600);
		}else{
			// loop
			changeThumb(index, 1, num_thumbs, path);
		}
	}
}

function thumbStart(index, num_thumbs, path){    
    rotateThumbs[index] = true;
    changeThumb(index, 1, num_thumbs, path);
}

function thumbStop(index, path, def){
    rotateThumbs[index] = false;
	
	//strip index
	//indexStr = index.replace(/[^0-9]/g, ''); 	
	var thumbsArr = index.split('-');
	
    document.getElementById(index).src = path + thumbsArr[1] + "_" + def + ".jpg";
}


// cdn 
function changeThumbCDN(index, i, thumbs_urls_str){
	if (rotateThumbs[index]){

		var thumbsArr = thumbs_urls_str.split(';');

		var num_thumbs = thumbsArr.length;

		if(i<num_thumbs){
			
			document.getElementById(index).src = thumbsArr[i];
			i++;
			setTimeout("changeThumbCDN('" + index + "'," + i + ", '" + thumbs_urls_str + "')", 600);
		}else{
			// loop
			changeThumbCDN(index, 0, thumbs_urls_str);
		}
	}
}

function thumbStartCDN(index, thumbs_urls_str){    
    rotateThumbs[index] = true;
    changeThumbCDN(index, 0, thumbs_urls_str);
}

function thumbStopCDN(index, def_thumb_url){
    rotateThumbs[index] = false;
	
    document.getElementById(index).src = def_thumb_url;
}