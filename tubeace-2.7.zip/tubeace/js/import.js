jQuery(document).ready(function ($) {

	//only load if on last page
	if(typeof(jQuery('#delimiter').val()) != "undefined" && jQuery('#delimiter').val() !== null){
		//var line = 1;
		process(1,0);
	}
});

function process(line,num_added){
	
	var status = jQuery('#status').val();
	var type = jQuery('#type').val();
	var delimiter = jQuery('#delimiter').val();
	var field = encodeURIComponent(jQuery('#field').val());
	var thumb_source = jQuery('#thumb_source').val();
	var sponsor = jQuery('#sponsor').val();
	var post_category = jQuery('#post_category').val();
	var block_dups = jQuery('#block_dups').val();
	var first_id = jQuery('#first_id').val();
	
	var dataString = 'action=my_action&line='+line+'&num_added='+num_added+'&';

	dataString = dataString + 'status='+status+'&';
	dataString = dataString + 'type='+type+'&';
	dataString = dataString + 'delimiter='+delimiter+'&';
	dataString = dataString + 'field='+field+'&';
	dataString = dataString + 'thumb_source='+thumb_source+'&';
	dataString = dataString + 'sponsor='+sponsor+'&';
	dataString = dataString + 'post_category='+post_category+'&';
	dataString = dataString + 'block_dups='+block_dups+'&';
	dataString = dataString + 'first_id='+first_id+'&';
	
	var setAlls=new Array('post_date','duration','title','description','tags','performers','site','sponsor_link_url','sponsor_link_txt','misc1','misc2','misc3','misc4','misc5');
	
	jQuery.each(setAlls, function(key, value) { 
	  dataString = dataString + 'setall_'+value+'='+encodeURIComponent(jQuery('#'+value).val())+'&';
	});	
	
	jQuery.ajax({
	  type: "POST",
	  dataType: 'json',
	  url: ajaxurl,
	  data: dataString,
	  
	  success: function(json){

		jQuery('#response').append(json.response);
		
		if(json.done==1){
			jQuery('#tubeace-loading').remove();
			return;
			
		} else {
			
			//increment
			line = line+1;
			
			process(line, json.num_added);
		}
	
	  }
	});
	
}

