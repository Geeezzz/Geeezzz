/**
 * This file adds some LIVE to the Theme Customizer live preview. To leverage
 * this, set your custom settings to 'postMessage' and then add your handling
 * here. Your javascript should grab settings from customizer controls, and 
 * then make any necessary changes to the page using jQuery.
 */
( function( $ ) {

	/* BG Images */

	// preview bg image
	wp.customize( 'ta_preview_background_image', function( value ) {
	    value.bind( function( to ) {

	        $( '.post-preview-styling' ).css( 'background-image', 'url( ' + to + ')' );
	    });
	});

	// sticky preview bg image
	wp.customize( 'ta_sticky_preview_background_image', function( value ) {
	    value.bind( function( to ) {

	        $( '.sticky-post-preview-styling' ).css( 'background-image', 'url( ' + to + ')' );
	    });
	});	

	//post preview
	bind_css('ta_preview_title_txt_color', '#tubeace-results .post-preview-styling:not(.sticky) a.preview-title', 'color');	
	bind_css('ta_preview_bg_color', '#tubeace-results .post-preview-styling:not(.sticky)', 'background-color');
	bind_css('ta_preview_txt_color', '#tubeace-results .post-preview-styling:not(.sticky)', 'color');
	bind_css('ta_preview_link_color', '#tubeace-results .post-preview-styling:not(.sticky) :not(.post-preview-tags):not(.post-preview-category):not(.post-preview-performers):not(.preview-date) a:not(.preview-title), .post-preview-styling:not(.sticky) .post-edit-link', 'color');
	bind_css('ta_preview_border_color', '#tubeace-results .post-preview-styling', 'border-color');
	bind_css('ta_preview_featured_image_border_color', '#tubeace-results .wp-post-image', 'border-color');
	bind_css('ta_preview_duration_bg_color', '#tubeace-results .post-preview-styling > .duration', 'background-color');
	bind_css('ta_preview_duration_txt_color', '#tubeace-results .post-preview-styling > .duration', 'color');
	bind_css('ta_preview_duration_border_color', '#tubeace-results .post-preview-styling > .duration', 'border-color');
	bind_css('ta_preview_post_date_txt_color', '#tubeace-results .preview-date > a', 'color');
	bind_css('ta_preview_tags_label_color', '#tubeace-results .post-preview-tags', 'color');
	bind_css('ta_preview_tags_txt_color', '#tubeace-results .post-preview-tags > a', 'color');
	bind_css('ta_preview_tags_bg_color', '#tubeace-results .post-preview-tags > a', 'background-color');
	bind_css('ta_preview_tags_border_color', '#tubeace-results .post-preview-tags > a', 'border-color');
	bind_css('ta_preview_category_label_color', '#tubeace-results .post-preview-category', 'color');
	bind_css('ta_preview_category_txt_color', '#tubeace-results .post-preview-category > a', 'color');
	bind_css('ta_preview_category_bg_color', '#tubeace-results .post-preview-category > a', 'background-color');
	bind_css('ta_preview_category_border_color', '#tubeace-results .post-preview-category > a', 'border-color');
	bind_css('ta_preview_performers_label_color', '#tubeace-results .post-preview-performers', 'color');
	bind_css('ta_preview_performers_txt_color', '#tubeace-results .post-preview-performers > a', 'color');
	bind_css('ta_preview_performers_bg_color', '#tubeace-results .post-preview-performers > a', 'background-color');
	bind_css('ta_preview_performers_border_color', '#tubeace-results .post-preview-performers > a', 'border-color');
	bind_css('ta_preview_rating_txt_color', '#tubeace-results .post-preview-rating', 'color');	
	bind_css('ta_preview_view_count_txt_color', '#tubeace-results .post-preview-view-count', 'color');


	//sticky post preview
	bind_css('ta_sticky_preview_label_txt_color', '#tubeace-results .sticky .ribbon span', 'color');
	bind_css('ta_sticky_preview_label_bg_color', '#tubeace-results .sticky .ribbon span', 'background-color');
	bind_css('ta_sticky_preview_title_txt_color', '#tubeace-results .sticky a.preview-title', 'color');	
	bind_css('ta_sticky_preview_bg_color', '#tubeace-results .sticky-post-preview-styling ', 'background-color');
	bind_css('ta_sticky_preview_txt_color', '#tubeace-results .sticky-post-preview-styling ', 'color');
	bind_css('ta_sticky_preview_link_color', '#tubeace-results .sticky-post-preview-styling :not(.sticky-post-preview-tags):not(.sticky-post-preview-category) a:not(.preview-title), .sticky .post-edit-link', 'color');
	bind_css('ta_sticky_preview_border_color', '#tubeace-results .sticky-post-preview-styling ', 'border-color');
	bind_css('ta_sticky_preview_featured_image_border_color', '#tubeace-results .sticky .wp-post-image', 'border-color');
	bind_css('ta_sticky_preview_duration_bg_color', '#tubeace-results .sticky-post-preview-styling > .duration', 'background-color');
	bind_css('ta_sticky_preview_duration_txt_color', '#tubeace-results .sticky-post-preview-styling > .duration', 'color');
	bind_css('ta_sticky_preview_duration_border_color', '#tubeace-results .sticky-post-preview-styling > .duration', 'border-color');	
	bind_css('ta_sticky_preview_post_date_txt_color', '#tubeace-results .sticky-preview-date > a', 'color');
	bind_css('ta_sticky_preview_tags_label_color', '#tubeace-results .sticky-post-preview-tags', 'color');
	bind_css('ta_sticky_preview_tags_txt_color', '#tubeace-results .sticky-post-preview-tags > a', 'color');
	bind_css('ta_sticky_preview_tags_bg_color', '#tubeace-results .sticky-post-preview-tags > a', 'background-color');
	bind_css('ta_sticky_preview_tags_border_color', '#tubeace-results .sticky-post-preview-tags > a', 'border-color');
	bind_css('ta_sticky_preview_category_label_color', '#tubeace-results .sticky-post-preview-category', 'color');
	bind_css('ta_sticky_preview_category_txt_color', '#tubeace-results .sticky-post-preview-category > a', 'color');
	bind_css('ta_sticky_preview_category_bg_color', '#tubeace-results .sticky-post-preview-category > a', 'background-color');
	bind_css('ta_sticky_preview_category_border_color', '#tubeace-results .sticky-post-preview-category > a', 'border-color');
	bind_css('ta_sticky_preview_performers_label_color', '#tubeace-results .sticky-post-preview-performers', 'color');
	bind_css('ta_sticky_preview_performers_txt_color', '#tubeace-results .sticky-post-preview-performers > a', 'color');
	bind_css('ta_sticky_preview_performers_bg_color', '#tubeace-results .sticky-post-preview-performers > a', 'background-color');
	bind_css('ta_sticky_preview_performers_border_color', '#tubeace-results .sticky-post-preview-performers > a', 'border-color');	
	bind_css('ta_sticky_preview_rating_txt_color', '#tubeace-results .sticky-post-preview-rating', 'color');	
	bind_css('ta_sticky_preview_view_count_txt_color', '#tubeace-results .sticky-post-preview-view-count', 'color');

	// pagination
	bind_css('ta_pagination_prev_bg_color', '.nav-links a.prev', 'background-color');
	bind_css('ta_pagination_prev_txt_color', '.nav-links a.prev', 'color');
	bind_css('ta_pagination_prev_border_color', '.nav-links a.prev', 'border-color');
	bind_css('ta_pagination_current_bg_color', '.nav-links span.current:not(.prev):not(.next)', 'background-color');
	bind_css('ta_pagination_current_txt_color', '.nav-links span.current:not(.prev):not(.next)', 'color');
	bind_css('ta_pagination_current_border_color', '.nav-links span.current:not(.prev):not(.next)', 'border-color');
	bind_css('ta_pagination_num_bg_color', '.nav-links a.page-numbers:not(.prev):not(.next)', 'background-color');
	bind_css('ta_pagination_num_txt_color', '.nav-links a.page-numbers:not(.prev):not(.next)', 'color');
	bind_css('ta_pagination_num_border_color', '.nav-links a.page-numbers:not(.prev):not(.next)', 'border-color');
    bind_css('ta_pagination_dots_bg_color', '.nav-links span.dots:not(.prev):not(.next)', 'background-color');
    bind_css('ta_pagination_dots_txt_color', '.nav-links span.dots:not(.prev):not(.next)', 'color');
    bind_css('ta_pagination_dots_border_color', '.nav-links span.dots:not(.prev):not(.next)', 'border-color');
    bind_css('ta_pagination_next_bg_color', '.nav-links a.next', 'background-color');
    bind_css('ta_pagination_next_txt_color', '.nav-links a.next', 'color');
    bind_css('ta_pagination_next_border_color', '.nav-links a.next', 'border-color');

    // related posts
	bind_css('ta_related_label_color', '#post-page-related-title', 'color');

	function bind_css(settings, selector, style){

		wp.customize( settings, function( value ) {
			value.bind( function( newval ) {
				$(selector).css(style, newval );
			} );
		} );

	}

} )( jQuery );