jQuery(document).ready(function ($) {

	//listen onclick
	$( ".tubeace-display-thumbs" ).click(function() {

	  var myValue = $( this ).attr('id'); 

	  // remove class
	  $(".tubeace-display-thumbs").removeClass("tubeace-def-thmb");

	  // add class
	  $(this).addClass("tubeace-def-thmb");

	  $('#tubeace_def_thmb').val(myValue);
	  $('#tubeace_def_thumb_url').val(myValue);

	});	

});


