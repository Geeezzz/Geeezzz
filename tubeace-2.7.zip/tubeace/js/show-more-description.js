function tubeaceMoreDescription() {
  var dots = document.getElementById("tubeace-more-description-dots");
  var moreText = document.getElementById("tubeace-more-description-txt");
  var btnText = document.getElementById("tubeace-more-description-btn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less";
    moreText.style.display = "inline";
  }
}