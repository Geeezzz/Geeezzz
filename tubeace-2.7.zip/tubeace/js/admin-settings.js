jQuery(document).ready(function ($) {

	var a = ["pornhub", "redtube", "tube8", "youporn", "xhamster"];
	a.forEach(function(site) {

	    // if 'Display Default Thumbnail Only' checkbox changed
		$('#tubeace_' + site + '_api_def_thumb_only').change(function() {
			if ($(this).is(':checked')) {

		    	$('#tubeace_' + site + '_api_use_def_thumb').prop("disabled", true); 
		    	$('#tubeace_' + site + '_api_num_thumbs').prop("disabled", true); 
		    	$('#tubeace_' + site + '_api_def_thumb').prop("disabled", true); 

		    } else {

		    	$('#tubeace_' + site + '_api_use_def_thumb').prop("disabled", false); 
		    	$('#tubeace_' + site + '_api_num_thumbs').prop("disabled", false); 
		    	$('#tubeace_' + site + '_api_def_thumb').prop("disabled", false); 	    	
		  	}
		});


		// If 'Use Preselected Default Thumbnail' checkbox changed
		$('#tubeace_' + site + '_api_use_def_thumb').change(function() {
			if ($(this).is(':checked')) {

		    	$('#tubeace_' + site + '_api_def_thumb_only').prop("disabled", true); 
		    	$('#tubeace_' + site + '_api_def_thumb').prop("disabled", true); 

		    } else {

		    	$('#tubeace_' + site + '_api_def_thumb_only').prop("disabled", false); 
		    	$('#tubeace_' + site + '_api_def_thumb').prop("disabled", false); 
		    	
		  	}
		});




	});











});