<?php

tubeace_header(1);

edd_tubeace_check_license();

if( isset($_GET['edit'])==1 ) { // edit single cron job

	$siteArray = tubeace_api_site_array($_GET['site']);
	include('inc/cron/cron-edit.php');

} else { //show cron jobs or delete

	if( isset($_GET['run_now'])!='' ) { 

		echo'<div class="updated"><p><b>Started Cron Job.</b></p></div>';

		$cron_id = $_GET['run_now'];

		wp_schedule_single_event( time(), 'tubeace_cron_manual_run_hook', array( $cron_id ) );
		spawn_cron();
	}

	?>
	<div class="wrap"><h1>Auto-Import Cron Jobs <span style="float:right"><small><small><span class="dashicons dashicons-paperclip"></span><a href="https://tubeace.com/docs/auto-import-cron-jobs" target="_blank">Documentation</a></small></small></span></h1></div>

	<?php

	include_once'inc/cron/cron-delete.php';

	echo'<form action="'.admin_url('admin.php?page=tubeace/tubeace-cron.php').'" method="post">';

	$siteArray = tubeace_api_site_array('pornhub');
	include('inc/cron/cron-display.php');

	$siteArray = tubeace_api_site_array('redtube');
	include('inc/cron/cron-display.php');

	$siteArray = tubeace_api_site_array('tube8');
	include('inc/cron/cron-display.php');

	$siteArray = tubeace_api_site_array('youporn');
	include('inc/cron/cron-display.php');

	$siteArray = tubeace_api_site_array('xhamster');
	include('inc/cron/cron-display-xhamster.php');


	echo '</form>';
}

?>