<?php 
/**
 *  This is a template file. 
 *  Displays post preview template part.
 *
**/

?>
<!-- start preview-->
<?php 

// check if already set in shortcode
if( !isset($classes) ){

$classes = array(
    get_theme_mod('ta_preview_xs_class', $tubeace_defaults['ta_preview_xs_class']),
    get_theme_mod('ta_preview_sm_class', $tubeace_defaults['ta_preview_sm_class']),
    get_theme_mod('ta_preview_md_class', $tubeace_defaults['ta_preview_md_class']),
    get_theme_mod('ta_preview_lg_class', $tubeace_defaults['ta_preview_lg_class']),
    'post-preview'
  ); 

}
?>

<div <?php post_class($classes) ?>>
  <div class="post-preview-styling">

    <?php if( get_theme_mod('ta_preview_show_duration', $tubeace_defaults['ta_preview_show_duration'])==1 && get_post_meta( get_the_ID(),'duration',true)  ) {  ?>
      <div class="duration"><?php echo tubeace_duration(get_post_meta( get_the_ID(),'duration',true)); ?></div> 
    <?php } ?>

    <?php if ( has_post_thumbnail() ): ?>
      <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
        <?php the_post_thumbnail( get_theme_mod('ta_preview_featured_image_size', $tubeace_defaults['ta_preview_featured_image_size']), array('class'=>'img-responsive')); ?>
      </a>
    <?php endif; ?>

    <?php if(get_theme_mod('ta_preview_show_title', $tubeace_defaults['ta_preview_show_title'])==1): ?>    
      <a class="preview-title" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo get_the_title(); ?></a>
    <?php endif; 

    if( (get_theme_mod('ta_preview_excerpt_content', $tubeace_defaults['ta_preview_excerpt_content'])=='excerpt') ){
      the_excerpt();
    }
    if( (get_theme_mod('ta_preview_excerpt_content', $tubeace_defaults['ta_preview_excerpt_content'])=='content') ){
      the_content();
    } ?>

    <div class="preview-date">
      <a href="<?php the_permalink() ?>">
        <?php
        if(get_theme_mod('ta_preview_show_post_date', $tubeace_defaults['ta_preview_show_post_date'])==1){
          echo get_the_date().' ';
        }

        if(get_theme_mod('ta_preview_show_post_time', $tubeace_defaults['ta_preview_show_post_time'])==1){
          echo get_the_time();
        } ?>
      </a>
    </div>

    <?php
    // author
    if(get_theme_mod('ta_preview_show_author', $tubeace_defaults['ta_preview_show_author'])==1){
    ?>
      <span class="post-preview-author">
        <?php
        if(get_theme_mod('ta_preview_link_to_author', $tubeace_defaults['ta_preview_link_to_author'])==1){

          if(get_theme_mod('ta_preview_show_author_avatar', $tubeace_defaults['ta_preview_show_author_avatar'])==1){

            echo '<a href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'">'.get_avatar( get_the_author_meta( 'ID' ), get_theme_mod('ta_preview_avatar_size', $tubeace_defaults['ta_preview_avatar_size']) ).'</a>';
          }
          echo' <a href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'"><span class="preview-author">'.get_the_author().'</span></a>';

        } else { //don't link to author page

          if(get_theme_mod('ta_preview_show_author_avatar', $tubeace_defaults['ta_preview_show_author_avatar'])==1){

            echo get_avatar( get_the_author_meta( 'ID' ), get_theme_mod('ta_preview_avatar_size', $tubeace_defaults['ta_preview_avatar_size']) );
          }
          echo' <span class="preview-author">'.get_the_author().'</span>';
        }?>
      </span>
    <?php
    }
    ?>

    <?php 
    // comments
    if(get_theme_mod('ta_preview_show_number_comments', $tubeace_defaults['ta_preview_show_number_comments'])==1){

    ?>
      <span class="post-preview-comments">
        <?php
        $comments_count = wp_count_comments( get_the_id() ); 

        if( $comments_count->approved == 1 ){
            $plural = 'Comment';
         } else {
            $plural = 'Comments';
         }        

        if(get_theme_mod('ta_preview_link_to_comments', $tubeace_defaults['ta_preview_link_to_comments'])==1){

          echo '<a href="'.esc_url( get_the_permalink() ).'#comments">'.$comments_count->approved .' '.$plural.'</a>';

        } else {
          echo $comments_count->approved .' '.$plural;
        }?>
      </span>
    <?php
    } 
    ?>

    <div class="clearfix"></div>

    <?php
    // ratings
    if(get_theme_mod('ta_preview_show_rating', $tubeace_defaults['ta_preview_show_rating'])==1){
    ?>
      <span class="post-preview-rating">
        <?php if(function_exists('the_ratings')) { echo expand_ratings_template( get_site_option('tubeace_post_preview_rating_templ','<span class="rating">%RATINGS_IMAGES%</span>') , get_the_ID()); }; ?> 
      </span>
    <?php } 

    // view count
    if(get_theme_mod('ta_preview_show_view_count', $tubeace_defaults['ta_preview_show_view_count'])==1){
    ?>
      <span class="post-preview-view-count">
        <?php if(function_exists('pvc_post_views')) {  pvc_post_views( $post_id = get_the_id() ); }; ?>
      </span>
    <?php
    }
    ?>

    <?php if(get_theme_mod('ta_preview_show_tags', $tubeace_defaults['ta_preview_show_tags'])==1 && get_the_tags() != '' ): ?>
      <div class="post-preview-tags">
        <?php echo esc_html( get_theme_mod('ta_preview_tags_label', $tubeace_defaults['ta_preview_tags_label'])); ?>
        <?php the_tags('', get_theme_mod('ta_preview_tags_separator', $tubeace_defaults['ta_preview_tags_separator']), ''); ?>
      </div>
    <?php endif; ?>

    <?php if( get_theme_mod('ta_preview_show_category', $tubeace_defaults['ta_preview_show_category'])==1 && get_the_category() != '' ) :?>
      <div class="post-preview-category">
        <?php echo esc_html( get_theme_mod('ta_preview_category_label', $tubeace_defaults['ta_preview_category_label'])); ?>
        <?php the_category(get_theme_mod('ta_preview_category_separator', $tubeace_defaults['ta_preview_category_separator'])); ?>
      </div>
    <?php endif; ?>

    <?php if( get_theme_mod('ta_preview_show_performers', $tubeace_defaults['ta_preview_show_performers'])==1 && get_the_term_list( $post->ID, "performer", 'Performers: ', ', ', '' ) != ''  ) :?>
      <div class="post-preview-performers">
        <?php echo get_the_term_list( $post->ID, "performer", esc_html(get_theme_mod('ta_preview_performers_label', $tubeace_defaults['ta_preview_performers_label'])), get_theme_mod('ta_preview_performers_separator', $tubeace_defaults['ta_preview_performers_separator']), '' ) ?>
      </div>
    <?php endif; ?>
  </div> <!-- post-preview-styling -->
</div>
<!-- end preview -->