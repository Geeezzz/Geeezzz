== Tube Ace ==

Plugin Name: Tube Ace
Theme URI: https://tubeace.com
Author: Tube Ace
Author URI: https://tubeace.com
Description: Build an adult video tube site with embedded video import tools from all the major adult video sites or any source with an import file.
Version: 2.7
Requires at least: 4.4
Tested up to: 5.8

== Info ==

- Demo -
https://demo.tubeace.com
 
== COPYRIGHT AND LICENSE ==

Tube Ace, copyright 2019 tubeace.com
 
- Tube Ace is built with the following resources -

Flowplayer 7
Resource URI: http://flowplayer.org

Video.js
Resource URI: http://videojs.com

== CHANGE LOG ==

= 2.7 = Released: 2021-09-26

 - Added 'Split video description after x characters' setting.

= 2.6.9 = Released: 2021-09-25

 - Fixed default videojs code to reference https files.

= 2.6.8 = Released: 2021-05-21

 - Fixed bug in tubeace_get_default_thumb_url() where RedTube thumbnail wasn't matching (possible equal sign in basename).

= 2.6.7 = Released: 2021-04-14

 - Added 'none' option for Excerpt field in Post Preview.

= 2.6.6 = Released: 2021-02-26

 - Fixed Notice errors shown if WP debugging is set to true
 - Added option to have content below video player in filter function tubeace_append_video_player_to_the_content
 - Added option to save / serve from CDN - thumbnails

= 2.6.5 = Released: 2020-04-01

 - Fixed bug appearing in WP 5.4 which prevented post_thumbnail_html filter from being called. Fixed by changing meta_value of 'by_url' for meta_key of '_thumbnail_id' to number '6969TA'

= 2.6.4 = Released: 2020-01-25
 - Fixed bug in view xhamster cron jobs.

= 2.6.3 = Released: 2019-05-28

 - Fixed bug when using count() function in PHP 7.2+.
 - Fixed bug to strip non alphanumeric characters from cron names.

= 2.6.2 = Released: 2019-04-13

 - Fixed single videos import tools missing parameter in tubeace_create_thumbs().

= 2.6.1 = Released: 2019-04-07

 - Removed unneeded apply filter.

= 2.6 = Released: 2019-04-06

 - Added new shortcode [tubeace_results] for Performer & Tag page results.

= 2.5.1 = Released: 2019-04-01

 - Fixed bug in tubeace_get_default_thumb_url() where RedTube thumbnail wasn't matching.
 - Fixed tubeace_cron_run() call missing parameter.

= 2.5 = Released: 2019-03-17

 - Added Related Videos widget and shortcode.

= 2.4.2 = Released: 2019-02-25

 - Fixed error in filter.php where 'CDN thumbs, default only' elseif statement on line 62 which triggered 'Can't use function return value in write context' in < PHP 5.5.

= 2.4.1 = Released: 2019-02-15

 - Fixed xHamster CDN thumbs to use https.
 - Fixed Safari bug where last video of first row drops by changing .row class to .tubeace-row in /css/bootstrap-3-grid.css.
 - Fixed cron delete if name contains hyphen.

= 2.4 = Released: 2019-02-08

 - Added ability to serve thumbnails from source in addition to saving to server for API import tools.
 - Added ability to link directly to video page from thumbnails for API imported videos.
 - Added sort order options for API calls.
 - Added word filters for API import tools.
 - Fixed cron job deletion error if same name.
 - Fixed CSV import for Mass Import tool.
 - Deprecated KeezMovies dump as file format no longer provided. API import to be added in future version.
 - Added limited features for free demo version.

= 2.3.1 =

 - Fixed Highest Rated shortcode to include pagination="true" on activation.
 - Reduced results number from 24 to 12 for shortcodes.

= 2.3 =

 - Added Pagination to shortcodes with customization options.

= 2.2.2 =

 - Changed .post-preview-view-count from margin to padding in customizer defaults.
 - Fixed xHamster API import settings GET parameters.
 - Fixed RedTube Dump import for new file format.
 - Fixed Mass Import Tool to show first result in file and improve field prediction.
 - Fixed sponsor link display to check for both URL and anchor text.
 - Fixed Bootstrap CSS classes .row, .container, .fluid-container to be prepended with 'tubeace-'.

= 2.2.1 =

 - Fixed xHamster import to get GET parameters.
 - Fixed uncaught error $category array set as string in cron.php.

= 2.2 =

 - Added shortcode support for Highest Rated, Most Viewed, Newest, Porn Star List and Categories.
 - Added 'Tube' page on activation with shortcodes.

= 2.1.2 =

 - Added default thumbnail select custom meta box for posts.
 - Added minimum rating filter to API imports.
 - Fixed EDD function names which could conflict with other plugins.

= 2.1.1 =

 - Fixed missing xHamster thumbnail add_site_option in settings for upgrades.

= 2.1 =

 - Added xHamster API tool.
 - Added preview thumbnail and site columns on admin Posts page.
 - Added allowfullscreen attribute to video player codes.
 - Added tubeace_cron_set_last_page_as_start to change start page to last complete page for faster cron importing.
 - Fixed bug incomplete PHP opening tag '<?' in api-import-single-populate-form.php
 - Fixed RedTube API import, tag parameter cannot be empty.
 - Fixed xHamster import fields, added 'video_url' as second field of dump file.

= 2.0.6 =

 - Fixed bug where def_thmb could be higher than saved_thmb for imports.
 - Fixed post_thumbnail_html filter.

= 2.0.5 =

 - Added restart on last page of cron if resuming after stall.
 - Added restart cron run after stall detection.
 - Fixed Run Now link not shown if already running.
 - Added 'Quality Control' page, delete posts with missing thumbnails.

= 2.0.4 =

 - Added 'Run Visual' for cron jobs.
 - Added switch stalled cron jobs back to Not Running.
 - Fixed deletion of tubeace_$frequency() when deleting a different site.

= 2.0.3 =

 - Fixed cron Last Start Time from reseting when manually editing cron job.
 - Fixed API Import using multiple keywords by replacing '+' with space before urlencode.
 - Added API Call URL to display in API Import results.

= 2.0.2 =

 - Fixed cron display to show 'Never' instead of 48 years ago for last start time.

= 2.0.1 =

 - Added CSS warning class 'tubeace-warnmsg' for warnings.
 - Added links to documentation from import tools.
 - Added option to import videos as 'Video' Post Format.
 - Fixed cron importer from importing duplicates by marking cron jobs as running.
 - Fixed API search and cron import if using multiple words as keyword.
 - Fixed number of thumbs to create for single video import on APIs.
 - Fixed EDD SL updater

= 2.0 =

 - Added Mass Import Tool field prediction for faster and less-hassle importing.
 - Added merge and overwrite options for tags and performers set all values.
 - Removed BangYouLater import, webmasters section now defunct.
 - Added option to select number of thumbnails to create for each video per import tool.
 - Added video.js video player option.
 - Added flowplayer 7 video player option.
 - Added featured image creation on video import to add compatability with all WordPress themes.
 - Added AJAX importing for API and Dump file Import tools.