<?php

class TubeAce_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'tubeace_widget', // Base ID
			esc_html__( 'Tube Ace Related Posts', 'tubeace' ), // Name
			array( 'description' => esc_html__( 'Displays related posts.', 'tubeace' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {

    	if ( !is_single() or is_page()) {  return;}

    	wp_reset_query();

		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		echo do_shortcode('[tubeace_related_posts widget="1" results="'.$instance['num_related_results'].'" xs_class="'.$instance['xs_class'].'" sm_class="'.$instance['sm_class'].'" md_class="'.$instance['md_class'].'" lg_class="'.$instance['lg_class'].'"]');
		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Related Videos', 'tubeace' );
		$num_related_results = ! empty( $instance['num_related_results'] ) ? $instance['num_related_results'] : esc_html__( '12', 'tubeace' );
		$xs_class = ! empty( $instance['xs_class'] ) ? $instance['xs_class'] : esc_html__( 'col-xs-12', 'tubeace' );
		$sm_class = ! empty( $instance['sm_class'] ) ? $instance['sm_class'] : esc_html__( 'col-sm-12', 'tubeace' );
		$md_class = ! empty( $instance['md_class'] ) ? $instance['md_class'] : esc_html__( 'col-md-12', 'tubeace' );
		$lg_class = ! empty( $instance['lg_class'] ) ? $instance['lg_class'] : esc_html__( 'col-lg-12', 'tubeace' );
		?>
		<p>
		  <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'tubeace' ); ?></label> 
		  <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
		  <label for="<?php echo esc_attr( $this->get_field_id( 'num_related_results' ) ); ?>"><?php esc_attr_e( 'Number of Related Results:', 'tubeace' ); ?></label> <br>
		  <input class="widefatX" id="<?php echo esc_attr( $this->get_field_id( 'num_related_results' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'num_related_results' ) ); ?>" type="text" value="<?php echo esc_attr( $num_related_results ); ?>">			
		</p>
		<p>
		  <label for="<?php echo esc_attr( $this->get_field_id( 'xs_class' ) ); ?>"><?php esc_attr_e( 'X-Small Devices (<768px) # of Columns:', 'tubeace' ); ?></label> <br>
		  <select id="<?php echo $this->get_field_id('xs_class'); ?>" name="<?php echo $this->get_field_name('xs_class'); ?>" class="widefat" style="width:100%;">
		    <option <?php selected( $instance['xs_class'], 'col-xs-12'); ?> value="col-xs-12">1</option>
			<option <?php selected( $instance['xs_class'], 'col-xs-6'); ?> value="col-xs-6">2</option> 
		  </select>
		</p>
		<p>
		  <label for="<?php echo esc_attr( $this->get_field_id( 'sm_class' ) ); ?>"><?php esc_attr_e( 'Small Devices (<768px) # of Columns:', 'tubeace' ); ?></label> <br>
		  <select id="<?php echo $this->get_field_id('sm_class'); ?>" name="<?php echo $this->get_field_name('sm_class'); ?>" class="widefat" style="width:100%;">
		    <option <?php selected( $instance['sm_class'], 'col-sm-12'); ?> value="col-sm-12">1</option>
			<option <?php selected( $instance['sm_class'], 'col-sm-6'); ?> value="col-sm-6">2</option> 
		  </select>
		</p>	
		<p>
		  <label for="<?php echo esc_attr( $this->get_field_id( 'md_class' ) ); ?>"><?php esc_attr_e( 'Medium Devices (≥992px) # of Columns:', 'tubeace' ); ?></label> <br>
		  <select id="<?php echo $this->get_field_id('md_class'); ?>" name="<?php echo $this->get_field_name('md_class'); ?>" class="widefat" style="width:100%;">
		    <option <?php selected( $instance['md_class'], 'col-md-12'); ?> value="col-md-12">1</option>
			<option <?php selected( $instance['md_class'], 'col-md-6'); ?> value="col-md-6">2</option>
			<option <?php selected( $instance['md_class'], 'col-md-4'); ?> value="col-md-4">3</option>
		  </select>
		</p>
		<p>
		  <label for="<?php echo esc_attr( $this->get_field_id( 'lg_class' ) ); ?>"><?php esc_attr_e( 'Large Devices (≥1200px) # of Columns:', 'tubeace' ); ?></label> <br>
		  <select id="<?php echo $this->get_field_id('lg_class'); ?>" name="<?php echo $this->get_field_name('lg_class'); ?>" class="widefat" style="width:100%;">
		    <option <?php selected( $instance['lg_class'], 'col-lg-12'); ?> value="col-lg-12">1</option>
			<option <?php selected( $instance['lg_class'], 'col-lg-6'); ?> value="col-lg-6">2</option> 
			<option <?php selected( $instance['lg_class'], 'col-lg-4'); ?> value="col-lg-4">3</option>
			<option <?php selected( $instance['lg_class'], 'col-lg-3'); ?> value="col-lg-3">4</option>
		  </select>
		</p>		
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['num_related_results'] = ( ! empty( $new_instance['num_related_results'] ) ) ? sanitize_text_field( $new_instance['num_related_results'] ) : '';
		$instance['xs_class'] = ( ! empty( $new_instance['xs_class'] ) ) ? sanitize_text_field( $new_instance['xs_class'] ) : '';
		$instance['sm_class'] = ( ! empty( $new_instance['sm_class'] ) ) ? sanitize_text_field( $new_instance['sm_class'] ) : '';
		$instance['md_class'] = ( ! empty( $new_instance['md_class'] ) ) ? sanitize_text_field( $new_instance['md_class'] ) : '';
		$instance['lg_class'] = ( ! empty( $new_instance['lg_class'] ) ) ? sanitize_text_field( $new_instance['lg_class'] ) : '';

		return $instance;
	}
}

// register TubeAce_Widget widget
function register_tubeace_widget() {
    
	register_widget( 'TubeAce_Widget' );
}
add_action( 'widgets_init', 'register_tubeace_widget' );
?>