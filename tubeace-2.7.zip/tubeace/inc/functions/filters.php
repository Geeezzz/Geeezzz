<?php

// Add settings link on plugin page
function tubeace_settings_link($links) { 
  $settings_link = '<a href="options-general.php?page=tubeace/tubeace-settings.php">Settings</a>'; 
  array_unshift($links, $settings_link); 
  return $links; 
}
$plugin = plugin_basename(__FILE__); 
add_filter('plugin_action_links_'.$plugin, 'tubeace_settings_link' );

// show single or rotating thumbnail.
//function tubeace_show_thumbs( $html, $post_id, $post_image_id ) {
function tubeace_show_thumbs( $html, $post_id ) {

    // number of saved thumbs (if saved)
    $saved_thmb = get_post_meta( $post_id,'saved_thmb',true);

    // semi-colon delimited string of thumbs (if not saved and serving from CDN)
    $thumbs_src = get_post_meta( $post_id,'thumbs_src',true);

    $title = get_the_title($post_id);

    if($saved_thmb>1) { // saved thumbs

        $subPath = tubeace_sub_dir_path($post_id); 

        $upload_dir = wp_upload_dir();
        $thumb_url = $upload_dir['baseurl']."/tubeace-thumbs/".$subPath."/";

        $def_thmb = get_post_meta( $post_id,'def_thmb',true);

        // if def_thmb > saved_thmb, set def_thmb = saved_thmb
        // for backwards compatability - fixed bug in 2.0.6 which allowed $def_thmb to be higher than $saved_thmb
        if( $def_thmb > $saved_thmb ){
          $def_thmb = $saved_thmb;
        }

        // default thumb to show
        $thumb = $thumb_url.$post_id."_".$def_thmb.".jpg";

        $hash = bin2hex(random_bytes(5));

        $hash.= $hash.'-'.$post_id;

        $rotate_thumbs = "onmouseover=\"thumbStart('".$hash."', $saved_thmb, '$thumb_url');\" onmouseout=\"thumbStop('".$hash."', '$thumb_url', '$def_thmb');\"";

        $thumb = "<img class=\"img-responsive wp-post-image\" src=\"$thumb\" $rotate_thumbs id=\"".$hash."\" alt=\"".esc_attr($title)."\">";
        return $thumb;    
         
    } elseif( !empty($thumbs_src) ){  // CDN thumbs, rotating

        $hash = bin2hex(random_bytes(5));

        $def_thumb_url = get_post_meta( $post_id,'def_thumb_url',true);

        $rotate_thumbs = "onmouseover=\"thumbStartCDN('".$hash."', '$thumbs_src');\" onmouseout=\"thumbStopCDN('".$hash."', '$def_thumb_url');\"";

        $thumb = "<img class=\"img-responsive wp-post-image\" src=\"$def_thumb_url\" $rotate_thumbs id=\"".$hash."\" alt=\"".esc_attr($title)."\">";
        return $thumb;   

    } elseif( empty($thumbs_src) && get_post_meta( $post_id,'def_thumb_url',true) ){  // CDN thumbs, default only

        $def_thumb_url = get_post_meta( $post_id,'def_thumb_url',true);

        $thumb = "<img class=\"img-responsive wp-post-image\" src=\"$def_thumb_url\" alt=\"".esc_attr($title)."\">";
        return $thumb;

    } else {// single thumb generated or non-tubeace post
    
        return $html;

    }
}
add_filter( 'post_thumbnail_html', 'tubeace_show_thumbs', 10, 3 );


// add video player to the_content
function tubeace_append_video_player_to_the_content( $content ) {

    global $tubeace_defaults;    
    global $wp_query; 
 
    // Check if we're inside the main loop in a single post page.
    if ( is_single() && in_the_loop() && is_main_query() ) {

        $embed_code = get_post_meta( get_the_ID(),'embed_code',true);

        $video_id = get_post_meta( get_the_ID(),'video_id',true);
        $site = get_post_meta( get_the_ID(),'site',true);

        if(!empty($embed_code)){

            $code = "<div class=\"flex-video\">$embed_code</div>";

        } elseif($site =="drtuber.com"){

            $code = get_site_option('tubeace_drtuber_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";

        } elseif($site =="pornhub.com"){

            $code = get_site_option('tubeace_pornhub_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";

        } elseif($site =="keezmovies.com"){

            $code = get_site_option('tubeace_keezmovies_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="porntube.com"){

            $code = get_site_option('tubeace_porntube_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="redtube.com"){

            $code = get_site_option('tubeace_redtube_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";

        } elseif($site =="spankwire.com"){

            $code = get_site_option('tubeace_spankwire_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="sunporno.com"){

            $code = get_site_option('tubeace_sunporno_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="tube8.com"){

            $code = get_site_option('tubeace_tube8_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="xhamster.com"){

            $code = get_site_option('tubeace_xhamster_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="xtube.com"){

            $code = get_site_option('tubeace_xtube_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="xvideos.com"){

            $code = get_site_option('tubeace_xvideos_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            
        } elseif($site =="youporn.com"){

            $code = get_site_option('tubeace_youporn_video_player_code');
            $code = str_replace("{video_id}", $video_id, $code);
            $code = "<div class=\"flex-video\">$code</div>";
            

        } elseif( get_post_meta(get_the_ID(), 'video_url',true) != '' ){

            if(get_site_option('tubeace_default_video_player')=="flowplayer7"){

                $code = get_site_option('tubeace_flowplayer7_code');
                $code = str_replace("{plugin_url}", plugins_url('tubeace'), $code);
                $code = str_replace("{video_file}", get_post_meta(get_the_ID(), 'video_url',true), $code);

                if( get_post_meta(get_the_ID(), 'thumb_url',true) != ''  ){
                    $thumb_url = get_post_meta(get_the_ID(), 'thumb_url',true);
                } else {
                    $thumb_url = get_the_post_thumbnail_url(get_the_ID());
                }

                $code = str_replace("{thumb_url}", $thumb_url, $code);
            }

            if(get_site_option('tubeace_default_video_player')=="videojs"){

                $code = get_site_option('tubeace_videojs_code');
                $code = str_replace("{plugin_url}", plugins_url('tubeace'), $code);
                $code = str_replace("{video_file}", get_post_meta(get_the_ID(), 'video_url',true), $code);

                if( get_post_meta(get_the_ID(), 'thumb_url',true) != ''  ){
                    $thumb_url = get_post_meta(get_the_ID(), 'thumb_url',true);
                } else {
                    $thumb_url = get_the_post_thumbnail_url(get_the_ID());
                }

                $code = str_replace("{thumb_url}", $thumb_url, $code);                
            }

        } else {

            return $content;
        }

        $theme_slug =  get_option('stylesheet'); 

        $related = '';

        if($theme_slug != 'tubeaceplay' && get_theme_mod('ta_show_related', $tubeace_defaults['ta_show_related'])==1){ 

            $related = do_shortcode('[tubeace_related_posts filter="1"]');
        } 

        $tubeace_split_description_characters = get_site_option('tubeace_split_description_characters');

        $charcount = strlen(strip_tags($content));

        if(  $charcount > $tubeace_split_description_characters ){

            $output[0] = substr($content, 0, $tubeace_split_description_characters);
            $output[1] = substr($content, $tubeace_split_description_characters);

            // wrap long content
            $content = $output[0] .'<span id="tubeace-more-description-dots">...</span><span id="tubeace-more-description-txt">'.$output[1].'</span><button onclick="tubeaceMoreDescription()" id="tubeace-more-description-btn" class="btn btn-default">Read more</button>';
        }

        if( get_site_option( 'tubeace_filter_video_position') == 'below' ){
            return $content . $code . $related;
        }        
        if( get_site_option( 'tubeace_filter_video_position') == 'above' ){
            return $code . $content .  $related;
        }
        
    }
 
    return $content;
}
add_filter( 'the_content', 'tubeace_append_video_player_to_the_content',11);
?>