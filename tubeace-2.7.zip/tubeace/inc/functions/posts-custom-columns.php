<?php

// GET FEATURED IMAGE
function ST4_get_featured_image($post_ID) {

  // get CDN thumb
  if ( !empty(get_post_meta( $post_ID,'def_thumb_url',true)) ){

    return get_post_meta( $post_ID,'def_thumb_url',true);

  } else {

    // get saved image
    $post_thumbnail_id = get_post_thumbnail_id($post_ID);
    if ($post_thumbnail_id) {
        $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview');
        return $post_thumbnail_img[0];
    }

  }





}

// ADD NEW COLUMN
function ST4_columns_head($defaults) {
    $defaults['featured_image'] = 'Preview Image';
    return $defaults;
}
 
// SHOW THE FEATURED IMAGE
function ST4_columns_content($column_name, $post_ID) {
    if ($column_name == 'featured_image') {
        $post_featured_image = ST4_get_featured_image($post_ID);
        if ($post_featured_image) {
            echo '<img src="' . $post_featured_image . '" class="tubeace-img-responsive" />';
        }
    }
}
add_filter('manage_posts_columns', 'ST4_columns_head');
add_action('manage_posts_custom_column', 'ST4_columns_content', 10, 2);


// GET SITE IMAGE
function tubeace_get_site_image($post_ID) {

    $site= get_post_meta( get_the_ID(), 'site',true );
    
    if( isset( $site ) ){

        if($site=='pornhub.com'){
            $img = 'pornhub.png';
        }elseif($site=='redtube.com'){
            $img = 'redtube.png';
        }elseif($site=='tube8.com'){
            $img = 'tube8.jpg';
        }elseif($site=='youporn.com'){
            $img = 'youporn.png';
        }elseif($site=='xhamster.com'){
            $img = 'xhamster.png';
        } else {
            $img = 'play.png';   
        }

    } else {
        $img = 'play.png';    
  }

  $img = plugins_url('/tubeace/images/favicon-'.$img);

    return $img;
}

// ADD NEW COLUMN
function site_image_columns_head($defaults) {
    $defaults['site_icon'] = 'Site';
    return $defaults;
}
 
// SHOW THE FEATURED IMAGE
function site_image_columns_content($column_name, $post_ID) {
    if ($column_name == 'site_icon') {
        $post_site_image = tubeace_get_site_image($post_ID);
        $perma = get_the_permalink();
        if ($post_site_image) {
          echo '<a href="'.$perma.'" target="_blank">';
            echo '<img src="' . $post_site_image . '" class="tubeace-posts-site-icon" />';
            echo'</a>';
        }
    }
}
add_filter('manage_posts_columns', 'site_image_columns_head');
add_action('manage_posts_custom_column', 'site_image_columns_content', 10, 2);

?>