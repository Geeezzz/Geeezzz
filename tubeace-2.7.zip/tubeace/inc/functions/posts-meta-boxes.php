<?php

// custom meta box preview thumbnails
function wporg_add_custom_box(){
    
    add_meta_box(
        'wporg_box_id',           // Unique ID
        'Preview Thumbnails',  // Box title
        'wporg_custom_box_html',  // Content callback, must be of type callable
        'post'                   // Post type
    );
}
add_action('add_meta_boxes', 'wporg_add_custom_box');


function wporg_custom_box_html($post){

    $post_id = $post->ID;

    // number of saved thumbs (if saved)
    $saved_thmb = get_post_meta( $post_id,'saved_thmb',true);

    // semi-colon delimited string of thumbs (if not saved and serving from CDN)
    $thumbs_src = get_post_meta( $post_id,'thumbs_src',true);

    if($saved_thmb>1) { // saved thumbs

        $subPath = tubeace_sub_dir_path( get_the_id() );

        $def_thmb = get_post_meta(get_the_id(), 'def_thmb', true);

        for($i=1;$i<=$saved_thmb;$i++){

            if( $def_thmb == $i ){
              $class = 'tubeace-def-thmb';
            } else {
              $class = '';
            }

            $thumb_source = WP_CONTENT_URL."/uploads/tubeace-thumbs/".$subPath."/".get_the_id()."_".$i.".jpg";

            echo '<img src="'.$thumb_source.'" id="'.$i.'" class="tubeace-display-thumbs '.$class.'">';
        }

        ?>
        <input type="hidden" name="tubeace_def_thmb" id="tubeace_def_thmb" value="<?php echo $def_thmb; ?>">
        <?php

    } elseif( !empty($thumbs_src) ){  // CDN thumbs, rotating

        $thumbsArr = explode(';', $thumbs_src);

        $def_thumb_url = get_post_meta( $post_id,'def_thumb_url',true);

        $i=1;        
        foreach ($thumbsArr as $value) {

            if( $def_thumb_url == $value ){
              $class = 'tubeace-def-thmb';
            } else {
              $class = '';
            }          
            echo '<img src="'.$value.'" id="'.urlencode($value).'" class="tubeace-display-thumbs '.$class.'">';
            $i++;
        }
        ?>
        <input type="hidden" name="tubeace_def_thumb_url" id="tubeace_def_thumb_url" value="<?php echo urlencode($def_thumb_url); ?>">
        <?php
    } else { // single thumb  

        $featured_image = get_the_post_thumbnail_url($post_id );

        // single saved
        if( !empty($featured_image)) { // saved thumbs

            $thumb_source = $featured_image;

        } else { // CDN

            $thumb_source = get_post_meta( $post_id,'def_thumb_url',true);            
        }

        echo '<img src="'.$thumb_source.'" class="tubeace-display-thumbsX">';
    }
}

function add_admin_scripts( $hook ) {

    global $post;

    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
      wp_enqueue_script(  'tubeace-select-def-thumb', plugins_url() . '/tubeace/js/select-def-thumb.js' );
    }
}
add_action( 'admin_enqueue_scripts', 'add_admin_scripts', 10, 1 );

// save post
function wporg_save_postdata($post_id){

    if (array_key_exists('tubeace_def_thmb', $_POST)) {

      // if changed, generate new featured image

        if( $_POST['tubeace_def_thmb'] != get_post_meta($post_id, 'def_thmb', true) ){

          $upload_dir = wp_upload_dir();
          $subPath = tubeace_sub_dir_path( get_the_id() );

          $tubeace_def_thmb = intval($_POST['tubeace_def_thmb']);

          $thumb_source = $upload_dir['basedir']."/tubeace-thumbs/".$subPath."/".$post_id."_".$tubeace_def_thmb.".jpg";

          // copy thumb
          tubeace_create_featured_image($post_id, $thumb_source);
        }

        update_post_meta(
            $post_id,
            'def_thmb',
            $_POST['tubeace_def_thmb']
        );
    }

    if (array_key_exists('tubeace_def_thumb_url', $_POST)) {

        $def_thumb_url = urldecode($_POST['tubeace_def_thumb_url']);

        update_post_meta(
            $post_id,
            'def_thumb_url',
            $def_thumb_url
        );

    }


}
add_action('save_post', 'wporg_save_postdata');

?>