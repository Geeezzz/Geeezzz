<?php

// AJAX callbacks
require_once WP_PLUGIN_DIR.'/tubeace/inc/apis/api-import-ajax-callback.php';
require_once WP_PLUGIN_DIR.'/tubeace/inc/mass-import/mass-import-ajax-callback.php';
require_once WP_PLUGIN_DIR.'/tubeace/inc/dumps/dump-import-ajax-callback.php';
require_once WP_PLUGIN_DIR.'/tubeace/inc/qc/missing-thumbnails-ajax-callback.php';

?>