<?php

/* Enqueue CSS and JS */
function tubeace2_enqueue()  { 

	global $tubeace_defaults;

	// css portions
	$custom_css = get_theme_mod('ta_preview_css', $tubeace_defaults['ta_preview_css']);
	$custom_css.= get_theme_mod('ta_sticky_preview_css', $tubeace_defaults['ta_sticky_preview_css']);
	$custom_css.= get_theme_mod('ta_pagination_css', $tubeace_defaults['ta_pagination_css']);

	// from Customizer > tubeaceplay Theme Options > Post Preview  > Background Image
	if( strlen( $background_image_url = get_theme_mod('ta_preview_background_image', $tubeace_defaults['ta_preview_background_image']) ) > 0 ){ 
		$custom_css.= '.post-preview-styling {';
		$custom_css.= 'background-image: url('. $background_image_url .');'; 
		$custom_css.= 'background-repeat: '. get_theme_mod('ta_preview_background_image_repeat', $tubeace_defaults['ta_preview_background_image_repeat']) .';';
		$custom_css.= 'background-position: '. get_theme_mod('ta_preview_background_image_position', $tubeace_defaults['ta_preview_background_image_position']) .';';
		$custom_css.= 'background-attachment: '. get_theme_mod('ta_preview_background_image_attachment', $tubeace_defaults['ta_preview_background_image_attachment']) .';';
		$custom_css.= '}';
	}	

	  // from Customizer > tubeaceplay Theme Options > Sticky Post Preview  > Background Image
	  if( strlen( $background_image_url = get_theme_mod('ta_sticky_preview_background_image', $tubeace_defaults['ta_sticky_preview_background_image']) ) > 0 ){ 
	    $custom_css.= '.sticky-post-preview-styling {';
	    $custom_css.= 'background-image: url('. $background_image_url .');'; 
	    $custom_css.= 'background-repeat: '. get_theme_mod('ta_sticky_preview_background_image_repeat', $tubeace_defaults['ta_sticky_preview_background_image_repeat']) .';';
	    $custom_css.= 'background-position: '. get_theme_mod('ta_sticky_preview_background_image_position', $tubeace_defaults['ta_sticky_preview_background_image_position']) .';';
	    $custom_css.= 'background-attachment: '. get_theme_mod('ta_sticky_preview_background_image_attachment', $tubeace_defaults['ta_sticky_preview_background_image_attachment']) .';';
	    $custom_css.= '}';
	  }

	$custom_css = tubeace_minify_css($custom_css);

	wp_register_style( 'tubeace-style2', false );
	wp_enqueue_style( 'tubeace-style2' );

	wp_add_inline_style( 'tubeace-style2', $custom_css );

	// get array of fonts for Google Fonts
	$fonts = [
		get_theme_mod('ta_preview_title_font_family'),
		get_theme_mod('ta_preview_font_family'),
		get_theme_mod('ta_preview_duration_font_family'),
		get_theme_mod('ta_preview_tags_font_family'),
		get_theme_mod('ta_preview_category_font_family'),
		get_theme_mod('ta_preview_performers_font_family'),
		get_theme_mod('ta_preview_rating_font_family'),
		get_theme_mod('ta_preview_view_count_font_family'),

	    get_theme_mod('ta_sticky_preview_label_font_family'),
	    get_theme_mod('ta_sticky_preview_title_font_family'),
	    get_theme_mod('ta_sticky_preview_font_family'),
	    get_theme_mod('ta_sticky_preview_duration_font_family'),
	    get_theme_mod('ta_sticky_preview_tags_font_family'),
	    get_theme_mod('ta_sticky_preview_category_font_family'),
	    get_theme_mod('ta_sticky_preview_performers_font_family'),
	    get_theme_mod('ta_sticky_preview_rating_font_family'),
	    get_theme_mod('ta_sticky_preview_view_count_font_family'),

	    get_theme_mod('ta_pagination_prev_font_family'),
	    get_theme_mod('ta_pagination_current_font_family'),
	    get_theme_mod('ta_pagination_num_font_family'),
	    get_theme_mod('ta_pagination_num_hover_font_family'),
	    get_theme_mod('ta_pagination_next_font_family'),

		get_theme_mod('ta_related_font_family')
	];

	// remove false value(s)
	$fonts = array_filter( $fonts, 'strlen' );
	// remove duplicates
	$fonts = array_unique($fonts);
	// remove webfonts (not retrievable in API)
	$fonts = array_diff( $fonts, tubeace_websafe_fonts() );

	// make sure at least 1 in array
	if( sizeof($fonts)>0 ){

		// implode fonts array with pipe for API call
		$fonts = implode('|', $fonts);

		// replace space with plus sign for API call
		$fonts = str_replace(" ", "+", $fonts);

		wp_enqueue_style( 'tubeace-fonts', 'http://fonts.googleapis.com/css?family='.$fonts, false );
	}

	wp_enqueue_style( 'bootstrap-grid', plugin_dir_url( '' ).'tubeace/css/bootstrap-3-grid.css' );

	// js
	wp_enqueue_script('jquery');
	//wp_enqueue_script('bootstrap-js', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), true);
	if( get_theme_mod('preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='masonry' ){

		wp_enqueue_script('masonry');
		wp_enqueue_script('imagesloaded');
		wp_enqueue_script('masonry-js', plugin_dir_url( '' ) . 'tubeace/js/masonry.js', array('jquery','imagesloaded'), true, true);
	}	

		wp_enqueue_script('tubeace-show-more-description', plugin_dir_url( '' ) . 'tubeace/js/show-more-description.js', array('jquery'), true, true);
}
add_action('wp_enqueue_scripts', 'tubeace2_enqueue',99999);

/* minify CSS */
function tubeace_minify_css($string){

		// comments
		$string = preg_replace('!/\*.*?\*/!s','', $string);
		$string = preg_replace('/\n\s*\n/',"\n", $string);

		// space
		$string = preg_replace('/[\n\r \t]/',' ', $string);
		$string = preg_replace('/ +/',' ', $string);
		$string = preg_replace('/ ?([,:;{}]) ?/','$1',$string);

		// trailing;
		$string = preg_replace('/;}/','}',$string);

		return $string;    
}

function tubeace_duration($seconds){

		$hours = floor($seconds / 3600);
		$mins = floor(($seconds - $hours*3600) / 60);
		$s = $seconds - ($hours*3600 + $mins*60);

		$mins = ($mins<10?"0".$mins:"".$mins);
		$s = ($s<10?"0".$s:"".$s); 

		$time = ($hours>0?$hours.":":"").$mins.":".$s;
		return $time;
}

/* array of websafe fonts called in customizer */
function tubeace_websafe_fonts(){

	$fontsArr = array(
		'Arial, Helvetica, sans-serif'=>'Arial, Helvetica, sans-serif',
		'"Arial Black", Gadget, sans-serif'=>'Arial Black, Gadget, sans-serif',
		'"Comic Sans MS", cursive, sans-serif'=>'Comic Sans MS, cursive, sans-serif',
		'"Courier New", Courier, monospace'=>'Courier New, Courier, monospace',
		'Georgia, serif'=>'Georgia, serif',
		'Helvetica, Arial, sans-serif'=>'Helvetica, Arial, sans-serif',
		'Impact, Charcoal, sans-serif'=>'Impact, Charcoal, sans-serif',
		'"Lucida Sans Unicode", "Lucida Grande", sans-serif'=>'Lucida Sans Unicode, Lucida Grande, sans-serif',
		'"Lucida Console", Monaco, monospace'=>'Lucida Console, Monaco, monospace',
		'"Palatino Linotype", "Book Antiqua", Palatino, serif'=>'Palatino Linotype, Book Antiqua, Palatino, serif',
		'Tahoma, Geneva, sans-serif'=>'Tahoma, Geneva, sans-serif',
		'"Times New Roman", Times, serif'=>'Times New Roman, Times, serif',
		'"Trebuchet MS", Helvetica, sans-serif'=>'Trebuchet MS, Helvetica, sans-serif',
		'Verdana, Geneva, sans-serif'=>'Verdana, Geneva, sans-serif',
	);
	return $fontsArr;
}


function tubeace_porn_star_list_shortcode($atts = [], $content = null){
					
	$list = '';
	$tags = get_terms( 'performer' );

	$groups = array();
	if( $tags && is_array( $tags ) ) {
		foreach( $tags as $tag ) {
			$first_letter = strtoupper( $tag->name[0] );
			$groups[ $first_letter ][] = $tag;
		}
		if( count( $groups ) > 0 ) {
			foreach( $groups as $letter => $tags ) {

				$tagsCount = $tags;

				$i=0; $postCount = 0;

				$list .= '<h2>' . apply_filters( 'the_title', $letter ) . '</h2>';
				foreach( $tags as $tag ) {

					$i++;
					$postCount++;

					if($i==1){$list .='<div class="tubeace-row">';} 

					$url = esc_attr( get_term_link( $tag ) );
					$name = apply_filters( 'the_title', $tag->name );
					$list .= '<div class="col-xs-6 col-sm-4 col-md-3"><a href="' . $url . '">' . $name . '</a></div>';
					if($postCount == count($tagsCount)){$i=0;$list .='</div>';}

					}
				}
			}
	} else $list .= '<p>Sorry, but no tags were found</p>';

	return $list;
}


function tubeace_categories_shortcode($atts = [], $content = null){

	$list = '';

    $args = array(
      'orderby' => 'name',
      'order' => 'ASC'
      );
    $categories = get_categories($args);
      foreach($categories as $category) { 

        $list .= '<div class="col-xs-12 col-sm-6 col-md-4"><h3><a href="' . get_category_link( $category->term_id ) . '">' . $category->name.'</a></h3>';
        if($category->description){$list .= $category->description;}
        $list .= '</div>';
    } 

    return $list;
}

function tubeace_highest_rated_shortcode($atts = [], $content = null){

	global $tubeace_defaults;
	global $wp_query;

	$not_home = null;	

	// in case "tube" page not set as homepage, we need to str_replace 'tube' slug from paginaion 
	if( $atts['pagination'] == "true" && !is_front_page() ){
	
		// get page slug before loop
		$page_slug = get_post_field( 'post_name', get_post() );

		$not_home = 1; //must be set now, is_home won't work later
	}		

	$paged = 1;
	if ( get_query_var('paged') ) $paged = get_query_var('paged');
	if ( get_query_var('page') ) $paged = get_query_var('page');

	$args = array(
		'paged' => $paged,
		'meta_key' => 'ratings_average',
		'orderby' => 'meta_value',
		'order' => 'DESC',
		'ignore_sticky_posts' => true,
	);

	if( isset($atts['results']) ){
		$args['posts_per_page'] = $atts['results'];
	}
	
	if( isset($atts['sticky']) ){	

		//sticky: only_sticky, never_sticky, mixed
		// show mixed posts
		if( $atts['sticky'] == '' || $atts['sticky'] == 'mixed' ){
		}
		// show sticky posts
		if( $atts['sticky'] == 'only_sticky' ){
			$args['post__in'] = get_option( 'sticky_posts' );
		}
		// exclude sticky posts
		if( $atts['sticky'] == 'never_sticky' ){
			$args['post__not_in']  = get_option( 'sticky_posts' );
		}
	}

	$msg = null;

	$wp_query = new WP_Query($args); 

	if ( $wp_query ->have_posts() ){

		$msg = '';

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='flexbox' ){
			$msg.='<div id="tubeace-results" class="tubeace-row tubeace-flexbox">';
		}

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='masonry' ){
			$msg.='<div id="tubeace-results" class="masonry">';
		}			

		while (have_posts()) : the_post();

			ob_start();

			if( is_sticky() && !is_paged() ): // if sticky and not on home page 1
				$path = WP_PLUGIN_DIR . '/tubeace/templates/sticky-preview.php';
			else :
				$path = WP_PLUGIN_DIR . '/tubeace/templates/preview.php';
			endif;

			include $path;
				$msg.= ob_get_contents();
			ob_end_clean();

		endwhile;
		
		$msg.= '</div>';

		// show pagination
		if( $atts['pagination'] == "true"){

			$msg.= '<div id="tubeace-pagination">';

			$pagination = get_the_posts_pagination( array(
				'mid_size'  => esc_html( get_theme_mod('ta_pagination_num_per_side', $tubeace_defaults['ta_pagination_num_per_side'])),
				'prev_text' => __( esc_html( get_theme_mod('ta_pagination_prev_label', $tubeace_defaults['ta_pagination_prev_label'])) , 'tubeace' ),
				'next_text' => __( esc_html( get_theme_mod('ta_pagination_next_label', $tubeace_defaults['ta_pagination_next_label'])), 'tubeace' ),
			) );

			if( isset($atts['slug']) ){
				// replace
				$msg.= str_replace('/page', '/'.$atts['slug'].'/page', $pagination);

				if( $not_home == 1 ){

					// remove page slugs
					$msg = str_replace( get_home_url().'/'.$page_slug, get_home_url() , $msg);
				}
							
			} else {
				$msg.=$pagination;
			}

			$msg.= '</div>';
		}

	};
	wp_reset_query();
	return $msg;
}

function tubeace_most_viewed_shortcode($atts = [], $content = null){

	global $tubeace_defaults;          
	global $wp_query;

	$not_home = null;	

	// in case "tube" page not set as homepage, we need to str_replace 'tube' slug from paginaion 
	if( $atts['pagination'] == "true" && !is_front_page() ){
	
		// get page slug before loop
		$page_slug = get_post_field( 'post_name', get_post() );

		$not_home = 1; //must be set now, is_home won't work later
	}	

	$paged = 1;
	if ( get_query_var('paged') ) $paged = get_query_var('paged');
	if ( get_query_var('page') ) $paged = get_query_var('page');

	$args = array(
		'paged' => $paged,
		'order' => 'desc',
		'post_type' => 'post',
		'ignore_sticky_posts' => true,  
		// required by PVC
		'suppress_filters' => false,
		'orderby' => 'post_views',
	);

	if( isset($atts['results']) ){
		$args['posts_per_page'] = $atts['results'];
	}
	

	if( isset($atts['sticky']) ){

		//sticky: only_sticky, never_sticky, mixed
		// show mixed posts
		if( $atts['sticky'] == '' || $atts['sticky'] == 'mixed' ){
		}
		// show sticky posts
		if( $atts['sticky'] == 'only_sticky' ){
			$args['post__in'] = get_option( 'sticky_posts' );
		}
		// exclude sticky posts
		if( $atts['sticky'] == 'never_sticky' ){
			$args['post__not_in']  = get_option( 'sticky_posts' );
		}

	}

	$msg = null;

	$wp_query = new WP_Query($args); 

	if ( $wp_query ->have_posts() ){

		$msg = '';

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='flexbox' ){
			$msg.='<div id="tubeace-results" class="tubeace-row tubeace-flexbox">';
		}

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='masonry' ){
			$msg.='<div id="tubeace-results" class="masonry">';
		}			

		while (have_posts()) : the_post();

			ob_start();

			if( is_sticky() && !is_paged() ): // if sticky and not on home page 1
				$path = WP_PLUGIN_DIR . '/tubeace/templates/sticky-preview.php';
			else :
				$path = WP_PLUGIN_DIR . '/tubeace/templates/preview.php';
			endif;

			include $path;
				$msg.= ob_get_contents();
			ob_end_clean();

		endwhile;
		
		$msg.= '</div>';

		// show pagination
		if( $atts['pagination'] == "true"){

			$msg.= '<div id="tubeace-pagination">';

			$pagination = get_the_posts_pagination( array(
				'mid_size'  => esc_html( get_theme_mod('ta_pagination_num_per_side', $tubeace_defaults['ta_pagination_num_per_side'])),
				'prev_text' => __( esc_html( get_theme_mod('ta_pagination_prev_label', $tubeace_defaults['ta_pagination_prev_label'])) , 'tubeace' ),
				'next_text' => __( esc_html( get_theme_mod('ta_pagination_next_label', $tubeace_defaults['ta_pagination_next_label'])), 'tubeace' ),
			) );

			if( isset($atts['slug']) ){
				// replace
				$msg.= str_replace('/page', '/'.$atts['slug'].'/page', $pagination);

				if( $not_home == 1 ){

					// remove page slugs
					$msg = str_replace( get_home_url().'/'.$page_slug, get_home_url() , $msg);
				}

			} else {
				$msg.=$pagination;
			}

			$msg.= '</div>';
		}

	};
	wp_reset_query();

	return $msg;
}

function tubeace_newest_shortcode($atts = [], $content = null){

	global $tubeace_defaults;          
	global $wp_query;

	$not_home = null;

	// in case "tube" page not set as homepage, we need to str_replace 'tube' slug from paginaion 
	if( $atts['pagination'] == "true" && !is_front_page() ){
	
		// get page slug before loop
		$page_slug = get_post_field( 'post_name', get_post() );

		$not_home = 1; //must be set now, is_home won't work later
	}

	$paged = 1;
	if ( get_query_var('paged') ) $paged = get_query_var('paged');
	if ( get_query_var('page') ) $paged = get_query_var('page');

	$args = array(
		'paged' => $paged,
		'orderby' => 'post_id',
		'order' => 'DESC',
	);

	if( isset($atts['results']) ){
		$args['posts_per_page'] = $atts['results'];
	}

	if( isset($atts['sticky']) ){

		//sticky: only_sticky, never_sticky, mixed
		// show mixed posts
		if( $atts['sticky'] == '' || $atts['sticky'] == 'mixed' ){
		}
		// show sticky posts
		if( $atts['sticky'] == 'only_sticky' ){
			$args['post__in'] = get_option( 'sticky_posts' );
		}
		// exclude sticky posts
		if( $atts['sticky'] == 'never_sticky' ){
			$args['post__not_in']  = get_option( 'sticky_posts' );
		}
	}


	$wp_query = new WP_Query($args); 

	if ( $wp_query ->have_posts() ){

		$msg = '';

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='flexbox' ){
			$msg.='<div id="tubeace-results" class="tubeace-row tubeace-flexbox">';
		}

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='masonry' ){
			$msg.='<div id="tubeace-results" class="masonry">';
		}			

		while (have_posts()) : the_post();

			ob_start();

			if( is_sticky() && !is_paged() ): // if sticky and not on home page 1
				$path = WP_PLUGIN_DIR . '/tubeace/templates/sticky-preview.php';
			else :
				$path = WP_PLUGIN_DIR . '/tubeace/templates/preview.php';
			endif;

			include $path;
				$msg.= ob_get_contents();
			ob_end_clean();

		endwhile;
		
		$msg.= '</div>';

		// show pagination
		if( $atts['pagination'] == "true"){

			$msg.= '<div id="tubeace-pagination">';

			$pagination = get_the_posts_pagination( array(
				'mid_size'  => esc_html( get_theme_mod('ta_pagination_num_per_side', $tubeace_defaults['ta_pagination_num_per_side'])),
				'prev_text' => __( esc_html( get_theme_mod('ta_pagination_prev_label', $tubeace_defaults['ta_pagination_prev_label'])) , 'tubeace' ),
				'next_text' => __( esc_html( get_theme_mod('ta_pagination_next_label', $tubeace_defaults['ta_pagination_next_label'])), 'tubeace' ),
			) );

			if( isset($atts['slug']) ){

				// prepend /page with /sort_slug/page
				$msg.= str_replace('/page', '/'.$atts['slug'].'/page', $pagination);

				if( $not_home == 1 ){

					// remove page slugs
					$msg = str_replace( get_home_url().'/'.$page_slug, get_home_url() , $msg);
				}

			} else {
				$msg.=$pagination;
			}

			$msg.= '</div>';
		}

	};

	wp_reset_query();
	return $msg;
}


function tubeace_related_posts_shortcode($atts = [], $content = null){

    wp_reset_query();

    global $tubeace_defaults;    
    global $wp_query;
	global $post;

	$post_id = $post->ID;

    // Get the post categories
    $post_categories = get_the_category( $post_id );

    if ( $post_categories ){

	    foreach ( $post_categories as $category ) {
	        if ( $category->parent == 0 ) {
	            $term_ids[] = $category->term_id;
	        } else {
	            $term_ids[] = $category->parent;
	            $term_ids[] = $category->term_id;
	        }
	    }
    }

    // if from a widget - results will be specified in widget area / widgets.php
    if( isset($atts['widget']) ){

		$num_related_results = $atts['results'];

	} elseif ( isset($atts['filter']) ){ // filter.php

		$num_related_results = get_theme_mod('ta_related_num_results', $tubeace_defaults['ta_related_num_results']);

	} else { // shortcode - results could be empty 

		if( isset($atts['results']) ){

			$num_related_results = $atts['results'];
		} else {

			$num_related_results = 12;
		}
	}

    // Remove duplicate values from the array
    $unique_array = array_unique( $term_ids );

    $args = [
        'post__not_in' => [$post_id],
        'posts_per_page' => $num_related_results,
        'ignore_sticky_posts' => 1,
        'orderby' => 'rand',
        'no_found_rows' => true,
        'tax_query' => [
            [
                'taxonomy' => 'category',
                'terms' => $unique_array,
                'include_children' => false,
            ],
        ],     
    ];

    //get tag IDs
	$tag_ids = wp_get_post_tags( $post->ID, array( 'fields' => 'ids' ) );

    // if tags for post, add to args for query
    if( $tag_ids ){
    	$args['tag__in'] = $tag_ids;
    }

    $wp_query = new WP_Query($args); 

    // show related label if not in widget
    if( isset($atts['widget']) ){  
    	$related = '';

    } else {
    	$related = '<h3 id="post-page-related-title">'.esc_html(get_theme_mod('ta_related_label', $tubeace_defaults['ta_related_label'])).'</h3>';    	
    }

    if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='flexbox' ) :

      $related.= '<div id="tubeace-results" class="tubeace-row tubeace-flexbox">'; endif;

    if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='masonry' ) :
      $related.= '<div id="tubeace-results" class="masonry">'; endif;

    if ( $wp_query ->have_posts() ) {

      $is_related = 1;

      // if in widget get different sizes for previews
	  if( isset($atts['widget']) ){      	
		$classes = array(

		    $atts['xs_class'], 
		    $atts['sm_class'], 
		    $atts['md_class'], 
		    $atts['lg_class'], 
		    'post-preview'
		  );
      }

      while (have_posts()) : the_post();

        ob_start();

        if( is_sticky() && !is_paged() ): // if sticky and not on home page 1
          $path = WP_PLUGIN_DIR . '/tubeace/templates/sticky-preview.php';
        else :
          $path = WP_PLUGIN_DIR . '/tubeace/templates/preview.php';
        endif;

        include $path;
          $related.= ob_get_contents();
        ob_end_clean();

      endwhile;

    }

    wp_reset_postdata(); 
    wp_reset_query();

    $related.= '</div>';

	return $related;    
}


function tubeace_results_shortcode($atts = [], $content = null){

	global $tubeace_defaults;   
	global $wp_query;

	if ( $wp_query ->have_posts() ){

		$msg = '';

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='flexbox' ){
			$msg.='<div id="tubeace-results" class="tubeace-row tubeace-flexbox">';
		}

		if( get_theme_mod('ta_preview_layout_style', $tubeace_defaults['ta_preview_layout_style'])=='masonry' ){
			$msg.='<div id="tubeace-results" class="masonry">';
		}			

		while (have_posts()) : the_post();

			ob_start();

			if( is_sticky() && !is_paged() ): // if sticky and not on home page 1
				$path = WP_PLUGIN_DIR . '/tubeace/templates/sticky-preview.php';
			else :
				$path = WP_PLUGIN_DIR . '/tubeace/templates/preview.php';
			endif;

			include $path;
				$msg.= ob_get_contents();
			ob_end_clean();

		endwhile;
		
		$msg.= '</div>';

	};

	// show pagination
	if( $atts['pagination'] == "true"){

		$msg.= '<div id="tubeace-pagination">';

		$pagination = get_the_posts_pagination( array(
			'mid_size'  => esc_html( get_theme_mod('ta_pagination_num_per_side', $tubeace_defaults['ta_pagination_num_per_side'])),
			'prev_text' => __( esc_html( get_theme_mod('ta_pagination_prev_label', $tubeace_defaults['ta_pagination_prev_label'])) , 'tubeace' ),
			'next_text' => __( esc_html( get_theme_mod('ta_pagination_next_label', $tubeace_defaults['ta_pagination_next_label'])), 'tubeace' ),
		) );

		if( isset($atts['slug']) ){

			// prepend /page with /sort_slug/page
			$msg.= str_replace('/page', '/'.$atts['slug'].'/page', $pagination);

			if( $not_home == 1 ){

				// remove page slugs
				$msg = str_replace( get_home_url().'/'.$page_slug, get_home_url() , $msg);
			}

		} else {
			$msg.=$pagination;
		}

		$msg.= '</div>';

	}

	return $msg;    
}


function tubeace_shortcodes_init(){
	add_shortcode('tubeace_highest_rated', 'tubeace_highest_rated_shortcode');
	add_shortcode('tubeace_categories', 'tubeace_categories_shortcode');
	add_shortcode('tubeace_most_viewed', 'tubeace_most_viewed_shortcode');
	add_shortcode('tubeace_newest', 'tubeace_newest_shortcode');
	add_shortcode('tubeace_porn_star_list', 'tubeace_porn_star_list_shortcode');
	add_shortcode('tubeace_related_posts', 'tubeace_related_posts_shortcode');	
	add_shortcode('tubeace_results', 'tubeace_results_shortcode');	
}
add_action('init', 'tubeace_shortcodes_init');


?>