<?php

function tubeace_cron_manual_run($cron_id) {

    // get option name and valuue
    // "cron_id";i:"1";
    $match_option_val = '"cron_id";i:'.$cron_id.';';

    global $wpdb;
    $mylink = $wpdb->get_row( "SELECT * FROM ".$wpdb->prefix."options WHERE option_value LIKE '%$match_option_val%'" );

    $option_values = get_site_option($mylink->option_name);

    tubeace_cron_run($mylink->option_name, false);
}
add_action( 'tubeace_cron_manual_run_hook', 'tubeace_cron_manual_run', 10, 1 );

function tubeace_cron_run($option_name, $restarted){

    $option_values = get_site_option($option_name);

    //include 
    include WP_PLUGIN_DIR.'/tubeace/inc/cron/cron-option-values.php';

    // check not running
    if( $running == 1 ){
        // already running
        return;
    }

    // mark as running
    $cronValues = $option_values;
    $cronValues['running'] = 1;
    $cronValues['running_current_page'] = $start;
    $cronValues['running_start_timestamp'] = current_time( 'timestamp' );

    update_site_option($option_name, $cronValues);

    // get $site from option_name explode
    $option_name_Arr = explode('_', $option_name);
    $site = $option_name_Arr[2];

    $siteArray = tubeace_api_site_array($site);

    $tubeace_is_running_cron = 1;

    // set $tart page from $running_current_page if resuming stalled
    if( $restarted ){
      $start = $running_current_page;      
    }

    //include import
    include WP_PLUGIN_DIR.'/tubeace/inc/apis/api-import-process.php';

    // mark as not running
    // values may have been changed since start of run
    $cronValues = get_site_option($option_name);
    $cronValues['running'] = 0;
    $cronValues['running_completition_timestamp'] = current_time( 'timestamp' );
    update_site_option($option_name, $cronValues);

    // send email
    tubeace_cron_email($outputAll, $name, $siteArray['site_name']);
}

function tubeace_cron_run_cycle($frequency){

    $sites = array('redtube','pornhub','tube8','youporn','xhamster');

    foreach($sites as $site){

        //get options array
        $existingCronNames = get_site_option('tubeace_cron_'.$site.'_'.$frequency);

        foreach($existingCronNames as $name){

            $option_name = 'tubeace_cron_'.$site.'_'.$name.'_'.$frequency;

            tubeace_cron_run($option_name, false);
        }
    }
}

function tubeace_detect_stalled_cron_function(){

    $sites = array('redtube','pornhub','tube8','youporn','xhamster');

    foreach($sites as $site){

        $frequencies = array('hourly','twicedaily','daily');

        foreach($frequencies as $frequency){

            $existingCronNames = get_site_option('tubeace_cron_'.$site.'_'.$frequency);

            foreach($existingCronNames as $name){

                $option_values = get_site_option('tubeace_cron_'.$site.'_'.$name.'_'.$frequency);

                //include 
                include WP_PLUGIN_DIR.'/tubeace/inc/cron/cron-option-values.php';

                $cronValues = $option_values;

                if( $running == 1 ){

                    //if more than 30 minutes ago
                    if( ( current_time( 'timestamp' ) - (60 * 30) ) > $running_last_page_timestamp ){

                        // switch to not running
                        $cronValues['running'] = 0;
                        update_site_option('tubeace_cron_'.$site.'_'.$name.'_'.$frequency, $cronValues);

                        // restart
                        tubeace_cron_manual_run($cron_id, true);

                    }
                }
            }
        }
    }
}
add_action( 'tubeace_detect_stalled_cron', 'tubeace_detect_stalled_cron_function' );

function tubeace_hourly_function() {

  tubeace_cron_run_cycle('hourly');
}
add_action( 'tubeace_hourly', 'tubeace_hourly_function' );

function tubeace_twicedaily_function() {

  tubeace_cron_run_cycle('twicedaily');
}
add_action( 'tubeace_twicedaily', 'tubeace_twicedaily_function' );

function tubeace_daily_function() {

  tubeace_cron_run_cycle('daily');
}
add_action( 'tubeace_daily', 'tubeace_daily_function' );

# various functions
function tubeace_cron_frequency_label($frequency){

  if( $frequency=='hourly' ){
    $frequency_label = 'Hourly';
  } elseif( $frequency=='twicedaily' ){
    $frequency_label = 'Twice Daily';
  } elseif( $frequency=='daily' ){
    $frequency_label = 'Daily';
  } 

  return $frequency_label;
}

function tubeace_cron_email($message, $name, $site_name){

  $to = get_site_option('tubeace_cron_email');

  if(!empty($message) && !empty($to)){

    $subject = get_site_option('blogname')." '$name' $site_name Cron Import Update";

    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers.= "From: ".get_site_option('admin_email');

    $css = "<style>";
    $css.=".tubeace-succmsg{color:#390;}";
    $css.=".tubeace-warnmsg{color:#c68700;}";
    $css.=".tubeace-errormsg{color:red;}";
    $css.= "</style>";

    $message = $css.$message;

    mail($to, $subject, $message, $headers);
  }
}

function tubeace_show_cron_jobs($site, $frequency, $deleted_cron_names){

  //get options array
  $existingCronNames = get_site_option('tubeace_cron_'.$site.'_'.$frequency, false, true);

  if(!empty($existingCronNames)){

    foreach($existingCronNames as $name){

      // in case cron name contains hyphen, we need to replace it with something obscure and not used
      // will replace back in cron-delete.php
      $name_sanitized = str_replace('-', '.tahyphen.', $name);

      $site_plus_name_plus_freq = $site.'-'.$name_sanitized.'-'.$frequency;

      //make sure not just deleted
      if(!in_array($site_plus_name_plus_freq, $deleted_cron_names)){

            $option_values = get_site_option('tubeace_cron_'.$site.'_'.$name.'_'.$frequency, false, true);

            //include 
            include WP_PLUGIN_DIR.'/tubeace/inc/cron/cron-option-values.php';

            // post_category string for Run Visual URL
            $post_category_str = '';
            if(!empty($post_category)){
                foreach($post_category as $catID){

                    $post_category_str.='post_category%5B%5D='.$catID.'&';
                }
            }

        echo'
        <tr>
          <td>
              <input type="checkbox" name="del_'.$site.'['.$site_plus_name_plus_freq.']" value="1">
          </td>
          <td>'.tubeace_cron_frequency_label($frequency).' <br><a href="admin.php?page=tubeace/tubeace-cron.php&freq='.$frequency.'&name='.$name.'&edit=1&site='.$site.'">Edit</a>';
          
          if($running!=1){
            echo'
            | <a href="admin.php?keyword='.$keyword.'&tag'.$tag.'&start='.$start.'&end='.$end.'&rating_min='.$rating_min.'&ratings_num_min='.$ratings_num_min.'&status='.$status.'&sponsor='.$sponsor.'&post_date='.$post_date.'&'.$post_category_str.'description='.$description.'&tags='.$tags_set_all.'&tags_method='.$tags_method.'&performers='.$performers_set_all.'&performers_method='.$performers_method.'&sponsor_link_txt='.$sponsor_link_txt.'&sponsor_link_url='.$sponsor_link_url.'&misc1='.$misc1.'&misc2='.$misc2.'&misc3='.$misc3.'&misc4='.$misc4.'&misc5='.$misc5.'&page=tubeace%2Ftubeace-'.$site.'-api.php&all=Import+All">Run Visual</a>
            | <a href="admin.php?page=tubeace%2Ftubeace-cron.php&run_now='.$cron_id.'">Run Now</a>';
          }
          echo'
          </td>
          <td>'.$name.'</td>
          <td>'.stripcslashes($keyword).'</td>
          <td>'.$tag.'</td>
          <td>'.$start.'</td>
          <td>'.$end.'</td>';

          if($ordering=='featured'){
            $ordering = 'Featured';
          }

          if($ordering=='newest'){
            $ordering = 'Newest';
          }

          if($ordering=='mostviewed'){
            $ordering = 'Most Viewed';
          }

          if($ordering=='rating'){
            $ordering = 'Rating';
          }

          if($ordering=='favorites'){
            $ordering = 'Favorites';
          }

          if($ordering=='comments'){
            $ordering = 'Comments';
          }

          if($ordering=='votes'){
            $ordering = 'Votes';
          }

          if($ordering=='longest'){
            $ordering = 'Longest';
          }                                     

          echo'
          <td>'.$ordering.'</td>


          <td>'.$rating_min.'</td>
          <td>'.$ratings_num_min.'</td>

          <td>'.ucfirst($status).'</td>
          <td>';

          $categories = array();
          if(!empty($post_category)){
            foreach($post_category as $catID){

              $categories[].= get_the_category_by_ID( $catID );
            }

            $categories = implode(', ',$categories);
          } else {
            $categories='None';
          }

          echo $categories.'</td>
          <td>';

          if($running==0){
            $running = '<span class="tubeace-warnmsg">Not Running</span>';
          }
          if($running==1){
            $running = '<span class="tubeace-succmsg">Running on page '.$running_current_page.'</span>';
          }

          if( $running_start_timestamp != '' ){
            $start_time =  human_time_diff( $running_start_timestamp, current_time('timestamp') ) . ' ago';
          } else {
            $start_time = 'Never';
          }

          if( $running_last_page_timestamp != '' ){
            $last_page_time =  human_time_diff( $running_last_page_timestamp, current_time('timestamp') ) . ' ago';
          } else {
            $last_page_time = 'Never';
          }      
          
          if( $running_completition_timestamp != '' ){
            $completion_time =  human_time_diff( $running_completition_timestamp, current_time('timestamp') ) . ' ago';
          } else {
            $completion_time = 'Never';
          }   


          echo $running.'</td>
          <td>'.$start_time.'</td>
          <td>'.$last_page_time.'</td> 
          <td>'.$completion_time.'</td> 
        </tr>';
      }
    }
  }
} 


function tubeace_show_xhamster_cron_jobs($site, $frequency, $deleted_cron_names){

  //get options array
  $existingCronNames = get_site_option('tubeace_cron_'.$site.'_'.$frequency, false, false);

  if(!empty($existingCronNames)){

    foreach($existingCronNames as $name){

      $site_plus_name_plus_freq = $site.'-'.$name.'-'.$frequency;

      //make sure not just deleted
      if(!in_array($site_plus_name_plus_freq, $deleted_cron_names)){

            $option_values = get_site_option('tubeace_cron_'.$site.'_'.$name.'_'.$frequency, false, false);

            //include 
            include WP_PLUGIN_DIR.'/tubeace/inc/cron/cron-option-values.php';

            // post_category string for Run Visual URL
            $cats_str = '';
            if(!empty($cats)){
                foreach($cats as $catID){

                    $cats_str.='cats%5B%5D='.$catID.'&';
                }
            }

            // post_category string for Run Visual URL
            $post_category_str = '';
            if(!empty($post_category)){
                foreach($post_category as $catID){

                    $post_category_str.='post_category%5B%5D='.$catID.'&';
                }
            }

        echo'
        <tr>
          <td>
              <input type="checkbox" name="del_'.$site.'['.$site_plus_name_plus_freq.']" value="1">
          </td>
          <td>'.tubeace_cron_frequency_label($frequency).' <br><a href="admin.php?page=tubeace/tubeace-cron.php&freq='.$frequency.'&name='.$name.'&edit=1&site='.$site.'">Edit</a>';
          
          $channelStr = '';
          $N = count($cats);
          for($i=0; $i < $N; $i++){
            $channelStr.= '.'.$cats[$i];
          }
          
          if($running!=1){
            echo'
            | <a href="admin.php?'.$cats_str.'&cnt='.$cnt.'&resolution='.$resolution.'&period='.$period.'&orderby='.$orderby.'&rating_min='.$rating_min.'&views_min='.$views_min.'&status='.$status.'&sponsor='.$sponsor.'&post_date='.$post_date.'&'.$post_category_str.'description='.$description.'&tags='.$tags_set_all.'&tags_method='.$tags_method.'&performers='.$performers_set_all.'&performers_method='.$performers_method.'&sponsor_link_txt='.$sponsor_link_txt.'&sponsor_link_url='.$sponsor_link_url.'&misc1='.$misc1.'&misc2='.$misc2.'&misc3='.$misc3.'&misc4='.$misc4.'&misc5='.$misc5.'&page=tubeace%2Ftubeace-'.$site.'-api.php&all=Import+All">Run Visual</a>
            | <a href="admin.php?page=tubeace%2Ftubeace-cron.php&run_now='.$cron_id.'">Run Now</a>';
          }
          echo'
          </td>
          <td>'.$name.'</td>
          <td>';

          $categoriesArr = tubeace_api_export_categories_array('xhamster');

          if(!empty($cats)){

            $channelsStr = '';
            $N = count($cats);
            for($i=0; $i < $N; $i++){
              $channelsStr.= $categoriesArr[$cats[$i]].', ';
            } 

            $channelsStr = rtrim($channelsStr, ', ');
          }

          echo $channelsStr.'</td>
          <td>';

          if( isset($cnt)){

            if($cnt==0){
              $num_to_import = 100;
            }
            if($cnt==1){
              $num_to_import = 500;
            }       
            if($cnt==2){
              $num_to_import = 1000;
            }   
            if($cnt==3){
              $num_to_import = 5000;
            }   
            if($cnt==4){
              $num_to_import = 10000;
            }   
            if($cnt==5){
              $num_to_import = 50000;
            }   

          }

          echo $num_to_import.'</td>';

          if( isset($rating_min)){

            if($rating_min==0){
              $min_rating = 0;
            }

            if($rating_min==1){
              $min_rating = 40;
            }

            if($rating_min==2){
              $min_rating = 60;
            }

            if($rating_min==3){
              $min_rating = 80;
            }

          }

          echo'<td>'.$min_rating.'%</td>';

          if( isset($views_min)){

            if($views_min==0){
              $display_views_min = 'Any';
            }

            if($views_min==1){
              $display_views_min = 1000;
            }

            if($views_min==2){
              $display_views_min = 5000;
            }

            if($views_min==3){
              $display_views_min = 10000;
            }

          }

          echo'<td>'.$display_views_min.'</td>
          <td>'.ucfirst($status).'</td>
          <td>';

          $categories = array();
          if(!empty($post_category)){
            foreach($post_category as $catID){

              $categories[].= get_the_category_by_ID( $catID );
            }

            $categories = implode(', ',$categories);
          } else {
            $categories='None';
          }

          echo $categories.'</td>
          <td>';

          if($running==0){
            $running = '<span class="tubeace-warnmsg">Not Running</span>';
          }
          if($running==1){
            $running = '<span class="tubeace-succmsg">Running</span>';
          }

          if( $running_start_timestamp != '' ){
            $start_time =  human_time_diff( $running_start_timestamp, current_time('timestamp') ) . ' ago';
          } else {
            $start_time = 'Never';
          }

          if( $running_last_page_timestamp != '' ){
            $last_page_time =  human_time_diff( $running_last_page_timestamp, current_time('timestamp') ) . ' ago';
          } else {
            $last_page_time = 'Never';
          }      
          
          if( $running_completition_timestamp != '' ){
            $completion_time =  human_time_diff( $running_completition_timestamp, current_time('timestamp') ) . ' ago';
          } else {
            $completion_time = 'Never';
          }   


          echo $running.'</td>
          <td>'.$start_time.'</td>
          <td>'.$last_page_time.'</td> 
          <td>'.$completion_time.'</td> 
        </tr>';
      }
    }
  }
} 

?>