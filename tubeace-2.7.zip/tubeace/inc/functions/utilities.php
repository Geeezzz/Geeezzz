<?php

function tubeace_api_site_array($site) {  

  if($site=='pornhub'){

    $array = array(
        'site'=> 'pornhub',
        'domain'=> 'pornhub.com',
        'site_name'=> 'Pornhub',
        'single_example_id'=> 'ph5ed404e8c4201',
        'videos_per_pg'=> 30
      );
  }

  if($site=='redtube'){

    $array = array(
        'site'=> 'redtube',
        'domain'=> 'redtube.com',
        'site_name'=> 'RedTube',
        'single_example_id'=> '1775586',
        'videos_per_pg'=> 24
      );
  }

  if($site=='tube8'){

    $array = array(
        'site'=> 'tube8',
        'domain'=> 'tube8.com',
        'site_name'=> 'Tube8',
        'single_example_id'=> '34537021',
        'videos_per_pg'=> 31
      );
  }

  if($site=='youporn'){

    $array = array(
        'site'=> 'youporn',
        'domain'=> 'youporn.com',
        'site_name'=> 'YouPorn',
        'single_example_id'=> '13542163',
        'videos_per_pg'=> 29
      );
  }

  if($site=='xhamster'){

    $array = array(
        'site'=> 'xhamster',
        'domain'=> 'xhamster.com',
        'site_name'=> 'xHamster',
        //'single_example_id'=> '13478737',
        //'videos_per_pg'=> 29
      );
  }


  return $array;
}

function tubeace_dump_site_array($site) {  

  if($site=='drtuber'){
    $array = array(
        'site'=> 'drtuber',
        'domain'=> 'drtuber.com',
        'site_name'=> 'DrTuber',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='keezmovies'){
    $array = array(
        'site'=> 'keezmovies',
        'domain'=> 'keezmovies.com',
        'site_name'=> 'KeezMovies',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='pornhub'){
    $array = array(
        'site'=> 'pornhub',
        'domain'=> 'pornhub.com',
        'site_name'=> 'Pornhub',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ';'
      );
  }

  if($site=='porntube'){
    $array = array(
        'site'=> 'porntube',
        'domain'=> 'porntube.com',
        'site_name'=> 'PornTube',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='redtube'){
    $array = array(
        'site'=> 'redtube',
        'domain'=> 'redtube.com',
        'site_name'=> 'RedTube',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ';'
      );
  }

  if($site=='spankwire'){
    $array = array(
        'site'=> 'spankwire',
        'domain'=> 'spankwire.com',
        'site_name'=> 'Spankwire',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='sunporno'){
    $array = array(
        'site'=> 'sunporno',
        'domain'=> 'sunporno.com',
        'site_name'=> 'Sun Porno',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='tube8'){
    $array = array(
        'site'=> 'tube8',
        'domain'=> 'tube8.com',
        'site_name'=> 'Tube8',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='xhamster'){
    $array = array(
        'site'=> 'xhamster',
        'domain'=> 'xhamster.com',
        'site_name'=> 'xHamster',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ';'
      );
  }

  if($site=='xtube'){
    $array = array(
        'site'=> 'xtube',
        'domain'=> 'xtube.com',
        'site_name'=> 'XTube',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='xvideos'){
    $array = array(
        'site'=> 'xvideos',
        'domain'=> 'xvideos.com',
        'site_name'=> 'XVIDEOS',
        'delimiter'=> ';',
        'thumbs_delimiter'=> ','
      );
  }

  if($site=='youporn'){
    $array = array(
        'site'=> 'youporn',
        'domain'=> 'youporn.com',
        'site_name'=> 'YouPorn',
        'delimiter'=> '|',
        'thumbs_delimiter'=> ','
      );
  }

  return $array;
}


function tubeace_api_export_categories_array($site) {  

  if($site=='xhamster'){

    $array = [

      274 =>"18 Years Old",
      273 => "69",
      4234 => "African",
      38298 => "Agent",
      279 => "Albanian",
      280 => "Algerian",
      38299 => "Alien",
      4 => "Amateur",
      150 => "Amateur (Gay)",
      189 => "Amateur (Shemale)",
      5937 => "American",
      5 => "Anal",
      74832 => "Anal (Shemale)",
      74836 => "Anal (Gay)",
      104 => "Arab",
      239 => "Argentinian",
      282 => "Armenian",
      6 => "Asian",
      151 => "Asian (Gay)",
      224 => "Ass Licking",
      291 => "Audition",
      292 => "Australian",
      293 => "Austrian",
      294 => "Azeri",
      7 => "Babes",
      105 => "Babysitters",
      250 => "Ballbusting",
      299 => "Bangladeshi",
      152 => "Bareback (Gay)",
      190 => "Bareback (Shemale)",
      2999 => "BBC",
      16 => "BBW",
      60 => "BDSM",
      153 => "BDSM (Gay)",
      191 => "BDSM (Shemale)",
      8 => "Beach",
      154 => "Beach (Gay)",
      155 => "Bear (Gay)",
      305 => "Belgian",
      192 => "Big Ass (Shemale)",
      47 => "Big Boobs",
      219 => "Big Butts",
      257 => "Big Clits",
      156 => "Big Cock (Gay)",
      193 => "Big Cock (Shemale)",
      2807 => "Big Cock",
      312 => "Big Natural Tits",
      313 => "Big Nipples",
      194 => "Big Tits (Shemale)",
      315 => "Bikini",
      95 => "Bisexuals",
      10 => "Black and Ebony",
      106 => "Black and Ebony (Gay)",
      217 => "Black and Ebony (Shemale)",
      11 => "Blondes",
      157 => "Blowjob (Gay)",
      195 => "Blowjob (Shemale)",
      12 => "Blowjobs",
      323 => "Bolivian",
      254 => "Bondage",
      325 => "Bosnian",
      142 => "Brazilian",
      107 => "British",
      13 => "Brunettes",
      43949 => "Brutal Sex",
      108 => "Bukkake",
      158 => "Bukkake (Gay)",
      245 => "Bulgarian",
      336 => "Cambodian",
      338 => "Canadian",
      339 => "Car",
      83 => "Cartoons",
      236 => "Castings",
      233 => "Cat Fights",
      14 => "Celebrities",
      231 => "CFNM",
      351 => "Cheating",
      260 => "Cheerleaders",
      352 => "Chilean",
      144 => "Chinese",
      17 => "Close-ups",
      8455 => "Coed",
      363 => "College",
      364 => "Colombian",
      38301 => "Compilation",
      234 => "Cosplay",
      367 => "Costa Rica",
      226 => "Cougars",
      74833 => "Couple (Shemale)",
      74837 => "Couple (Gay)",
      3287 => "Cowgirl",
      96 => "Creampie",
      196 => "Creampie (Shemale)",
      373 => "Croatian",
      159 => "Crossdresser (Gay)",
      109 => "Cuckold",
      376 => "Cum in Mouth",
      383 => "Cum Swallowing",
      160 => "Cum Tribute (Gay)",
      18 => "Cumshots",
      264 => "Cunnilingus",
      143 => "Czech",
      38296 => "Dad",
      161 => "Daddy (Gay)",
      145 => "Danish",
      227 => "Deep Throats",
      393 => "Dildo",
      394 => "Dirty Talk",
      395 => "Doctor",
      397 => "Dogging",
      261 => "Doggy Style",
      74834 => "Domination (Shemale)",
      110 => "Double Penetration",
      237 => "Dutch",
      406 => "Ecuador",
      240 => "Egyptian",
      136 => "Emo",
      162 => "Emo Boy (Gay)",
      1234 => "Escort",
      412 => "Estonia",
      4193 => "European",
      137 => "Face Sitting",
      56 => "Facials",
      163 => "Fat (Gay)",
      140 => "Female Choice",
      97 => "Femdom",
      21 => "Fingering",
      422 => "Finnish",
      164 => "Fisting (Gay)",
      424 => "Fisting",
      63 => "Flashing",
      111 => "Foot Fetish",
      434 => "Footjob",
      112 => "French",
      256 => "Fucking Machines",
      15 => "Funny",
      437 => "Futanari",
      113 => "Gangbang",
      165 => "Gangbang (Gay)",
      197 => "Gangbang (Shemale)",
      114 => "Gaping",
      166 => "Gaping (Gay)",
      115 => "Gay Porn (Gay)",
      132 => "German",
      1428 => "Ghetto",
      167 => "Glory Hole (Gay)",
      230 => "Glory Holes",
      135 => "Gothic",
      116 => "Grannies",
      238 => "Greek",
      50 => "Group Sex",
      168 => "Group Sex (Gay)",
      446 => "Guadeloupe",
      447 => "Guatemala",
      198 => "Guy Fucks Shemale (Shemale)",
      22 => "Hairy",
      453 => "Halloween",
      169 => "Handjob (Gay)",
      48 => "Handjobs",
      23 => "Hardcore",
      148 => "HD Videos",
      220 => "HD Videos",
      221 => "HD Videos",
      133 => "Hentai",
      43 => "Hidden Cams",
      457 => "High Heels",
      2125 => "Hogtied",
      38294 => "Homemade",
      18356 => "Humiliation",
      244 => "Hungarian",
      170 => "Hunk (Gay)",
      117 => "Indian",
      467 => "Indonesian",
      98 => "Interracial",
      171 => "Interracial (Gay)",
      199 => "Interracial (Shemale)",
      468 => "Interview",
      469 => "Iranian",
      470 => "Irish",
      471 => "Israeli",
      118 => "Italian",
      472 => "Jamaican",
      87 => "Japanese",
      2563 => "Jewish",
      251 => "JOI",
      1213 => "Kissing",
      120 => "Korean",
      478 => "Lactating",
      141 => "Ladyboy (Shemale)",
      121 => "Latex",
      200 => "Latex (Shemale)",
      89 => "Latin",
      172 => "Latin (Gay)",
      201 => "Latin (Shemale)",
      481 => "Latvian",
      485 => "Lebanese",
      28 => "Lesbians",
      122 => "Lingerie",
      202 => "Lingerie (Shemale)",
      490 => "Lithuanian",
      173 => "Locker Room (Gay)",
      495 => "Macedonian",
      496 => "Maid",
      497 => "Malaysian",
      80 => "Man (Gay)",
      123 => "Massage",
      174 => "Massage (Gay)",
      31 => "Masturbation",
      175 => "Masturbation (Gay)",
      203 => "Masturbation (Shemale)",
      74831 => "Mature (Shemale)",
      32 => "Matures",
      253 => "Medical",
      246 => "Mexican",
      139 => "Midgets",
      99 => "MILFs",
      177 => "Military (Gay)",
      223 => "Military",
      506 => "Mistress",
      509 => "Moldavian",
      38295 => "Mom",
      512 => "Moroccan",
      178 => "Muscle (Gay)",
      263 => "Muscular Women",
      520 => "Nigerian",
      33 => "Nipples",
      521 => "Norwegian",
      522 => "Nudist",
      124 => "Nylon",
      100 => "Old+Young",
      179 => "Old+Young (Gay)",
      235 => "Orgasms",
      527 => "Orgy",
      180 => "Outdoor (Gay)",
      204 => "Outdoor (Shemale)",
      232 => "Outdoor",
      529 => "Pakistani",
      530 => "Panama",
      1759 => "Pantyhose",
      533 => "Party",
      534 => "PAWG",
      538 => "Peruvian",
      247 => "Philippines",
      43950 => "Pick Up",
      259 => "Piercing",
      42181 => "Pissing",
      249 => "Polish",
      38 => "Pornstars",
      242 => "Portuguese",
      101 => "POV",
      205 => "POV (Shemale)",
      85 => "Pregnant",
      39 => "Public Nudity",
      560 => "Puerto Rican",
      561 => "Puffy Nipples",
      2220 => "Pussy",
      88 => "Redheads",
      2221 => "Retro",
      38300 => "Rimjob",
      243 => "Romanian",
      1053 => "Rough Sex",
      125 => "Russian",
      582 => "Saggy Tits",
      267 => "Secretaries",
      248 => "Serbian",
      181 => "Sex Toy (Gay)",
      206 => "Sex Toy (Shemale)",
      19 => "Sex Toys",
      207 => "Shemale Fucks Girl (Shemale)",
      218 => "Shemale Fucks Guy (Shemale)",
      208 => "Shemale Fucks Shemale (Shemale)",
      82 => "Shemale Porn (Shemale)",
      42 => "Showers",
      602 => "Singaporean",
      266 => "Skinny",
      74838 => "Skinny (Gay)",
      606 => "Slave",
      608 => "Slovakian",
      609 => "Slovenian",
      182 => "Small Cock (Gay)",
      209 => "Small Tits (Shemale)",
      228 => "Small Tits",
      138 => "Softcore",
      210 => "Solo (Shemale)",
      617 => "South African",
      268 => "Spandex",
      222 => "Spanish",
      134 => "Spanking",
      183 => "Spanking (Gay)",
      229 => "Sports",
      90 => "Squirting",
      621 => "Sri Lankan",
      84 => "Stockings",
      211 => "Stockings (Shemale)",
      126 => "Strapon",
      184 => "Striptease (Gay)",
      265 => "Striptease",
      127 => "Swedish",
      128 => "Swingers",
      628 => "Swiss",
      629 => "Sybian",
      258 => "Tattoos",
      38302 => "Taxi",
      635 => "Teacher",
      44 => "Teens",
      212 => "Teens (Shemale)",
      146 => "Thai",
      1055 => "Threesome",
      129 => "Threesomes",
      45 => "Tits",
      642 => "Titty Fucking",
      81 => "Top Rated",
      646 => "Tunisian",
      130 => "Turkish",
      131 => "Twink (Gay)",
      649 => "Ukrainian",
      46 => "Upskirts",
      667 => "Valentine's Day",
      654 => "Venezuelan",
      656 => "Vibrator",
      241 => "Vietnamese",
      51 => "Vintage",
      185 => "Vintage (Gay)",
      214 => "Vintage (Shemale)",
      102 => "Voyeur",
      186 => "Voyeur (Gay)",
      42192 => "VR Porn",
      187 => "Webcam (Gay)",
      216 => "Webcam (Shemale)",
      3 => "Webcams",
      38297 => "Whipping",
      663 => "Wife",
      664 => "Wife Sharing",
      188 => "Wrestling (Gay)",
      353 => "Xmas",
      269 => "Yoga",
      74835 => "Young (Shemale)",
    ];

  }

  return $array;
}


function tubeace_detect_delimiter($fileName){
    //detect these delimeters
    $delA = array("|", ";", ",", "\t");
    $linesA = array();
    $resultA = array();

    $maxLines = 20; //maximum lines to parse for detection, this can be higher for more precision
    $lines = count(file($fileName));
    if ($lines < $maxLines) {//if lines are less than the given maximum
        $maxLines = $lines;
    }

    //load lines
    foreach ($delA as $key => $del) {
        $rowNum = 0;
        if (($handle = fopen($fileName, "r")) !== false) {
            $linesA[$key] = array();
            while ((($data = fgetcsv($handle, 1000, $del)) !== false) && ($rowNum < $maxLines)) {
                $linesA[$key][] = count($data);
                $rowNum++;
            }

            fclose($handle);
        }
    }

    //count rows delimiter number discrepancy from each other
    foreach ($delA as $key => $del) {
        //echo 'try for key=' . $key . ' delimeter=' . $del;
        $discr = 0;
        foreach ($linesA[$key] as $actNum) {
            if ($actNum == 1) {
                $resultA[$key] = 65535; //there is only one column with this delimeter in this line, so this is not our delimiter, set this discrepancy to high
                break;
            }

            foreach ($linesA[$key] as $actNum2) {
                $discr += abs($actNum - $actNum2);
            }

            //if its the real delimeter this result should the nearest to 0
            //because in the ideal (errorless) case all lines have same column number
            $resultA[$key] = $discr;
        }
    }

    //select the discrepancy nearest to 0, this would be our delimiter
    $delRes = 65535;
    foreach ($resultA as $key => $res) {
        if ($res < $delRes) {
            $delRes = $res;
            $delKey = $key;
        }
    }

    $delimeter = $delA[$delKey];

    '$delimeter=' . $delimeter;

    //get rows
    $row = 0;
    $rowsA = array();
    if (($handle = fopen($fileName, "r")) !== false) {
        while (($data = fgetcsv($handle, 1000, $delimeter)) !== false) {
            $rowsA[$row] = Array();
            $num = count($data);
            for ($c = 0; $c < $num; $c++) {
                $rowsA[$row][] = trim($data[$c]);
            }
            $row++;
        }
        fclose($handle);
    }

    return $delimeter;
}

//create multiple thumbs
function tubeace_create_thumbs($site, $lastID, $thumbsArr, $import_type, $def_thmb){

    $subPath = tubeace_sub_dir_path($lastID);

    //create thumb dir
    $upload_dir = wp_upload_dir();
    $create_path = $upload_dir['basedir']."/tubeace-thumbs/".$subPath;
    wp_mkdir_p($create_path);     

    if( get_site_option( 'tubeace_'.$site.'_'.$import_type.'_num_thumbs' ) > 0 || $site=='mass_import' ){

        $i = 1;
        foreach($thumbsArr as $val){

            $thumb_src = $val;

            if( ($site=='redtube' || $site=='pornhub' || $site=='tube8' || $site=='youporn') && $import_type=='api' ){

              //redtube uses protocol-relative URLs now for $val->src;
              if( !empty( $val->src ) ){
                $thumb_src = $val->src;
              }
              
              //add http:// if not already there
              if (false === strpos($thumb_src, '://')) {
                  $thumb_src = "http:" . $thumb_src;
              }   

            }

            list($width, $height) = getimagesize($thumb_src); 
            $thumbDest = $upload_dir['basedir']."/tubeace-thumbs/".$subPath."/".$lastID."_".$i.".jpg";
            
            if($width==get_site_option('tubeace_thumb_width') && $height==get_site_option('tubeace_thumb_height')){
                copy($thumb_src,$thumbDest);
            } else {
                tubeace_resize_thumb($thumb_src,$thumbDest,'jpg',$width,$height,get_site_option('tubeace_thumb_width'),get_site_option('tubeace_thumb_height'));    
            }
    
            $i++;
        }   
        
        $frames = $i-1;

        // if we don't know $def_thmb yet
        if( empty($def_thmb) ){

          if($site=='mass_import'){
              $def_thmb = 1;
          } else {
              $def_thmb = get_site_option('tubeace_'.$site.'_'.$import_type.'_def_thumb');

              // $def_thmb could be greater than actual # of thumbs, if this is case set $def_thmb as $frames (last frame)
              if( $def_thmb > $frames || empty($def_thmb) ){
                $def_thmb = $frames;
              }
          }
        }

        // add post meta of # of total thumbnails and default thumb #
        add_post_meta($lastID, 'saved_thmb', $frames);
        add_post_meta($lastID, 'def_thmb', $def_thmb);
    }

    //return the default image path/URL to create fetured image
    return $upload_dir['basedir']."/tubeace-thumbs/".$subPath."/".$lastID."_".$def_thmb.".jpg";
}

// create featured image (doesn't resize imgs)
function tubeace_create_featured_image($lastID, $default_thumb_src){

    //redtube uses protocol-relative URLs now for thumbs;
    //add http: if not already there
    // (if src doesn't contain :// and it does contain // )
    if ( strpos($default_thumb_src, '://') === false && strpos($default_thumb_src, '//') !== false ) {
        $default_thumb_src = "http:" . $default_thumb_src;
    }

    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($default_thumb_src);
    $filename = $lastID.'.jpg';
    if(wp_mkdir_p($upload_dir['path']))
        $file = $upload_dir['path'] . '/' . $filename;
    else
        $file = $upload_dir['basedir'] . '/' . $filename;
    file_put_contents($file, $image_data);

    $wp_filetype = wp_check_filetype($filename, null );
    $attachment = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id = wp_insert_attachment( $attachment, $file, $lastID );
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
    wp_update_attachment_metadata( $attach_id, $attach_data );

    set_post_thumbnail( $lastID, $attach_id );
}

function tubeace_resize_thumb($thumb_source,$thumb_path,$img_ext,$width,$height,$newwidth,$newheight){
  
  if($img_ext=="jpg"){
    if(@imagecreatefromjpeg($thumb_source)==true){
      $source = imagecreatefromjpeg($thumb_source);
      $is_valid_img = true;
    } else {
      $is_valid_img = false;
    }             
  } elseif ($img_ext=="png"){
    if(imagecreatefrompng($thumb_source)==true){
      $source = imagecreatefrompng($thumb_source);
      $is_valid_img = true;             
    } else {
      $is_valid_img = false;
    }             
  } elseif ($img_ext=="gif"){
    if(imagecreatefromgif($thumb_source)==true){          
      $source = imagecreatefromgif($thumb_source);
      $is_valid_img = true;             
    } else {
      $is_valid_img = false;
    }                           
  } else {
    $is_valid_img = false;  
  }
        
  if($is_valid_img){
  
    //CREATES IMAGE WITH NEW SIZES 
    $thumb = imagecreatetruecolor($newwidth, $newheight);       
  
    //RESIZES OLD IMAGE TO NEW SIZES 
    imagecopyresampled($thumb,  $source,  0,  0,  0,  0,  $newwidth,  $newheight,  $width,  $height); 

    //SAVES IMAGE AND SETS QUALITY || NUMERICAL VALUE = QUALITY ON SCALE OF 1-100 
    imagejpeg($thumb,  $thumb_path,  100);      
  }
  return $is_valid_img;
}


function tubeace_purge_thumbs( $site, $allThumbsArr, $import_type){

    $thumbsArr = array();
    //remove from array
    if( count($allThumbsArr) > get_site_option( 'tubeace_'.$site.'_'.$import_type.'_num_thumbs' ) ){
        for( $i=0; get_site_option( 'tubeace_'.$site.'_'.$import_type.'_num_thumbs' ) > $i ; $i++ ){
            $thumbsArr[] = $allThumbsArr[$i];
        }
    } else { // keep all
      $thumbsArr = $allThumbsArr;
    }

    return $thumbsArr;
}



// this function is only called when saving rotating thumbs, using preselected default thumb to return $def_thmb
function tubeace_detect_def_thmb($site, $featured_img, $thumbsArr, $import_type){

  if($site=='pornhub'){

    // get $def_thmb by matching thumb in src and getting key (and incrementing 1) from array of objects
    $neededObject = array_filter(
        $thumbsArr,
        function ($e) use (&$featured_img) {
            return $e->src == $featured_img;
        }
    );    

    $def_thmb = key($neededObject);
    $def_thmb++;
  }

  if($site=='redtube'){

    // get $def_thmb by matching thumb in src and getting key (and incrementing 1) from array of objects
    $neededObject = array_filter(
        $thumbsArr,
        function ($e) use (&$featured_img) {
            return $e->src == $featured_img;
        }
    );

    // get key by matching in array
    $def_thmb = key($neededObject);
    $def_thmb++;
  }

  if($site=='tube8'){

    // default thumb URL naming convention changed (not rotating thumbs?), there are (at least) 2 possible naming conventions. 
    // Older filenames such as https://ei1.t8cdn.com/201612/13/33916881/originals/12(m=eWdTmgaaaa).jpg
    // and newer filenames such as https://ei1.t8cdn.com/201711/17/41604651/240x180/6.jpg    

    // try newer filename type first, if we don't extract a number, try for older filename
    // tube8 uses protocol-relative URLs in thumbs array, so let's strip the https
    $featured_img = str_replace('https:', '', $featured_img);

    // get key by matching in array
    $def_thmb = array_search($featured_img , $thumbsArr);
    $def_thmb++;

    // if no match, must be older filename
    if( empty($def_thmb) ){

      // get filename without extension
      $filename = basename($featured_img, ".jpg");

      // remove parenthesis and text between
      $def_thmb = preg_replace("/\([^)]+\)/","",$filename);
    }
  }  

  if($site=='youporn'){

    // thumb URL naming convention changed, there are (at least) 2 possible naming conventions. 
    // Older filenames such as https://di1-ph.ypncdn.com/videos/201810/28/189450851/original/(m=eqgl9daaaa)(mh=9CQfp1yRNfbceasV)8.jpg
    // and newer filenames such as https://di1.ypncdn.com/m=eSuQKgaaaa/201901/10/15109495/original/3/fucking-my-dirty-boss-for-a-promotion-3.jpg

    // try newer filename type first, if we don't extract a number, try for older filename
    // get filename without extension
    $filename = basename($featured_img, ".jpg");

    // basenames are as cum-in-high-heels-1.jpg so explode and get last element in array
    $def_thmb = end(explode('-', $filename));

    // if not an integer, must be older filename
    if( !is_numeric($def_thmb) ){

      // remove parenthesis and text between
      $def_thmb = preg_replace("/\([^)]+\)/","",$filename);
    }
  }  

  if($site=='xhamster'){

    // ex. thumb URL http://thumb-v2.xhcdn.com/a/gqL0YnlqLa0l_1K6k_fldQ/010/871/542/320x240.10.jpg

    // get filename without extension
    $filename = basename($featured_img, ".jpg");

    // explode and get 
    $def_thmb = end(explode('.', $filename));
  }

  return $def_thmb;
}

// called when using default as thumbnail and rotating thumbs
function tubeace_verify_featured_img_in_thumb_array($site, $featured_img, $thumbsArr){

  if($site=='pornhub'){

    $neededObject = array_filter(
        $thumbsArr,
        function ($e) use (&$featured_img) {
            return $e->src == $featured_img;
        }
    );    

    if( !empty( $neededObject ) ){
      return true;
    } 
  }  

  if($site=='redtube'){

    // get filename without extension
    $thumb_num = basename($featured_img, ".jpg");

    // if $thumbsArr count is greater than or equal to the thumbnail number, it must be in array
    if( count($thumbsArr) >= $thumb_num ){
      return true;
    }

  }  

  if($site=='tube8'){  
    // default thumb URL naming convention changed (not rotating thumbs?), there are (at least) 2 possible naming conventions. 
    // Older filenames such as https://ei1.t8cdn.com/201612/13/33916881/originals/12(m=eWdTmgaaaa).jpg
    // and newer filenames such as https://ei1.t8cdn.com/201711/17/41604651/240x180/6.jpg


    // try newer filename type first, if we don't extract a number, try for older filename
    // get filename without extension
    $thumb_num = basename($featured_img, ".jpg");

    // if not an integer, must be older filename
    if( !is_numeric($thumb_num) ){

      // remove parenthesis and text between
      $thumb_num = preg_replace("/\([^)]+\)/","",$thumb_num);
    }

    // if $thumbsArr count is greater than or equal to the thumbnail number, it must be in array
    if( count($thumbsArr) >= $thumb_num ){
      return true;
    }


  }

  if($site=='youporn'){  

    $neededObject = array_filter(
        $thumbsArr,
        function ($e) use (&$featured_img) {
            return $e->src == $featured_img;
        }
    );    

    if( !empty( $neededObject ) ){
      return true;
    } 

  }
}



// redtube and youporn do not return default thumb with specifeid size so we must get filename and match in thumbs array to get desired size thumbnail.
function tubeace_get_default_thumb_url($site, $specified_def_thumb, $thumbsArr){

  if($site=='redtube'){

    // Redtube does not return default thumb with specifeid size so we must get filename and match in thumbs array.

    // get filename without extension
    $thumb_num = basename($specified_def_thumb, ".jpg");

    // filename may contain parenthesis with text between
    $thumb_num = str_replace('-', '', $thumb_num);// remove hyphen
    $thumb_num = str_replace('=', '', $thumb_num);// removeequal sign

    $thumb_num = preg_replace("/\([^)-]+\)/","",$thumb_num);

    // use default # if $thumb_num = 0
    if( $thumb_num == 0 ){

      $element =  $thumbsArr[(get_site_option( 'tubeace_redtube_api_def_thumb' )-1)];
      return $element->src;
    }

    $element = $thumbsArr[($thumb_num-1)];

    $featured_img = $element->src;
 
    return $featured_img;
  }

  if($site=='youporn'){

    // youporn does not return default thumb with specifeid size so we must get filename and match in thumbs array.
    // thumb URL naming convention changed, there are (at least) 2 possible naming convention. Older filenames such as https://di1-ph.ypncdn.com/videos/201810/28/189450851/original/(m=eqgl9daaaa)(mh=9CQfp1yRNfbceasV)8.jpg
    // and newer filenames such as https://di1.ypncdn.com/m=eSuQKgaaaa/201901/10/15109495/original/3/fucking-my-dirty-boss-for-a-promotion-3.jpg


    // https://di1.ypncdn.com/m=eSuQKgaaaa/201901/10/15109495/original/3/fucking-my-dirty-boss-for-a-promotion-3.jpg
    $filename = basename($specified_def_thumb, ".jpg");
    // if last char is number

    // test 1
    // fucking-my-dirty-boss-for-a-promotion-3.jpg
    $last_chars = preg_replace("/\([^)]+\)/","",$filename);    
    $last_chars = substr($last_chars, -2);
    $last_chars = preg_replace('~\D~', '', $last_chars); // remove non digits

    // test 2
    // 8(m=eSuQKgaaaa)(mh=CLWfV_WZQzx7lm_L)    
    $filename = preg_replace("/\([^)]+\)/","",$filename);    

    // test 3
    // 8(m=eSuQKgaaaa)(mh=h85C4Oavv0-Gr2Rx) w/ hyphen    
    $thumb_num = str_replace('-', '', $filename); // remve hypen from inside parentesis
    $thumb_num = preg_replace("/\([^)]+\)/","",$thumb_num);       

    //test 4
    // romi-rain-big-ass-big-tits-masturbating-until-massive-wet-orgasm-5(m=eSuQKgaaaa)
    $thumb_num = str_replace('-', '', $filename); // remve hypen from inside parentesis
    $thumb_num = preg_replace("/\([^)]+\)/","",$thumb_num);       
    
    $arr = explode("-", $thumb_num);
    $stripped_long = end($arr);

    $stripped_long = substr($filename, -2);
    $stripped_long = preg_replace('~\D~', '', $stripped_long); // remove non digits    

    // match
    if( is_numeric($last_chars) ){

      $thumb_num = $last_chars;
      //echo'<br>done1';

    } elseif( is_numeric($filename) ) {

      $thumb_num = $filename;
      //echo'<br>done2';
    } elseif( is_numeric($thumb_num) ) {

      $thumb_num = $thumb_num;
      //echo'<br>done3';
    } elseif( is_numeric($stripped_long) ) {

      $thumb_num = $stripped_long;
      //echo'<br>done4';
    } else {

      $thumb_num = 9; // will be 8
      //echo'<br>done gave up';
    }

    if( $thumb_num == 0){
      $thumb_num = 9; // will be 8
    }

    $element = $thumbsArr[($thumb_num-1)];

    $featured_img = $element->src;

    return $featured_img;
  }

}

// first thumbnail URL is default thumb in semicolon-separated string. this function sorts the thumbnails in numerical order.
function tubeace_sort_xhamster_thumbs($thumbs_str){

  $allThumbsArr = explode(';', $thumbs_str);

  // first thumb is default
  $basenamesArr = array();
  // get basenames
  foreach ($allThumbsArr as $value) {

    $basenamesArr[] = basename($value);
  }

  //sort numerically
  natsort($basenamesArr);

  $i=0;
  $total_thumbs = count($basenamesArr);
  $sortedThumbsArr = array();
  // build array with full thumb URLs by matching basenames
  foreach ($basenamesArr as $value) {

    // match basename with full URL
    for($b=0;$b<$total_thumbs;$b++){

      if(strpos($allThumbsArr[$b], $value)!== false){
        $sortedThumbsArr[] = $allThumbsArr[$b];
        break;
      }
    }
    $i++;
  }

  return $sortedThumbsArr;
}


function tubeace_get_the_post_data($field){

  $return_field = null;

  if( isset($_POST[$field]) ){
    $return_field = $_POST[$field];
  }
  
  return $return_field;
}

function tubeace_get_post_data($field){

  $return_field = null;

  if( isset($_POST[$field]) ){
    $return_field = $_POST[$field];
    $return_field = stripcslashes($return_field);
  }
  
  return $return_field;
}

// clean up CSV for Mass import tool
function tubeace_prepare_csv_data($data){

    // remove escaped double quotes (escaped with another doublequote)
    $data = str_replace('""','"', $data);

    // trim double quotes from fields
    $data = trim($data, "\"");

    // last field with new line character on end not trimmed, do that now
    $data = str_replace("\"\n","\n", $data);

    // carriage return
    $data = str_replace("\"\r","\r", $data);

    return $data;
}

function tubeace_sponsor_link(){

  $sponsor_link_url = get_post_meta( get_the_ID(),'sponsor_link_url',true);
  $sponsor_link_txt = get_post_meta( get_the_ID(),'sponsor_link_txt',true);

  $sponsor_link = null;
  
  if( !empty($sponsor_link_url) && !empty($sponsor_link_txt) ){
    $sponsor_link = "<h3><a class=\"sponsor_link\" href=\"$sponsor_link_url\">$sponsor_link_txt</a></h3>";
  }

  echo $sponsor_link;
}

function tubeace_misc($id){

  $misc = get_post_meta( get_the_ID(),"misc$id",true);
  echo $misc;
}

?>