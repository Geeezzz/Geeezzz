<div class="wrap">
	<h3><?php echo $siteArray['site_name'] ?> Auto-Import Cron Jobs</h3>
	
	<table class="widefat striped" cellspacing="0">
	  <thead>
			<tr>
				<th class="manage-column column-cb check-column"></th>
				<th>Frequency</th>
				<th>Name</th>

				<th>Keyword</th>
				<th>Tag</th>
				<th>Start Page</th>
				<th>End Page</th>

				<th>Ordering</th>

				<th>Min Rating</th>
				<th>Min # Ratings</th>
				
				<th>Status</th>
				<th>Category</th>
				<th>Running</th>
				<th>Started</th>
				<th>Last Page</th>
				<th>Completed</th>				
			</tr>
		</thead>
		<tbody>

			<?php
			tubeace_show_cron_jobs($siteArray['site'], 'hourly', $deleted_cron_names);
			tubeace_show_cron_jobs($siteArray['site'], 'twicedaily', $deleted_cron_names);
			tubeace_show_cron_jobs($siteArray['site'], 'daily',  $deleted_cron_names);
			?>
	  	</tbody>
	</table>
	<input type="submit" value="Delete Selected" class="button action" name="delete">
	
</div>