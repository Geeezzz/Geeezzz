<tr>
  <th>Select categories</th>
  <td><div id="xham_cats" style="max-height: 400px;width: 400px;overflow: scroll;">

    <?php
    $categoriesArr = tubeace_api_export_categories_array('xhamster');

    foreach($categoriesArr as $key => $val){

        if( in_array($key, $option_values['cats'])){
            $cat_checked = 'checked="checked"';
        } else {
            $cat_checked = '';
        }

        echo '<input type="checkbox" class="xham_cats_chkbxs" id="cats_'.$key.'" name="cats[]" value="'.$key.'" '.$cat_checked.'> <label for="cats_'.$key.'">'.$val.'</label><br>';
    }
    ?></div>

    <br><a href ='#' id="xham_select_all_cats">Select All</a>
    <br><a href ='#' id="xham_unselect_all_cats">Unselect All</a>
  </td>
</tr>

<tr>
  <th><label for="cnt"># of Videos to Import</label></th>
  <td>

    <?php 
    if($option_values['cnt']==0){
      $sel_cnt_0 = 'selected = "selected"';
    }
    if($option_values['cnt']==1){
      $sel_cnt_1 = 'selected = "selected"';
    }
    if($option_values['cnt']==2){
      $sel_cnt_2 = 'selected = "selected"';
    }
    if($option_values['cnt']==3){
      $sel_cnt_3 = 'selected = "selected"';
    }
    if($option_values['cnt']==4){
      $sel_cnt_4 = 'selected = "selected"';
    }
    if($option_values['cnt']==5){
      $sel_cnt_5 = 'selected = "selected"';
    }        
    ?>

    <select name="cnt" id="cnt">
      <option value="0" <?php echo $sel_cnt_0?>>100</option>
      <option value="1" <?php echo $sel_cnt_1?>>500</option>
      <option value="2" <?php echo $sel_cnt_2?>>1000</option>
      <option value="3" <?php echo $sel_cnt_3?>>5000</option>
      <option value="4" <?php echo $sel_cnt_4?>>10000</option>
      <option value="5" <?php echo $sel_cnt_5?>>50000</option>

    </select>
  </td>
</tr>

<tr>
  <th><label for="resolution">Video Resolution</label></th>
  <td>

    <?php 
    if($option_values['resolution']==0){
      $sel_resolution_0 = 'selected = "selected"';
    }
    if($option_values['resolution']==1){
      $sel_resolution_1 = 'selected = "selected"';
    }    
    ?>
    <select name="resolution" id="resolution">
      <option value="0" <?php echo $sel_resolution_0?>>All</option>
      <option value="1" <?php echo $sel_resolution_1?>>HD</option>
    </select>
  </td>
</tr>

<tr>
  <th><label for="period">Period</label></th>
  <td>

    <?php 
    if($option_values['period']==0){
      $sel_period_0 = 'selected = "selected"';
    }
    if($option_values['period']==1){
      $sel_period_1 = 'selected = "selected"';
    }
    if($option_values['period']==2){
      $sel_period_2 = 'selected = "selected"';
    }
    if($option_values['period']==3){
      $sel_period_3 = 'selected = "selected"';
    }       
    ?>
    <select name="period" id="period">
      <option value="0" <?php echo $sel_period_0?>>Any Time</option>
      <option value="1" <?php echo $sel_period_1?>>Last day (1 Day)</option>
      <option value="2" <?php echo $sel_period_2?>>Last week (7 Days)</option>
      <option value="3" <?php echo $sel_period_3?>>Last month (30 Days)</option>
    </select>
  </td>
</tr>

<tr>
  <th><label for="orderby">Order By</label></th>
  <td>

    <?php 
    if($option_values['orderby']==0){
      $sel_orderby_0 = 'selected = "selected"';
    }
    if($option_values['orderby']==1){
      $sel_orderby_1 = 'selected = "selected"';
    }
    if($option_values['orderby']==2){
      $sel_orderby_2 = 'selected = "selected"';
    }       
    ?>    
    <select name="orderby" id="orderby">
      <option value="0" <?php echo $sel_orderby_0?>>Added Time</option>
      <option value="1" <?php echo $sel_orderby_1?>>Rating</option>
      <option value="2" <?php echo $sel_orderby_2?>>Videos Count</option>
    </select>
  </td>
</tr>

<tr>
  <th><label for="rating_min">Rating more than</label></th>
  <td>

    <?php 
    if($option_values['rating_min']==0){
      $sel_rating_min_0 = 'selected = "selected"';
    }
    if($option_values['rating_min']==1){
      $sel_rating_min_1 = 'selected = "selected"';
    }
    if($option_values['rating_min']==2){
      $sel_rating_min_2 = 'selected = "selected"';
    }
    if($option_values['rating_min']==3){
      $sel_rating_min_3 = 'selected = "selected"';
    }        
    ?>      
    <select name="rating_min" id="rating_min">
      <option value="0" <?php echo $sel_rating_min_0?>>0%</option>
      <option value="1" <?php echo $sel_rating_min_1?>>40%</option>
      <option value="2" <?php echo $sel_rating_min_2?>>60%</option>
      <option value="3" <?php echo $sel_rating_min_3?>>80%</option>
    </select>
  </td>
</tr>

<tr>
  <th><label for="views_min">Views more than</label></th>
  <td>

    <?php 
    if($option_values['views_min']==0){
      $sel_views_min_0 = 'selected = "selected"';
    }
    if($option_values['views_min']==1){
      $sel_views_min_1 = 'selected = "selected"';
    }
    if($option_values['views_min']==2){
      $sel_views_min_2 = 'selected = "selected"';
    }
    if($option_values['views_min']==3){
      $sel_views_min_3 = 'selected = "selected"';
    }        
    ?>       
    <select name="views_min" id="views_min">
      <option value="0" <?php echo $sel_views_min_0?>>Any</option>
      <option value="1" <?php echo $sel_views_min_1?>>1000</option>
      <option value="2" <?php echo $sel_views_min_2?>>5000</option>
      <option value="3" <?php echo $sel_views_min_3?>>10000</option>
    </select>
  </td>
</tr>


