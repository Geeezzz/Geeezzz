<?php

$cron_id = $option_values['cron_id'];

// hubtraffic
$tag = $option_values['tag'];
$keyword = $option_values['keyword'];

$start = $option_values['start'];
$end = $option_values['end'];

$ordering = $option_values['ordering'];

// xhamster
$cats = $option_values['cats'];
$cnt = $option_values['cnt'];
$resolution = $option_values['resolution'];
$period = $option_values['period'];
$orderby = $option_values['orderby'];
$rating_min = $option_values['rating_min'];
$views_min = $option_values['views_min'];

$ratings_num_min = $option_values['ratings_num_min'];

$status = $option_values['status'];
$sponsor = $option_values['sponsor'];
$post_date = $option_values['post_date'];
$post_category = $option_values['post_category'];

$description = $option_values['description'];
$tags_set_all = $option_values['tags'];
$tags_method = $option_values['tags_method'];
$performers_set_all = $option_values['performers'];
$performers_method = $option_values['performers_method'];
$sponsor_link_txt = $option_values['sponsor_link_txt'];
$sponsor_link_url = $option_values['sponsor_link_url'];
$misc1 = $option_values['misc1'];
$misc2 = $option_values['misc2'];
$misc3 = $option_values['misc3'];
$misc4 = $option_values['misc4'];
$misc5 = $option_values['misc5'];


$running = isset($option_values['running']) ? $option_values['running'] : '';
$running_start_timestamp = isset($option_values['running_start_timestamp']) ? $option_values['running_start_timestamp'] : '';
$running_last_page_timestamp = isset($option_values['running_last_page_timestamp']) ? $option_values['running_last_page_timestamp'] : '';
$running_completition_timestamp = isset($option_values['running_completition_timestamp']) ? $option_values['running_completition_timestamp'] : '';
$running_current_page = isset($option_values['running_current_page']) ? $option_values['running_current_page'] : '';
