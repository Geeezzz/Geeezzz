<?php

if( isset($_POST['Submit']) ){

	$current_frequency = $_POST['current_frequency'];

	$cron_name = $_POST['cron_name'];
	$cron_frequency = $_POST['cron_frequency'];
	$cron_id = $_POST['cron_id'];	
	$running = $_POST['running'];

	$running_current_page = isset($_POST['running_current_page']) ? $_POST['running_current_page'] : '';
	$running_start_timestamp = isset($_POST['running_start_timestamp']) ? $_POST['running_start_timestamp'] : '';
	$running_last_page_timestamp = isset($_POST['running_last_page_timestamp']) ? $_POST['running_last_page_timestamp'] : '';
	$running_completition_timestamp = isset($_POST['running_completition_timestamp']) ? $_POST['running_completition_timestamp'] : '';


	// hubtraffic
	$tag = $_POST['tag'];
	$keyword = $_POST['keyword'];
	
	$start = $_POST['start'];
	$end = $_POST['end'];

	$ordering = $_POST['ordering'];

	// xhamster
	$cats = isset($_POST['cats']) ? $_POST['cats'] : '';
	$cnt = isset($_POST['cnt']) ? $_POST['cnt'] : '';
	$resolution = isset($_POST['resolution']) ? $_POST['resolution'] : '';
	$period = isset($_POST['period']) ? $_POST['period'] : '';
	$orderby = isset($_POST['orderby']) ? $_POST['orderby'] : '';
	$rating_min = isset($_POST['rating_min']) ? $_POST['rating_min'] : '';
	$views_min = isset($_POST['views_min']) ? $_POST['views_min'] : '';

	$ratings_num_min = isset($_POST['ratings_num_min']) ? $_POST['ratings_num_min'] : '';

	$status = $_POST['status'];
	$sponsor = $_POST['sponsor'];
	$post_date = $_POST['post_date'];
	$post_category = (isset($_POST['post_category'])) ? $_POST['post_category'] : null;
	
	$description = $_POST['description'];
	$tags = $_POST['tags'];
	$tags_method = $_POST['tags_method'];
	$performers = $_POST['performers'];
	$performers_method = $_POST['performers_method'];
	$sponsor_link_txt = $_POST['sponsor_link_txt'];
	$sponsor_link_url = $_POST['sponsor_link_url'];
	$misc1 = $_POST['misc1'];
	$misc2 = $_POST['misc2'];
	$misc3 = $_POST['misc3'];
	$misc4 = $_POST['misc4'];
	$misc5 = $_POST['misc5'];
	$misc5 = $_POST['misc5'];

	$error = false;

	//if frequency changed
	if($current_frequency != $cron_frequency){

		//check name not already used for new frequency
		$newCronNames = get_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_frequency);
		
		if(@in_array($cron_name,$newCronNames)){
			echo'<div class="error"><p><b>Cron name \''.$cron_name.'\' already used for '.tubeace_cron_frequency_label($cron_frequency).' frequency. You must delete the other auto-import job first.</b></p></div>';

			$error = true;

		} else {

			//remove from current tubeace_cron_{frequency} options array
			//note: if single name, its not an array
			$existingCronNames = get_site_option('tubeace_cron_'.$siteArray['site'].'_'.$current_frequency);

			//if multiple cron job names, remove current name from option, enter into new option
			if(count($existingCronNames)>1){

				$existingCronNames = array_diff($existingCronNames, array($cron_name));

				update_site_option("tubeace_cron_".$siteArray['site']."_".$current_frequency, $existingCronNames);
			
			} else { //only one name, delete from options and deactivate group cron hook

				//delete empty group option_name
				$wpdb->delete( $wpdb->prefix.'options', array( 'option_name' => 'tubeace_cron_'.$siteArray['site'].'_'.$current_frequency ) );

				//deactive old frequency if none remaining in group
				wp_clear_scheduled_hook( "tubeace_".$current_frequency );
			}

			//delete old set all's option_name
			$wpdb->delete( $wpdb->prefix.'options', array( 'option_name' => 'tubeace_cron_'.$siteArray['site'].'_'.$cron_name.'_'.$current_frequency ) );

			//create new frequency group, or add to existing
			//already exists add to it
			if(!empty($newCronNames)){
				$name_arr = array($cron_name);
				$newCronNames = array_merge($newCronNames,$name_arr);

			} else { // doesn't exist create it

				$newCronNames = array($cron_name);
			}

			update_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_frequency, $newCronNames);

			//rename set all's option_name
			$wpdb->update( 'options', array('option_name' => 'tubeace_cron_'.$siteArray['site'].'_'.$cron_name."_".$cron_frequency ), array('option_name' => 'tubeace_cron_'.$siteArray['site'].'_'.$cron_name.'_'.$current_frequency) );

			//activate new frequency 
			if ( ! wp_next_scheduled( 'tubeace_'.$cron_frequency ) ) {
			  	wp_schedule_event( time(), $cron_frequency, 'tubeace_'.$cron_frequency );
			}
		}
	}

	if( !$error ){

		echo'<div class="updated"><p>Updated Auto-Import (Cron) Job <b>\''.$cron_name.'\'</b>.</p></div>';

		//assoc array of cron values to store in options
		$cronValues= array(

			'cron_id' => (int)$cron_id,

			'keyword' => $keyword,
			'tag' => $tag,
			'start' => $start,
			'end' => $end,
			
			'ordering' => $ordering,

			'cats' => $cats,
			'cnt' => $cnt,
			'resolution' => $resolution,
			'period' => $period,
			'orderby' => $orderby,
			'rating_min' => $rating_min,
			'views_min' => $views_min,
			
			'ratings_num_min' => $ratings_num_min,

			'status' => $status,
			'sponsor' => $sponsor,
			'post_date' => $post_date,
			'post_category' => $post_category,
			'description' => $description,
			'tags' => $tags,
			'tags_method' => $tags_method,
			'performers' => $performers,
			'performers_method' => $performers_method,
			'sponsor_link_txt' => $sponsor_link_txt,
			'sponsor_link_url' => $sponsor_link_url,
			'misc1' => $misc1,
			'misc2' => $misc2,
			'misc3' => $misc3,
			'misc4' => $misc4,
			'misc5' => $misc5,
			'running' => $running,
			'running_current_page' => $running_current_page,
			'running_start_timestamp' => $running_start_timestamp,
			'running_last_page_timestamp' => $running_last_page_timestamp,
			'running_completition_timestamp' => $running_completition_timestamp
		);

		//update (or possibly create new option, check to delete old below) 
		update_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_name."_".$cron_frequency, $cronValues);
	}

} else {

	$cron_name = $_GET['name'];
	$cron_frequency = $_GET['freq'];
}

// get values to populate form
$option_values = get_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_name.'_'.$cron_frequency);

?>

<div class="wrap">
	<h2>Edit <?php echo $siteArray['site_name'] ?> Auto-Import (Cron) Job</h2>
	<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-cron.php&site='.$siteArray['site'].'&edit=1'); ?>" method="POST">
		<table class="form-table">
	    <tbody>
	      <tr>
	    		<th><label for="cron_name">Name</label></th>
	        <td>
	        	<?php echo $cron_name ?>
	        </td>
	      </tr>
	      <tr>
	    		<th><label for="cron_frequency">Frequency</label></th>
	      	<td>
        		<?php 

        			$sel_hourly = null;
        			$sel_twicedaily = null;
        			$sel_daily = null;

	    			if($cron_frequency=='hourly'){
	    				$sel_hourly = 'selected = "selected"';
	    			}
	    			if($cron_frequency=='twicedaily'){
	    				$sel_twicedaily = 'selected = "selected"';
	    			}
	    			if($cron_frequency=='daily'){
	    				$sel_daily = 'selected = "selected"';
	    			}
        		?>
					  <select name="cron_frequency" id="cron_frequency">
							<option value="hourly" <?php echo $sel_hourly?>>Hourly</option>
							<option value="twicedaily" <?php echo $sel_twicedaily?>>Twice Daily</option>
							<option value="daily" <?php echo $sel_daily?>>Daily</option>
					  </select>
	        </td>		        	
	      </tr>
	      <tr>
	    		<th><label for="running">Status</label></th>
	      	<td>
        		<?php 

        			$sel_not_running = null;
        			$sel_running = null;

	    			if($option_values['running']==0){
	    				$sel_not_running = 'selected = "selected"';
	    			}
	    			if($option_values['running']==1){
	    				$sel_running = 'selected = "selected"';
	    			}
        		?>
					  <select name="running" id="running">
							<option value="0" <?php echo $sel_not_running?>>Not Running</option>
							<option value="1" <?php echo $sel_running?>>Running</option>
					  </select> A cron job cannot start running if already running.
	        </td>		        	
	      </tr>

	      <?php

	      	if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn' ){	
	      		include('cron-edit-hubtraffic.php');
	      	}

			if( $siteArray['site']=='xhamster' ){
				include('cron-edit-xhamster.php');
			}

	      ?>

		  </tbody>
		</table>

		<div class="tubeace-set-alls-form">
			<h3>SET ALL Values</h3>
			<table class="form-table">
			  <tbody>
			    <tr>
			    	<th><label for="status">Status</label></th>
			      <td>
		        	<?php 
		        		$status = $option_values['status'];

		        		$sel_publish = $sel_pending = $sel_draft = $sel_future = $sel_private = null;

		    			if($status=='publish'){
		    				$sel_publish = 'selected = "selected"';
		    			}
		    			if($status=='pending'){
		    				$sel_pending = 'selected = "selected"';
		    			}
		    			if($status=='draft'){
		    				$sel_draft = 'selected = "selected"';
		    			}
		    			if($status=='future'){
		    				$sel_future = 'selected = "selected"';
		    			}
		    			if($status=='private'){
		    				$sel_private = 'selected = "selected"';
		    			} 
		        	?>
					<select name="status" id="status">
						<option value="publish" <?php echo $sel_publish?>>Publish</option>
						<option value="pending" <?php echo $sel_pending?>>Pending</option>
						<option value="draft" <?php echo $sel_draft?>>Draft</option>
						<option value="future" <?php echo $sel_future?>>Future</option>
						<option value="private" <?php echo $sel_private?>>Private</option>
			 		</select>
			      </td>		        	
			    </tr>
			    <tr>
			    	<th><label for="sponsor">Author / Sponsor</label></th>
			      <td>
							<select name="sponsor" id="sponsor">
								<?php tubeace_get_users_with_role(array('Contributor','Administrator'), $option_values['sponsor']); ?>
							</select>
							<small>To add a sponsor, <a href="user-new.php">add a new user</a> with a "Contributor" Role.</small>
			      </td>
			    </tr>	        
	        <tr>
		    	<th><label for="post_date">Post Date</label></th>
		        <td>
		        	<input name="post_date" type="text" class="tubeace-input-160" id="post_date" value="<?php echo $option_values['post_date']; ?>">
		        </td>
	        </tr>
	        <tr>
	    		<th><label for="start">Category</label></th>
	        	<td>
					<ul id="categorychecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
				  	<?php wp_category_checklist( 0,0,$option_values['post_category']); ?>
					</ul> 		        		
	        	</td>		        	
	        </tr>
	        <tr>
		    	<th><label for="description">Description</label></th>
	        	<td>
	        		<textarea name="description" class="tubeace-input-320" id="description"><?php echo $option_values['description'] ?></textarea>
	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="tags">Tags</label></th>
	        	<td>
	        		<input name="tags" type="text" class="tubeace-input-320" id="tags" value="<?php echo $option_values['tags'] ?>">
	        		<small>Separate multiple tags by comma.</small>
	        		<br>	        		

	        		<?php

	        		$tags_method = $option_values['tags_method'];

	        		$sel_merge_tags_y_setall = $sel_only_channels_as_tags = $sel_only_tags = $sel_merge_channels_as_tags_y_tags_y_setall = $sel_setall = null;

	        		if($tags_method=='merge_tags_y_setall'){
	        			$sel_merge_tags_y_setall = 'selected = "selected"';
	        		}

	        		if($tags_method=='only_channels_as_tags'){
	        			$sel_only_channels_as_tags = 'selected = "selected"';
	        		}		 

	        		if($tags_method=='only_tags'){
	        			$sel_only_tags = 'selected = "selected"';
	        		}	

	        		if($tags_method=='merge_channels_as_tags_y_tags_y_setall'){
	        			$sel_merge_channels_as_tags_y_tags_y_setall = 'selected = "selected"';
	        		}

	        		if($tags_method=='setall'){
	        			$sel_setall = 'selected = "selected"';
	        		}		        		

        			// if only tags
        			if( $siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='youporn' ){
        				?>
		        		<select name="tags_method">
		        			<option value="merge_tags_y_setall" <?php echo $sel_merge_tags_y_setall?>>Merge Imported Tags with Set All</option>
		        			<option value="setall" <?php echo $sel_setall?>>Use only Set All Value</option>
		        		</select>
		        		<?php			
        			}

        			// if both tags and channels 
        			if($siteArray['site']=='tube8' ){
        				?>
		        		<select name="tags_method">
		        			<option value="only_channels_as_tags" <?php echo $sel_only_channels_as_tags?>>Import only Channels as Tags</option>
		        			<option value="only_tags" <?php echo $sel_only_tags?>>Import only Tags</option>
		        			<option value="merge_tags_y_setall" <?php echo $sel_merge_tags_y_setall?>>Merge Imported Tags with Set All</option>
		        			<option value="merge_channels_as_tags_y_tags_y_setall" <?php echo $merge_channels_as_tags_y_tags_y_setall?>>Import Channels as Tags, Import Tags, and Merge with Set All</option>
		        			<option value="setall" <?php echo $sel_setall?>>Use only Set All Value</option>
		        		</select>
		        		<?php
        			}
	        		?>

	        	</td>		        	
	        </tr>	  

	        <tr>
	    		<th><label for="performers">Performers</label></th>
	        	<td>
	        		<input name="performers" type="text" class="tubeace-input-320" id="performers" value="<?php echo $option_values['performers'] ?>">
	        		<small>Separate multiple tags by comma.</small>
	        		<br>	        		 

					<?php

					$performers_method = $option_values['performers_method'];

					$sel_perf_merge = $sel_perf_overwrite = null;

	    			if($performers_method=='merge'){
	    				$sel_perf_merge = 'selected = "selected"';
	    			}
	    			if($performers_method=='setall'){
	    				$sel_perf_overwrite = 'selected = "selected"';
	    			}					

        			// these have performer value possibility, show option
        			if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='youporn'){
        				?>
		        		<select name="performers_method">
		        			<option value="merge" <?php echo $sel_perf_merge?>>Merge Imported Performers with Set All</option>
		        			<option value="setall" <?php echo $sel_perf_overwrite?>>Use only Set All Value</option>
		        		</select>	
		        		<?php	        				
        			}
					?>	

	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="sponsor_link_txt">Sponsor Link Anchor Text</label></th>
	        	<td>
	        		<input name="sponsor_link_txt" type="text" class="tubeace-input-320" id="sponsor_link_txt" value="<?php echo $option_values['sponsor_link_txt'] ?>">
	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="sponsor_link_url">Sponsor Link URL</label></th>
	        	<td>
	        		<input name="sponsor_link_url" type="text" class="tubeace-input-320" id="sponsor_link_url" value="<?php echo $option_values['sponsor_link_url'] ?>">
	        	</td>		        	
	        </tr>		
	        <tr>
	    		<th><label for="misc1">Misc 1</label></th>
	        	<td>
	        		<textarea name="misc1" class="tubeace-input-320" id="misc1"><?php echo $option_values['misc1'] ?></textarea>
	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="misc2">Misc 2</label></th>
	        	<td>
	        		<textarea name="misc2" class="tubeace-input-320" id="misc2"><?php echo $option_values['misc2'] ?></textarea>
	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="misc3">Misc 3</label></th>
	        	<td>
	        		<textarea name="misc3" class="tubeace-input-320" id="misc3"><?php echo $option_values['misc3'] ?></textarea>
	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="misc4">Misc 4</label></th>
	        	<td>
	        		<textarea name="misc4" class="tubeace-input-320" id="misc4"><?php echo $option_values['misc4'] ?></textarea>
	        	</td>		        	
	        </tr>
	        <tr>
	    		<th><label for="misc5">Misc 5</label></th>
	        	<td>
	        		<textarea name="misc5" class="tubeace-input-320" id="misc5"><?php echo $option_values['misc5'] ?></textarea>
	        	</td>
	        </tr>        
			  </tbody>
			</table>
		</div>
		<input type="hidden" name="cron_name" value="<?php echo $cron_name; ?>">
		<input type="hidden" name="current_frequency" value="<?php echo $cron_frequency; ?>">
		<input type="hidden" name="cron_id" value="<?php echo $option_values['cron_id']; ?>">
		<input type="hidden" name="running_start_timestamp" value="<?php echo $option_values['running_start_timestamp']; ?>">
		<input type="hidden" name="running_last_page_timestamp" value="<?php echo $option_values['running_last_page_timestamp']; ?>">
		<input type="hidden" name="running_completition_timestamp" value="<?php echo $option_values['running_completition_timestamp']; ?>">
		<input type="submit" value="Save Changes" class="button-primary" name="Submit">	
	</form>
</div>