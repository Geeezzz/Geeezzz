<?php 

//since get_option() is cached make an array of deleted cron names so they don't still show in results after deleting
$deleted_cron_names = array();

$sites = array('redtube','pornhub','tube8','youporn','xhamster');

if(!empty($_POST['delete'])) {

	$total=0;
	foreach ($sites as $site) {

		$count = 0;
		$updated = '';

		$del = tubeace_get_the_post_data('del_'.$site);

		if (is_array($del) && count($del)>0 ) {

			$count = count( $del );
			$total = $total + $count;

			foreach( $del as $dels => $val) {

				// get name and frequency from $val
				//explode to make array
				$valArr = explode("-", $dels);

				// last in array is frequency
				$frequency = $valArr[2];

				$cron_name = $valArr[1];

				// replace hyphen back
				$cron_name = str_replace('.tahyphen.', '-', $cron_name);

				$deleted_cron_names[] = $dels;

				$updated.= '<p>Deleted <b>\''.$cron_name.'\' '.tubeace_cron_frequency_label($frequency).'</b> Auto-Import Job.</p>';

				//remove from frequency group
				//get option
				$existingCronNames = get_site_option('tubeace_cron_'.$site.'_'.$frequency, false, false);

				//if multiple cron job names, remove current name from option, enter into new option
				if(count($existingCronNames)>1){

					$updatedCronNames = array_diff($existingCronNames, array($cron_name));

					update_site_option('tubeace_cron_'.$site.'_'.$frequency, $updatedCronNames);
				
				} else { //only one name, delete from options and deactivate group cron hook

					//delete empty group option_name
					$wpdb->delete( $wpdb->prefix.'options', array( 'option_name' => 'tubeace_cron_'.$site.'_'.$frequency ) );

				}
				
				//delete set all values
				$wpdb->delete( $wpdb->prefix.'options', array( 'option_name' => 'tubeace_cron_'.$site.'_'.$cron_name."_".$frequency ) );

			}
		}

		if($count>0){
			$updated.= '<p>Deleted <b>'.$count.' '.$site.'</b> auto-import Cron Job(s).</b></p>';
		}

		//display updated for group
		if (is_array($del) && count($del)>0 ) {
			echo '<div class="updated">'.$updated.'</div>';
		}
	}

	if($total==0) {
		echo'<div class="error"><p><b>No auto-import cron jobs selected to delete.</b></p></div>';
	}

	// loop through frequencies to check to delete scheduled_hook if no longer needed
	$freq_array = array('hourly','twicedaily','daily');

	foreach ($freq_array as $frequency) {

		$match_option_val = '_'.$frequency;

		$mylink = $wpdb->get_row( "SELECT * FROM ".$wpdb->prefix."options WHERE option_name LIKE 'tubeace_cron%' AND option_name LIKE '%$match_option_val'" );

		if( empty( $mylink ) ){

			//deactive old frequency if none remaining in group
			wp_clear_scheduled_hook( 'tubeace_'.$frequency );
		}
	}
}
