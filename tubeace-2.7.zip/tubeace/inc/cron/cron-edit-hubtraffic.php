<tr>
    <th><label for="keyword">Keyword</label></th>
    <td>
      <input name="keyword" type="text" class="tubeace-input-320" id="keyword" value="<?php echo $option_values['keyword'] ?>">
    </td>		        	
</tr>
<tr>
	<th><label for="tag">Tag</label></th>
  <td>
  	<input name="tag" type="text" class="tubeace-input-320" id="tag" value="<?php echo $option_values['tag'] ?>">
  </td>		        	
</tr>		
<tr>
	<th><label for="start">Start Page</label></th>
  <td>
  	<input name="start" type="text" class="tubeace-input-60" id="start" value="<?php echo $option_values['start'] ?>">
  </td>		        	
</tr>
<tr>
		<th><label for="end">End Page</label></th>
  <td>
  	<input name="end" type="text" class="tubeace-input-60" id="end" value="<?php echo $option_values['end'] ?>">
  </td>		        	
</tr>



<tr>
    <th><label for="ordering">Ordering</label></th>
  <td>

  <?php 

  $ordering = $option_values['ordering'];

  if( $siteArray['site']=='pornhub' ){ 

      $sel_ph_featured = $sel_ph_newest = $sel_ph_mostviewed = $sel_ph_rating = null;

      if($ordering=='featured'){
        $sel_ph_featured = 'selected = "selected"';
      }
      if($ordering=='newest'){
        $sel_ph_newest = 'selected = "selected"';
      }
      if($ordering=='mostviewed'){
        $sel_ph_mostviewed = 'selected = "selected"';
      }
      if($ordering=='rating'){
        $sel_ph_rating = 'selected = "selected"';
      }

      ?>

    <select name="ordering" id="ordering">
      <option value="featured" <?php echo $sel_ph_featured?>>Featured</option>
      <option value="newest" <?php echo $sel_ph_newest?>>Newest</option>
      <option value="mostviewed" <?php echo $sel_ph_mostviewed?>>Most Viewed</option>
      <option value="rating" <?php echo $sel_ph_rating?>>Rating</option>
    </select>        

  <?php }

  if( $siteArray['site']=='redtube' ){ 

      $sel_rt_newest = $sel_rt_mostviewed = $sel_rt_rating = null;

      if($ordering=='newest'){
        $sel_rt_newest = 'selected = "selected"';
      }
      if($ordering=='mostviewed'){
        $sel_rt_mostviewed = 'selected = "selected"';
      }
      if($ordering=='rating'){
        $sel_rt_rating = 'selected = "selected"';
      }

      ?>

    <select name="ordering" id="ordering">
      <option value="newest" <?php echo $sel_rt_newest?>>Newest</option>
      <option value="mostviewed" <?php echo $sel_rt_mostviewed?>>Most Viewed</option>
      <option value="rating" <?php echo $sel_rt_rating?>>Rating</option>
    </select>        

  <?php } 

  if( $siteArray['site']=='tube8' ){ 

      $sel_t8_featured = $sel_t8_newest = $sel_t8_mostviewed = $sel_t8_rating = $sel_t8_favorites = $sel_t8_comments = $sel_t8_votes = $sel_t8_longest = null;

      if($ordering=='featured'){
        $sel_t8_featured = 'selected = "selected"';
      }
      if($ordering=='newest'){
        $sel_t8_newest = 'selected = "selected"';
      }      
      if($ordering=='mostviewed'){
        $sel_t8_mostviewed = 'selected = "selected"';
      }
      if($ordering=='rating'){
        $sel_t8_rating = 'selected = "selected"';
      }
      if($ordering=='favorites'){
        $sel_t8_favorites = 'selected = "selected"';
      }
      if($ordering=='comments'){
        $sel_t8_comments = 'selected = "selected"';
      }   
      if($ordering=='votes'){
        $sel_t8_votes = 'selected = "selected"';
      }
      if($ordering=='longest'){
        $sel_t8_longest = 'selected = "selected"';
      }             
      ?>

    <select name="ordering" id="ordering">
      <option value="featured" <?php echo $sel_t8_featured?>>Featured</option>
      <option value="newest" <?php echo $sel_t8_newest?>>Newest</option>
      <option value="mostviewed" <?php echo $sel_t8_mostviewed?>>Most Viewed</option>
      <option value="rating" <?php echo $sel_t8_rating?>>Rating</option>
      <option value="favorites" <?php echo $sel_t8_favorites?>>Favorites</option>
      <option value="comments" <?php echo $sel_t8_comments?>>Comments</option>
      <option value="votes" <?php echo $sel_t8_votes?>>Votes</option>
      <option value="longest" <?php echo $sel_t8_longest?>>Longest</option>
    </select>        

  <?php } 

  if( $siteArray['site']=='youporn' ){ 

      $sel_yp_newest = $sel_yp_mostviewed = $sel_yp_rating = null;

      if($ordering=='newest'){
        $sel_yp_newest = 'selected = "selected"';
      }      
      if($ordering=='mostviewed'){
        $sel_yp_mostviewed = 'selected = "selected"';
      }
      if($ordering=='rating'){
        $sel_yp_rating = 'selected = "selected"';
      }
      ?>

    <select name="ordering" id="ordering">
      <option value="newest" <?php echo $sel_yp_newest?>>Newest</option>
      <option value="mostviewed" <?php echo $sel_yp_mostviewed?>>Most Viewed</option>
      <option value="rating" <?php echo $sel_yp_rating?>>Rating</option>
    </select>        

  <?php } ?>


  </td>             
</tr>



<tr>
    <th><label for="rating_min">Minimum Rating</label></th>
  <td>
    <input name="rating_min" type="text" class="tubeace-input-40" id="rating_min" value="<?php echo $option_values['rating_min'] ?>">
    <small>1-100</small>
  </td>             
</tr>

<tr>
    <th><label for="ratings_num_min">Minimum Rating</label></th>
  <td>
    <input name="ratings_num_min" type="text" class="tubeace-input-60" id="ratings_num_min" value="<?php echo $option_values['ratings_num_min'] ?>">
  </td>             
</tr>