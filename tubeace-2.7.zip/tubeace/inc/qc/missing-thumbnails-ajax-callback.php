<?php

// The function that handles the AJAX request
function tubeace_missing_thumbnails_callback() {

    global $wpdb;
    check_ajax_referer( 'my-special-string', 'security' );

    $page = $_POST['page'];

    $report = '';

    //loops through all videos
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 100,
        'paged' => $page
    );

    $post_query = new WP_Query($args);

    if($post_query->have_posts() ) {
        while($post_query->have_posts() ) {
            $post_query->the_post();

            // reset
            $missing_thumb = '';

            // get the id
            $id = get_the_id();

            //loop through thumbs and check exist
            $num_thumbs = get_post_meta($id, 'saved_thmb', true);

            for($i=1;$i<=$num_thumbs;$i++){

                $subPath = tubeace_sub_dir_path($id);

                //create thumb dir
                $upload_dir = wp_upload_dir();
                $thumb_path = $upload_dir['basedir']."/tubeace-thumbs/".$subPath.'/'.$id.'_'.$i.'.jpg';

                if( !file_exists($thumb_path) ){
                    $missing_thumb = true;
                }

            }

            if($missing_thumb){

                wp_delete_post( $id, true );

                $report.= '<span class="tubeace-warnmsg">Video ID '.$id.' \'<b>'.get_the_title().'\'</b> missing thumbnail and was deleted.</span><br>';
            }
        }

        $report.= $page.'00 posts checked.<br>';

    } else {

        $report.= '<b>All post thumbnails checked.</b><br>'; 
        $done = 1;
    }

    $resp = array('done' => $done, 'report' => $report);
    wp_send_json($resp);

 	die(); // this is required to return a proper result
}
add_action( 'wp_ajax_tubeace_missing_thumbnails', 'tubeace_missing_thumbnails_callback' );