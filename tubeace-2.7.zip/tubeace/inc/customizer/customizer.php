<?php 
/**
 * Displays the customizer controls and styles.
 *
 */

function tubeace_customize_register($wp_customize){

    global $tubeace_customizer_defaults;

    // get array of google fonts
    $response = wp_remote_get( plugin_dir_url( '' ) . 'tubeace/inc/google-fonts-list.json' );

    $fonts = json_decode($response['body']);

    if (!is_wp_error($response)) {
        $fonts = json_decode($response['body']);
        if (isset($fonts)) {

            $fonts = $fonts->items;

            // get array of web fonts
            $fontsArr = tubeace_websafe_fonts();

            foreach ($fonts as $font) {
                $fontsArr[$font->family] = $font->family;// add to array
            }

            $wp_customize->add_panel( 'tubeace_shortcode_options', array(
            'priority'       => 10,
            'capability'     => 'edit_theme_options',
            'title'          => __('Tube Ace Post Preview Options', 'tubeace')
            ));

            require WP_PLUGIN_DIR . '/tubeace/inc/customizer/customizer-preview.php';
            require WP_PLUGIN_DIR . '/tubeace/inc/customizer/customizer-sticky-preview.php';
            require WP_PLUGIN_DIR . '/tubeace/inc/customizer/customizer-pagination.php';
            require WP_PLUGIN_DIR . '/tubeace/inc/customizer/customizer-related-posts.php';
        }
    }
}

// Sanitize
// integer
function tubeace_sanitize_integer( $input ) {
    return intval($input);
}
// checkbox
function tubeace_sanitize_checkbox( $checked ) {
    // Boolean check.
    return ( ( isset( $checked ) && true == $checked ) ? true : false );
}
// select
function tubeace_sanitize_select( $input, $setting ) {
    
    global $wp_customize;
 
    $control = $wp_customize->get_control( $setting->id );
 
    if ( array_key_exists( $input, $control->choices ) ) {
        return $input;
    } else {
        return $setting->default;
    }
}
// hex color
function tubeace_sanitize_hex_color( $hex_color, $setting ) {
    // Sanitize $input as a hex value without the hash prefix.
    return $hex_color = sanitize_hex_color( $hex_color );
}
// html
function tubeace_sanitize_html( $html ) {
    return wp_filter_post_kses( $html );
}
// no-html
function tubeace_sanitize_nohtml( $nohtml ) {
    return wp_filter_nohtml_kses( $nohtml );
}
// image
function tubeace_sanitize_image( $image, $setting ) {
    /*
     * Array of valid image file types.
     *
     * The array includes image mime types that are included in wp_get_mime_types()
     */
    $mimes = array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'gif'          => 'image/gif',
        'png'          => 'image/png',
        'bmp'          => 'image/bmp',
        'tif|tiff'     => 'image/tiff',
        'ico'          => 'image/x-icon'
    );
    // Return an array with file extension and mime_type.
    $file = wp_check_filetype( $image, $mimes );
    // If $image has a valid mime_type, return it; otherwise, return the default.
    return ( $file['ext'] ? $image : $setting->default );
}
// css
function tubeace_sanitize_css( $css ) {
    return wp_strip_all_tags( $css );
}

// CSS styles in Customizer
function tubeace_customize_styles( $input ) { ?>
    <style type="text/css">

    /* dashicons */

    /* sections */
    li#accordion-section-ta_post_preview_setting > h3.accordion-section-title:before,
    li#accordion-section-ta_sticky_post_preview_setting > h3.accordion-section-title:before,
    li#accordion-section-ta_pagination_setting > h3.accordion-section-title:before,
    li#accordion-section-ta_related_posts_setting > h3.accordion-section-title:before
    {content: "\f489";font-family: dashicons;}

    /* sections */
    li#accordion-section-ta_post_preview_setting > .accordion-section-title,
    li#accordion-section-ta_sticky_post_preview_setting > .accordion-section-title,
    li#accordion-section-ta_pagination_setting > .accordion-section-title,
    li#accordion-section-ta_related_posts_setting > .accordion-section-title
    {background:#9CD0FF;}

    /* resize fields */
    /* textareas */
    #_customize-input-ta_preview_css,
    #_customize-input-ta_sticky_preview_css,
    #_customize-input-ta_pagination_css
    {height:400px;}

    /* inputs */
    /* 60 px */
    #_customize-input-ta_preview_title_font_size,
    #_customize-input-ta_preview_font_size,
    #_customize-input-ta_preview_excerpt_length,
    #_customize-input-ta_preview_duration_font_size,
    #_customize-input-ta_preview_tags_label,
    #_customize-input-ta_preview_tags_separator,
    #_customize-input-ta_preview_tags_font_size,
    #_customize-input-ta_preview_category_separator,
    #_customize-input-ta_preview_category_font_size,
    #_customize-input-ta_preview_performers_separator,
    #_customize-input-ta_preview_performers_font_size,
    #_customize-input-ta_preview_rating_font_size,
    #_customize-input-ta_preview_view_count_font_size,
    #_customize-input-ta_preview_avatar_size,
    #_customize-input-ta_preview_fixed_height,
    #_customize-input-ta_sticky_preview_label,
    #_customize-input-ta_sticky_preview_label_font_size,
    #_customize-input-ta_sticky_preview_title_font_size,
    #_customize-input-ta_sticky_preview_font_size,
    #_customize-input-ta_sticky_preview_duration_font_size,
    #_customize-input-ta_sticky_preview_tags_label,
    #_customize-input-ta_sticky_preview_tags_separator,
    #_customize-input-ta_sticky_preview_tags_font_size,
    #_customize-input-ta_sticky_preview_category_label,
    #_customize-input-ta_sticky_preview_category_separator,
    #_customize-input-ta_sticky_preview_category_font_size, 
    #_customize-input-ta_sticky_preview_performers_separator,
    #_customize-input-ta_sticky_preview_performers_font_size, 
    #_customize-input-ta_sticky_preview_rating_font_size, 
    #_customize-input-ta_sticky_preview_view_count_font_size, 
    #_customize-input-ta_sticky_preview_avatar_size,
    #_customize-input-ta_sticky_preview_fixed_height,
    #_customize-input-ta_pagination_prev_font_size,
    #_customize-input-ta_pagination_current_font_size,
    #_customize-input-ta_pagination_num_font_size,
    #_customize-input-ta_pagination_num_per_side,
    #_customize-input-ta_pagination_num_hover_font_size,
    #_customize-input-ta_pagination_dots_font_size,
    #_customize-input-ta_pagination_next_font_size,
    #_customize-input-ta_related_font_size,
    #_customize-input-ta_related_num_results
    {width:60px;}

    /* 80 px */
    #_customize-input-ta_preview_category_label,
    #_customize-input-ta_preview_performers_label,
    #_customize-input-ta_sticky_preview_category_label,
    #_customize-input-ta_sticky_preview_label
    {width:80px;}

    /* 100 px */
    #_customize-input-ta_preview_excerpt_content,
    #_customize-input-ta_preview_featured_image_size,
    #_customize-input-ta_preview_performers_label,
    #_customize-input-ta_sticky_preview_excerpt_content,
    #_customize-input-ta_sticky_preview_featured_image_size,    
    #_customize-input-ta_sticky_preview_performers_label,

    #_customize-input-ta_pagination_prev_label,
    #_customize-input-ta_pagination_num_label,
    #_customize-input-ta_pagination_num_hover_label,
    #_customize-input-ta_pagination_dots_label,
    #_customize-input-ta_pagination_next_label
    {width:100px;}       

    #_customize-input-ta_related_label
    {width:120px;}     
 
    /* select drop-downs
    .customize-control select
    {width:auto;max-width: 100%} */

    #_customize-input-ta_preview_title_font_size_unit,
    #_customize-input-ta_preview_font_size_unit,
    #_customize-input-ta_preview_duration_font_size_unit,
    #_customize-input-ta_preview_tags_font_size_unit,
    #_customize-input-ta_preview_category_font_size_unit,
    #_customize-input-ta_preview_performers_font_size_unit,
    #_customize-input-ta_preview_rating_font_size_unit,
    #_customize-input-ta_preview_view_count_font_size_unit,
    #_customize-input-ta_preview_xs_class,
    #_customize-input-ta_preview_sm_class,
    #_customize-input-ta_preview_md_class,
    #_customize-input-ta_preview_lg_class,

    #_customize-input-ta_sticky_preview_label_font_size_unit,
    #_customize-input-ta_sticky_preview_title_font_size_unit,
    #_customize-input-ta_sticky_preview_font_size_unit,
    #_customize-input-ta_sticky_preview_duration_font_size_unit,
    #_customize-input-ta_sticky_preview_tags_font_size_unit,
    #_customize-input-ta_sticky_preview_category_font_size_unit,
    #_customize-input-ta_sticky_preview_performers_font_size_unit,
    #_customize-input-ta_sticky_preview_rating_font_size_unit,
    #_customize-input-ta_sticky_preview_view_count_font_size_unit,

    #_customize-input-ta_pagination_prev_font_size_unit,
    #_customize-input-ta_pagination_current_font_size_unit,
    #_customize-input-ta_pagination_num_font_size_unit,
    #_customize-input-ta_pagination_num_hover_font_size_unit,
    #_customize-input-ta_pagination_dots_font_size_unit,
    #_customize-input-ta_pagination_next_font_size_unit,

    #_customize-input-ta_related_font_size_unit    
    {width:60px;} 

    /* separators */
    #customize-control-ta_preview_title_font_size_unit,
    #customize-control-ta_preview_border_color,
    #customize-control-ta_preview_excerpt_length,
    #customize-control-ta_preview_featured_image_border_color,
    #customize-control-ta_preview_duration_border_color,
    #customize-control-ta_preview_post_date_txt_color,
    #customize-control-ta_preview_tags_border_color,
    #customize-control-ta_preview_category_border_color,
    #customize-control-ta_preview_performers_border_color,
    #customize-control-ta_preview_link_to_comments,
    #customize-control-ta_preview_avatar_size,
    #customize-control-ta_preview_rating_font_size_unit,
    #customize-control-ta_preview_view_count_font_size_unit,
    #customize-control-ta_preview_lg_class,
    #customize-control-ta_preview_background_image_attachment,

    #customize-control-ta_sticky_preview_label_font_size_unit,
    #customize-control-ta_sticky_preview_title_font_size_unit,
    #customize-control-ta_sticky_preview_border_color,
    #customize-control-ta_sticky_preview_featured_image_border_color,
    #customize-control-ta_sticky_preview_duration_border_color,
    #customize-control-ta_sticky_preview_post_date_txt_color,
    #customize-control-ta_sticky_preview_tags_border_color,
    #customize-control-ta_sticky_preview_category_border_color,
    #customize-control-ta_sticky_preview_performers_border_color,
    #customize-control-ta_sticky_preview_link_to_comments,
    #customize-control-ta_sticky_preview_avatar_size,
    #customize-control-ta_sticky_preview_rating_font_size_unit,
    #customize-control-ta_sticky_preview_view_count_font_size_unit,    
    #customize-control-ta_sticky_preview_background_image_attachment, 

    #customize-control-ta_pagination_prev_border_color,
    #customize-control-ta_pagination_current_border_color,
    #customize-control-ta_pagination_num_border_color,
    #customize-control-ta_pagination_num_hover_border_color,
    #customize-control-ta_pagination_dots_border_color,
    #customize-control-ta_pagination_next_border_color

    {border-bottom:1px solid #999;padding-bottom:10px;position: relative;} 

    /* Offset bottom margins to lay transparent checkboxes closer to color picker */
    #customize-control-ta_preview_bg_color,
    #customize-control-ta_preview_duration_bg_color,
    #customize-control-ta_preview_tags_bg_color,
    #customize-control-ta_preview_category_bg_color,
    #customize-control-ta_preview_performers_bg_color,

    #customize-control-ta_sticky_preview_bg_color,
    #customize-control-ta_sticky_preview_duration_bg_color,
    #customize-control-ta_sticky_preview_tags_bg_color,
    #customize-control-ta_sticky_preview_category_bg_color,
    #customize-control-ta_sticky_preview_performers_bg_color,

    #customize-control-ta_pagination_prev_bg_color,
    #customize-control-ta_pagination_current_bg_color,
    #customize-control-ta_pagination_num_bg_color,
    #customize-control-ta_pagination_num_hover_bg_color,
    #customize-control-ta_pagination_dots_bg_color,
    #customize-control-ta_pagination_next_bg_color
    {margin-bottom:-8px;position: relative;}

    </style>
<?php 
}

function tubeace_transparent_switch(){
?>
    <script type="text/javascript">
    jQuery(document).ready(function ($) {

      function tubeace_transparent_switch(picker, checkbox){

        var color_pkr = $( picker );

        /* on page load, hide or show adv. option */
        if( $( checkbox ).prop( "checked" ) ){
          color_pkr.hide();
        } else{
          color_pkr.show();
        }

        /* on change, hide or show adv. option */
        $( checkbox ).change(function(){
          if( $(this).prop("checked") ) {
            color_pkr.slideUp();
          } else {
            color_pkr.slideDown();
          }
        });
      }

      tubeace_transparent_switch('#customize-control-ta_preview_bg_color', '#customize-control-ta_preview_transparent_bg input'); 
      tubeace_transparent_switch('#customize-control-ta_preview_duration_bg_color', '#customize-control-ta_preview_duration_transparent_bg input');  
      tubeace_transparent_switch('#customize-control-ta_preview_tags_bg_color', '#customize-control-ta_preview_tags_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_preview_category_bg_color', '#customize-control-ta_preview_category_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_preview_performers_bg_color', '#customize-control-ta_preview_performers_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_sticky_preview_bg_color', '#customize-control-ta_sticky_preview_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_sticky_preview_duration_bg_color', '#customize-control-ta_sticky_preview_duration_transparent_bg input');  
      tubeace_transparent_switch('#customize-control-ta_sticky_preview_tags_bg_color', '#customize-control-ta_sticky_preview_tags_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_sticky_preview_category_bg_color', '#customize-control-ta_sticky_preview_category_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_sticky_preview_performers_bg_color', '#customize-control-ta_sticky_preview_performers_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_pagination_prev_bg_color', '#customize-control-ta_pagination_prev_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_pagination_current_bg_color', '#customize-control-ta_pagination_current_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_pagination_num_bg_color', '#customize-control-ta_pagination_num_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_pagination_num_hover_bg_color', '#customize-control-ta_pagination_num_hover_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_pagination_dots_bg_color', '#customize-control-ta_pagination_dots_transparent_bg input');
      tubeace_transparent_switch('#customize-control-ta_pagination_next_bg_color', '#customize-control-ta_pagination_next_transparent_bg input');

    });
    </script>
<?php
}

function tubeace_customize_preview_js() {

  global $tubeace_customizer_defaults;

  $jsfile = plugin_dir_url( '' ) . 'tubeace/js/theme-customizer.js';

  wp_enqueue_script( 'veayo-customizer2', $jsfile, array( 'customize-preview' ), '20151215x', true );

  if( get_theme_mod('preview_layout_style', $tubeace_customizer_defaults['ta_preview_layout_style'])=='masonry'){
      wp_enqueue_script( 
          'tubeaceplay-themecustomizer-masonryfix', // Give the script a unique ID
          get_template_directory_uri() . '/js/theme-customizer-masonryfix.js', // Define the path to the JS file
          array(  'jquery', 'customize-preview' ), // Define dependencies
          '', // Define a version (optional) 
          true // Specify whether to put in footer (leave this true)
      );
  }
}

class tubeace_customizer {

    public static function header_output() {
 
        global $tubeace_customizer_defaults;

        ?>
        <!--Tube Ace Plugin Customizer CSS--> 
        <style type="text/css">
            <?php require 'customizer-css.php';
            ?>
        </style> 
        <!--/Tube Ace Plugin Customizer CSS-->
        <?php
    }

    public static function generate_css( $selector, $style, $mod_name, $prefix='', $postfix='', $echo=true ) {

        global $tubeace_customizer_defaults;

        $return = '';
        $mod = get_theme_mod( $mod_name, $tubeace_customizer_defaults[$mod_name] );
        if (  $mod !='' ) {

            //wrap multi-word google fonts in double quotes
            if (strpos($mod, ' ') !== false && strpos($mod, ',') === false) {
                $mod = '"'.$mod.'"';
            }

            $return = "$selector { $style:$prefix$mod$postfix}";
            $return = html_entity_decode($return); //decode double quotes from web safe fonts
            echo $return;

        }
        return $return;
    }

    public static function font_css( $selector, $mod_name) {

        global $tubeace_customizer_defaults;

        $mod = get_theme_mod($mod_name.'_size', $tubeace_customizer_defaults[$mod_name.'_size']);
        $unit = get_theme_mod($mod_name.'_size_unit', $tubeace_customizer_defaults[$mod_name.'_size_unit']); 
        if ( ! empty( $mod ) ) {

            echo "$selector { font-size:$mod$unit}";
        }
    }

    public static function transparent_css($selector) {

        echo "$selector { background-color:transparent}";
    }    

    public static function blockquote_css( $selector, $style, $mod_name) {

        $mod = get_theme_mod($mod_name);
        if ( ! empty( $mod ) ) {

            echo "$selector { $style:$mod !important}";
        }
    }
}

// Load customizer panels
add_action( 'customize_register', 'tubeace_customize_register' );

// Output custom CSS within Customizer 
add_action( 'customize_controls_print_styles', 'tubeace_customize_styles' );

// Output custom CSS to live site
add_action( 'wp_head' , array( 'tubeace_customizer' , 'header_output' ) , 99);

// Enqueue live preview javascript in Theme Customizer admin screen
add_action( 'customize_preview_init', 'tubeace_customize_preview_js' ); // must be loaded outside of a class or theme customizer won't be loaded.

// Output JS to hide color picker when transparent bg checked
add_action( 'customize_controls_print_footer_scripts', 'tubeace_transparent_switch', 99); // 99 priority needed to work

?>
