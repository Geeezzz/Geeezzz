<?php 
/**
 * Displays the customizer controls for the post previews.
 *
 */

$wp_customize->add_section('ta_pagination_setting', array(
    'title'                 => __('Pagination', 'tubeace'),
    'priority'              => 104,
    'panel'                 =>'tubeace_shortcode_options'
));

/* Previous */
// Background Color
$wp_customize->add_setting( 'ta_pagination_prev_bg_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_prev_bg_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_prev_bg_color',
    array(
        'label' => __( 'Previous Background Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_prev_bg_color',
    ) 
));
// Transparent BG
$wp_customize->add_setting( 'ta_pagination_prev_transparent_bg', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_prev_transparent_bg'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_pagination_prev_transparent_bg', array(
    'label'                 => __('Transparent Background', 'tubeace'),
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_prev_transparent_bg',
    'type'                  => 'checkbox',
));

// Pagination Label
$wp_customize->add_setting('ta_pagination_prev_label', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_prev_label'],
    'sanitize_callback' => 'tubeace_sanitize_nohtml',
));
$wp_customize->add_control('ta_pagination_prev_label', array(
    'label'                     => __('Previous Pagination Label', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_prev_label',
    'type'                      => 'text',
));

// Font Family
$wp_customize->add_setting('ta_pagination_prev_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_prev_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_prev_font_family', array(
    'label'                     => __('Previous Font Family', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_prev_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Title Font Size
$wp_customize->add_setting('ta_pagination_prev_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_prev_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_pagination_prev_font_size', array(
    'label'                     => __('Previous Font Size', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_prev_font_size',
    'type'                      => 'number',
));
// Font Size Unit
$wp_customize->add_setting('ta_pagination_prev_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_prev_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_prev_font_size_unit', array(
    'label'                     => __('Previous Font Size Unit', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_prev_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
));

// Text Color
$wp_customize->add_setting( 'ta_pagination_prev_txt_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_prev_txt_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_prev_txt_color',
    array(
        'label' => __( 'Previous Text Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_prev_txt_color',
    ) 
));

// Border Color
$wp_customize->add_setting( 'ta_pagination_prev_border_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_prev_border_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_prev_border_color',
    array(
        'label' => __( 'Previous Border Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_prev_border_color',
    ) 
));


/* Current */
// Background Color
$wp_customize->add_setting( 'ta_pagination_current_bg_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_current_bg_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_current_bg_color',
    array(
        'label' => __( 'Current Background Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_current_bg_color',
    ) 
));
// Transparent BG
$wp_customize->add_setting( 'ta_pagination_current_transparent_bg', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_current_transparent_bg'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_pagination_current_transparent_bg', array(
    'label'                 => __('Transparent Background', 'tubeace'),
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_current_transparent_bg',
    'type'                  => 'checkbox',
));

// Font Family
$wp_customize->add_setting('ta_pagination_current_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_current_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_current_font_family', array(
    'label'                     => __('Current Font Family', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_current_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Title Font Size
$wp_customize->add_setting('ta_pagination_current_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_current_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_pagination_current_font_size', array(
    'label'                     => __('Current Font Size', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_current_font_size',
    'type'                      => 'number',
));
// Font Size Unit
$wp_customize->add_setting('ta_pagination_current_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_current_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_current_font_size_unit', array(
    'label'                     => __('Current Font Size Unit', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_current_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
));

// Text Color
$wp_customize->add_setting( 'ta_pagination_current_txt_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_current_txt_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_current_txt_color',
    array(
        'label' => __( 'Current Text Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_current_txt_color',
    ) 
));

// Border Color
$wp_customize->add_setting( 'ta_pagination_current_border_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_current_border_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_current_border_color',
    array(
        'label' => __( 'Current Border Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_current_border_color',
    ) 
));


/* Numbers */
// Background Color
$wp_customize->add_setting( 'ta_pagination_num_bg_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_num_bg_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_num_bg_color',
    array(
        'label' => __( 'Number Background Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_num_bg_color',
    ) 
));
// Transparent BG
$wp_customize->add_setting( 'ta_pagination_num_transparent_bg', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_num_transparent_bg'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_pagination_num_transparent_bg', array(
    'label'                 => __('Transparent Background', 'tubeace'),
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_num_transparent_bg',
    'type'                  => 'checkbox',
));
// Numbers Per Side of Current 
$wp_customize->add_setting('ta_pagination_num_per_side', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_per_side'],
    'sanitize_callback' => 'tubeace_sanitize_nohtml',
));
$wp_customize->add_control('ta_pagination_num_per_side', array(
    'label'                     => __('Numbers Per Side of Current Page #', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_per_side',
    'type'                      => 'number',
));
// Font Family
$wp_customize->add_setting('ta_pagination_num_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_num_font_family', array(
    'label'                     => __('Number Font Family', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Title Font Size
$wp_customize->add_setting('ta_pagination_num_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_pagination_num_font_size', array(
    'label'                     => __('Number Font Size', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_font_size',
    'type'                      => 'number',
));
// Font Size Unit
$wp_customize->add_setting('ta_pagination_num_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_num_font_size_unit', array(
    'label'                     => __('Number Font Size Unit', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
));
// Text Color
$wp_customize->add_setting( 'ta_pagination_num_txt_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_num_txt_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_num_txt_color',
    array(
        'label' => __( 'Number Text Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_num_txt_color',
    ) 
));
// Border Color
$wp_customize->add_setting( 'ta_pagination_num_border_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_num_border_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_num_border_color',
    array(
        'label' => __( 'Number Border Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_num_border_color',
    ) 
));

/* Numbers Hover */
// Background Color
$wp_customize->add_setting( 'ta_pagination_num_hover_bg_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_num_hover_bg_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'refresh', //refresh for hover bug
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_num_hover_bg_color',
    array(
        'label' => __( 'Number Hover Background Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_num_hover_bg_color',
    ) 
));
// Transparent BG
$wp_customize->add_setting( 'ta_pagination_num_hover_transparent_bg', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_num_hover_transparent_bg'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_pagination_num_hover_transparent_bg', array(
    'label'                 => __('Transparent Background', 'tubeace'),
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_num_hover_transparent_bg',
    'type'                  => 'checkbox',
));
// Font Family
$wp_customize->add_setting('ta_pagination_num_hover_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_hover_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_num_hover_font_family', array(
    'label'                     => __('Number Hover Font Family', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_hover_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Title Font Size
$wp_customize->add_setting('ta_pagination_num_hover_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_hover_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_pagination_num_hover_font_size', array(
    'label'                     => __('Number Hover Font Size', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_hover_font_size',
    'type'                      => 'number',
));
// Font Size Unit
$wp_customize->add_setting('ta_pagination_num_hover_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_num_hover_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_num_hover_font_size_unit', array(
    'label'                     => __('Number Hover Font Size Unit', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_num_hover_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
));
// Text Color
$wp_customize->add_setting( 'ta_pagination_num_hover_txt_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_num_hover_txt_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'refresh',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_num_hover_txt_color',
    array(
        'label' => __( 'Number Hover Text Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_num_hover_txt_color',
    ) 
));
// Border Color
$wp_customize->add_setting( 'ta_pagination_num_hover_border_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_num_hover_border_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'refresh',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_num_hover_border_color',
    array(
        'label' => __( 'Number Hover Border Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_num_hover_border_color',
    ) 
));

/* Dots */
// Background Color
$wp_customize->add_setting( 'ta_pagination_dots_bg_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_dots_bg_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_dots_bg_color',
    array(
        'label' => __( 'Dots Background Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_dots_bg_color',
    ) 
));
// Transparent BG
$wp_customize->add_setting( 'ta_pagination_dots_transparent_bg', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_dots_transparent_bg'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_pagination_dots_transparent_bg', array(
    'label'                 => __('Transparent Background', 'tubeace'),
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_dots_transparent_bg',
    'type'                  => 'checkbox',
));
// Font Family
$wp_customize->add_setting('ta_pagination_dots_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_dots_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_dots_font_family', array(
    'label'                     => __('Dots Font Family', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_dots_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Title Font Size
$wp_customize->add_setting('ta_pagination_dots_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_dots_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_pagination_dots_font_size', array(
    'label'                     => __('Dots Font Size', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_dots_font_size',
    'type'                      => 'number',
));
// Font Size Unit
$wp_customize->add_setting('ta_pagination_dots_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_dots_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_dots_font_size_unit', array(
    'label'                     => __('Dots Font Size Unit', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_dots_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
));
// Text Color
$wp_customize->add_setting( 'ta_pagination_dots_txt_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_dots_txt_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_dots_txt_color',
    array(
        'label' => __( 'Dots Text Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_dots_txt_color',
    ) 
));
// Border Color
$wp_customize->add_setting( 'ta_pagination_dots_border_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_dots_border_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_dots_border_color',
    array(
        'label' => __( 'Dots Border Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_dots_border_color',
    ) 
));

/* Next */
// Background Color
$wp_customize->add_setting( 'ta_pagination_next_bg_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_next_bg_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_next_bg_color',
    array(
        'label' => __( 'Next Background Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_next_bg_color',
    ) 
));
// Transparent BG
$wp_customize->add_setting( 'ta_pagination_next_transparent_bg', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_next_transparent_bg'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_pagination_next_transparent_bg', array(
    'label'                 => __('Transparent Background', 'tubeace'),
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_next_transparent_bg',
    'type'                  => 'checkbox',
));

// Pagination Label
$wp_customize->add_setting('ta_pagination_next_label', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_next_label'],
    'sanitize_callback' => 'tubeace_sanitize_nohtml',
));
$wp_customize->add_control('ta_pagination_next_label', array(
    'label'                     => __('Next Pagination Label', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_next_label',
    'type'                      => 'text',
));

// Font Family
$wp_customize->add_setting('ta_pagination_next_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_next_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_next_font_family', array(
    'label'                     => __('Next Font Family', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_next_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Title Font Size
$wp_customize->add_setting('ta_pagination_next_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_next_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_pagination_next_font_size', array(
    'label'                     => __('Next Font Size', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_next_font_size',
    'type'                      => 'number',
));
// Font Size Unit
$wp_customize->add_setting('ta_pagination_next_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_pagination_next_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_pagination_next_font_size_unit', array(
    'label'                     => __('Next Font Size Unit', 'tubeace'),
    'section'                   => 'ta_pagination_setting',
    'settings'                  => 'ta_pagination_next_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
));

// Text Color
$wp_customize->add_setting( 'ta_pagination_next_txt_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_next_txt_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_next_txt_color',
    array(
        'label' => __( 'Next Text Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_next_txt_color',
    ) 
));

// Border Color
$wp_customize->add_setting( 'ta_pagination_next_border_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_pagination_next_border_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_pagination_next_border_color',
    array(
        'label' => __( 'Next Border Color', 'tubeace' ),
        'section' => 'ta_pagination_setting',
        'settings' => 'ta_pagination_next_border_color',
    ) 
));

/* CSS */
$wp_customize->add_setting( 'ta_pagination_css', array(
    'default'               => $tubeace_customizer_defaults['ta_pagination_css'],
    'sanitize_callback' => 'tubeace_sanitize_css',
));
$wp_customize->add_control( 'ta_pagination_css', array(
    'label'                 => __('CSS', 'tubeace'), 
    'section'               => 'ta_pagination_setting',
    'settings'              => 'ta_pagination_css',
    'type'                  => 'textarea',
));    