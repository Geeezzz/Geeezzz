<?php 
/**
 * Displays the customizer controls for the post previews.
 *
 */

$wp_customize->add_section('ta_related_posts_setting', array(
    'title'                 => __('Related Posts', 'tubeace'),
    'priority'              => 104,
    'panel'                 =>'tubeace_shortcode_options'
));


/* Related */
// Show Related
$wp_customize->add_setting( 'ta_show_related', array(
    'default'               => $tubeace_customizer_defaults['ta_show_related'],
    'sanitize_callback' => 'tubeace_sanitize_checkbox',
));
$wp_customize->add_control( 'ta_show_related', array(
    'label'                 => __('Show Related Posts After Post Content', 'tubeace'),
    'section'               => 'ta_related_posts_setting',
    'settings'              => 'ta_show_related',
    'type'                  => 'checkbox',
));
// Related Label
$wp_customize->add_setting('ta_related_label', array(
    'default'                   => $tubeace_customizer_defaults['ta_related_label'],
    'sanitize_callback' => 'tubeace_sanitize_nohtml',
));
$wp_customize->add_control('ta_related_label', array(
    'label'                     => __('Related Label', 'tubeace'),
    'section'                   => 'ta_related_posts_setting',
    'settings'                  => 'ta_related_label',
    'type'                      => 'text',
));
// Related Label Color
$wp_customize->add_setting( 'ta_related_label_color',
    array(
        'default' => $tubeace_customizer_defaults['ta_related_label_color'],
        'sanitize_callback' => 'tubeace_sanitize_hex_color',
        'transport' => 'postMessage',
    ) 
);
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ta_related_label_color',
    array(
        'label' => __( 'Related Label Color', 'tubeace' ),
        'section' => 'ta_related_posts_setting',
        'settings' => 'ta_related_label_color',
    ) 
));
// Related Font Family
$wp_customize->add_setting('ta_related_font_family', array(
    'default'                   => $tubeace_customizer_defaults['ta_related_font_family'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_related_font_family', array(
    'label'                     => __('Related Label Font Family', 'tubeace'),
    'section'                   => 'ta_related_posts_setting',
    'settings'                  => 'ta_related_font_family',
    'type'                      => 'select',
    'choices'                   => $fontsArr,
));
// Related Label Font Size
$wp_customize->add_setting('ta_related_font_size', array(
    'default'                   => $tubeace_customizer_defaults['ta_related_font_size'],
    'sanitize_callback'     => 'tubeace_sanitize_integer',
));    
$wp_customize->add_control('ta_related_font_size', array(
    'label'                     => __('Related Label Font Size', 'tubeace'),
    'section'                   => 'ta_related_posts_setting',
    'settings'                  => 'ta_related_font_size',
    'type'                      => 'number',
));
// Related Font Size Unit
$wp_customize->add_setting('ta_related_font_size_unit', array(
    'default'                   => $tubeace_customizer_defaults['ta_related_font_size_unit'],
    'sanitize_callback'     => 'tubeace_sanitize_select',
));    
$wp_customize->add_control('ta_related_font_size_unit', array(
    'label'                     => __('Related Label Font Size Unit', 'tubeace'),
    'section'                   => 'ta_related_posts_setting',
    'settings'                  => 'ta_related_font_size_unit',
    'type'                      => 'select',
    'choices'                   => array('px'=>'px','pt'=>'pt','em'=>'em','rem'=>'rem')
)); 
// Number of Related Results
$wp_customize->add_setting('ta_related_num_results', array(
    'default'                   => $tubeace_customizer_defaults['ta_related_num_results'],
    'sanitize_callback' => 'tubeace_sanitize_integer',
));
$wp_customize->add_control('ta_related_num_results', array(
    'label'                     => __('Number of Related Results', 'tubeace'),
    'section'                   => 'ta_related_posts_setting',
    'settings'                  => 'ta_related_num_results',
    'type'                      => 'number',
));