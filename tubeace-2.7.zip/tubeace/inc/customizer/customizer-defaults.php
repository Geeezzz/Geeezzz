<?php 
/**
 * Array of customizer default values. These styles will be displayed for the pages (Tube, Newest, Highest Rated, Most Viewed) and results for plugin shortcodes.
 */

$ta_preview_css = "/* Post Preview Outer */\n.post-preview {\n\tmargin: 0;\n\tpadding: 2px 2px;\n}\n\n";
$ta_preview_css.= "/* Post Preview */\n.post-preview-styling {\n\tborder-width: 0px;\n\tborder-style: solid;\n\toverflow: hidden;\n\tmargin: 0;\n\tpadding: 0px; 0px;\n}\n\n";
$ta_preview_css.= "/* Title */\na.preview-title {\n\tfont-weight: bold;\n\tdisplay: block;\n}\n\n.post-preview h2 {\n\tmargin: 0;\n}\n\n";
$ta_preview_css.= "/* Featured Image */\n.wp-post-image {\n\tborder-width: 1px;\n\tborder-style: solid;\n}\n\n";
$ta_preview_css.= "/* Post Preview Images */\n.post-preview-styling img:not(.avatar, .post-ratings-image) {\n\twidth: 100%;\n\theight: auto;\n}\n\n";
$ta_preview_css.= "/* Duration */\n.post-preview-styling .duration{\n\topacity: 0.7;\n\ttop:3px;\n\tleft:16px;\n\tposition: absolute;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tz-index: 1;\n}\n\n";
$ta_preview_css.= "/* Embedded Content */\n.post-preview-styling iframe:not(.instagram-media), .post-preview-styling, .post-preview-styling embed {\n\tmax-width: 100%;\n\theight: auto;\n}\n\n";
$ta_preview_css.= "/* Clear Lines */\n.post-preview-tags, .post-preview-category, .post-preview-edit {\n\tclear: both;\n}\n\n";
$ta_preview_css.= "/* Rating */\n.post-preview-rating {\n\tfloat:left;\n}\n\n";
$ta_preview_css.= "/* View Count */\n.post-preview-view-count {float:left;\n\padding:0 0 0 8px;}\n\n";
$ta_preview_css.= "/* Tags */\n.post-preview-tags a {\n\tpadding: 2px;\n\twhite-space: nowrap;\n\tline-height: 1.8em;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-radius: 6px;\n}\n\n";
$ta_preview_css.= "/* Categories */\n.post-preview-category a {\n\tpadding: 2px;\n\twhite-space: nowrap;\n\tline-height: 1.8em;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-radius: 6px;\n}\n\n";
$ta_preview_css.= "/* Performers */\n.post-preview-performers a {\n\tpadding: 2px;\n\twhite-space: nowrap;\n\tline-height: 1.8em;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-radius: 6px;\n}\n\n";
$ta_preview_css.= "/* Comments */\n.post-preview-comments {float:right;}\n\n";
$ta_preview_css.= "/* Author */\n.post-preview-author {}\n\n";
$ta_preview_css.= "/* Flexbox */\n.tubeace-flexbox {\n\tdisplay:flex;\n\tflex-flow:row wrap;\n}\n\n";

$ta_sticky_preview_css = "/* Sticky Post Preview Outer */\n.sticky {\n\tmargin: 0;\n\tpadding: 2px 2px;\n}\n\n";
$ta_sticky_preview_css.= "/* Sticky Post Preview */\n.sticky-post-preview-styling {\n\tborder-width: 0px;\n\tborder-style: solid;\n\toverflow: hidden;\n\tmargin: 0;\n\tpadding: 0px; 0px;\n}\n\n";
$ta_sticky_preview_css.= "/* Title */\n.sticky .preview-title a {\n\tfont-weight: bold;\n\tdisplay: block;\n}\n\n.sticky-post-preview-styling h2 {\n\tmargin: 0;\n}\n\n";
$ta_sticky_preview_css.= "/* Featured Image */\n.sticky .wp-post-image {\n\tborder-width: 1px;\n\tborder-style: solid;\n}\n\n";
$ta_sticky_preview_css.= "/* Post Preview Images */\n.sticky-post-preview-styling img:not(.avatar, .post-ratings-image) {\n\twidth: 100%;\n\theight: auto;\n}\n\n";
$ta_sticky_preview_css.= "/* Duration */\n.sticky-post-preview-styling .duration{\n\topacity: 0.7;\n\ttop:3px;\n\tleft:16px;\n\tposition: absolute;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-style: solid;\n\tz-index: 1;\n}\n\n";
$ta_sticky_preview_css.= "/* Embedded Content */\n.sticky-post-preview-styling iframe:not(.instagram-media), .sticky-post-preview-styling object, .sticky-post-preview-styling embed {\n\tmax-width: 100%;\n\theight: auto;\n}\n\n";
$ta_sticky_preview_css.= "/* Clear Lines */\n.sticky-post-preview-tags, .sticky-post-preview-category, .sticky-post-preview-edit {\n\tclear: both;\n}\n\n";
$ta_sticky_preview_css.= "/* Rating */\n.sticky-post-preview-rating {\n\tfloat:left;\n}\n\n";
$ta_sticky_preview_css.= "/* View Count */\n.sticky-post-preview-view-count {\n\tfloat: left;\n\padding:0 0 0 8px;\n}\n\n";
$ta_sticky_preview_css.= "/* Tags */\n.sticky-post-preview-tags a {\n\tpadding: 2px;\n\twhite-space: nowrap;\n\tline-height: 1.8em;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-radius: 6px;\n}\n\n";
$ta_sticky_preview_css.= "/* Categories */\n.sticky-post-preview-category a {\n\tpadding: 2px;\n\twhite-space: nowrap;\n\tline-height: 1.8em;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-radius: 6px;\n}\n\n";
$ta_sticky_preview_css.= "/* Performers */\n.sticky-post-preview-performers a {\n\tpadding: 2px;\n\twhite-space: nowrap;\n\tline-height: 1.8em;\n\tborder-width: 1px;\n\tborder-style: solid;\n\tborder-radius: 6px;\n}\n\n";
$ta_sticky_preview_css.= "/* Comments */\n.sticky-post-preview-comments {float:right;}\n\n";
$ta_sticky_preview_css.= "/* Author */\n.sticky-post-preview-author {}\n\n";
$ta_sticky_preview_css.= "/* Ribbon */\n.sticky .ribbon {\n\tposition: absolute;\n\tright: 1px;\n\ttop: 1px;\n\tz-index: 1;\n\toverflow: hidden;\n\twidth: 75px;\n\theight: 75px;\n\ttext-align: right;\n}\n\n";
$ta_sticky_preview_css.= "/* Ribbon Text Span */\n.sticky .ribbon span {\n\tfont-weight: bold;\n\ttext-transform: uppercase;\n\ttext-align: center;\n\tline-height: 20px;\n\ttransform: rotate(45deg);\n\t";
$ta_sticky_preview_css.= "-webkit-transform: rotate(45deg);\n\twidth: 100px;\n\tdisplay: block;\n\tbox-shadow: 0 3px 10px -5px rgba(0, 0, 0, 1);\n\tposition: absolute;\n\ttop: 19px; right: -21px;\n}\n\n";

$ta_pagination_css = "/* Previous */\n.nav-links .prev{\n\tborder-width: 2px;\n\tborder-style: solid;\n\tpadding: 14px 14px;\n}\n\n";
$ta_pagination_css.= "/* Current */\n.nav-links .current{\n\tborder-width: 1px;\n\tborder-style: solid;\n\tpadding: 14px 14px;\n}\n\n";
$ta_pagination_css.= "/* Numbers */\n.nav-links .page-numbers:not(.prev):not(.next):not(.dots){\n\tborder-width: 1px;\n\tborder-style: solid;\n\tpadding: 14px 14px;\n\tmargin: 2px;\n\tdisplay: inline-block;\n}\n\n";
$ta_pagination_css.= "/* Dots */\n.nav-links .dots{\n\tborder-width: 0px;\n\tborder-style: solid;\n\tpadding: 14px 14px;\n}\n\n";
$ta_pagination_css.= "/* Next */\n.nav-links .next{\n\tborder-width: 2px;\n\tborder-style: solid;\n\tpadding: 14px 14px;\n}\n\n";
$ta_pagination_css.= "/* Hover */\n.nav-links .page-numbers:hover{\n\ttext-decoration: none;\n}\n\n";


//create customizer defaults for /inc/customizer
// $tubeaceplay_customizer_defaults must be created for default values of $wp_customize->add_setting
// $tubeaceplay_defaults has values with '%' replaced with '%%' (escaped) below for get_theme_mod on front-end
$tubeace_defaults = $tubeace_customizer_defaults = array(

  'ta_preview_show_title' => true, //preview
  'ta_preview_title_txt_color' => '#1e73be',
  'ta_preview_title_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_title_font_size' => '14',
  'ta_preview_title_font_size_unit' => 'px',
  'ta_preview_bg_color' => '#000000',
  'ta_preview_transparent_bg' => true,
  'ta_preview_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_font_size' => '12',
  'ta_preview_font_size_unit' => 'px',
  'ta_preview_txt_color' => '#666666',
  'ta_preview_link_color' => '#dd9933',
  'ta_preview_border_color' => '#cccccc',
  'ta_preview_excerpt_content' => 'dontshow',
  'ta_preview_excerpt_length' => '20',
  'ta_preview_featured_image_size' => 'large',
  'ta_preview_featured_image_border_color' => '#444444',
  'ta_preview_show_duration' => true,
  'ta_preview_duration_bg_color' => '#000000',
  'ta_preview_duration_transparent_bg' => false,
  'ta_preview_duration_txt_color' => '#ffffff',
  'ta_preview_duration_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_duration_font_size' => '10',
  'ta_preview_duration_font_size_unit' => 'px',
  'ta_preview_duration_border_color' => '#000000',
  'ta_preview_show_post_date' => false,
  'ta_preview_show_post_time' => false,
  'ta_preview_post_date_txt_color' => '#999999',
  'ta_preview_show_tags' => false,
  'ta_preview_tags_label' => 'Tags: ',
  'ta_preview_tags_separator' => ', ',
  'ta_preview_tags_label_color' => '#999999',
  'ta_preview_tags_txt_color' => '#1e73be',
  'ta_preview_tags_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_tags_font_size' => '14',
  'ta_preview_tags_font_size_unit' => 'px',    
  'ta_preview_tags_bg_color' => '#ffffff',
  'ta_preview_tags_transparent_bg' => true,
  'ta_preview_tags_border_color' => '#999999',
  'ta_preview_show_category' => false,
  'ta_preview_category_label' => 'Category: ',
  'ta_preview_category_separator' => ', ',
  'ta_preview_category_label_color' => '#999999',
  'ta_preview_category_txt_color' => '#1e73be',
  'ta_preview_category_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_category_font_size' => '14',
  'ta_preview_category_font_size_unit' => 'px',    
  'ta_preview_category_bg_color' => '#f1f1f1',
  'ta_preview_category_transparent_bg' => true,
  'ta_preview_category_border_color' => '#999999',
  'ta_preview_show_performers' => false,
  'ta_preview_performers_label' => 'Performers: ',
  'ta_preview_performers_separator' => ', ',
  'ta_preview_performers_label_color' => '#999999',
  'ta_preview_performers_txt_color' => '#1e73be',
  'ta_preview_performers_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_performers_font_size' => '14',
  'ta_preview_performers_font_size_unit' => 'px',    
  'ta_preview_performers_bg_color' => '#000000',
  'ta_preview_performers_transparent_bg' => true,
  'ta_preview_performers_border_color' => '#999999',
  'ta_preview_show_number_comments' => false,
  'ta_preview_link_to_comments' => true,
  'ta_preview_show_author' => false,
  'ta_preview_show_author_avatar' => true,
  'ta_preview_link_to_author' => true,
  'ta_preview_avatar_size' => '32',
  'ta_preview_show_rating' => true,
  'ta_preview_rating_txt_color' => '#999999',
  'ta_preview_rating_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_rating_font_size' => '12',
  'ta_preview_rating_font_size_unit' => 'px',  
  'ta_preview_show_view_count' => true,
  'ta_preview_view_count_txt_color' => '#999999',
  'ta_preview_view_count_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_preview_view_count_font_size' => '12',
  'ta_preview_view_count_font_size_unit' => 'px',
  'ta_preview_layout_style' => 'flexbox',
  'ta_preview_fixed_height' => '200px',
  'ta_preview_xs_class' => 'col-xs-12',
  'ta_preview_sm_class' => 'col-sm-4',
  'ta_preview_md_class' => 'col-md-4',
  'ta_preview_lg_class' => 'col-lg-3',
  'ta_preview_background_image' => '',
  'ta_preview_background_image_repeat' => 'repeat',
  'ta_preview_background_image_position' => 'center',
  'ta_preview_background_image_attachment' => 'scroll',
  'ta_preview_css' => $ta_preview_css,

  'ta_sticky_preview_show_label' => true, //sticky preview
  'ta_sticky_preview_label' => 'Featured',
  'ta_sticky_preview_label_txt_color' => '#ffffff',
  'ta_sticky_preview_label_bg_color' => '#dd3333',
  'ta_sticky_preview_label_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_label_font_size' => '10',
  'ta_sticky_preview_label_font_size_unit' => 'px',
  'ta_sticky_preview_show_title' => true,
  'ta_sticky_preview_title_txt_color' => '#1e73be',
  'ta_sticky_preview_title_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_title_font_size' => '16',
  'ta_sticky_preview_title_font_size_unit' => 'px',
  'ta_sticky_preview_bg_color' => '#000000',
  'ta_sticky_preview_transparent_bg' => true,
  'ta_sticky_preview_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_font_size' => '14',
  'ta_sticky_preview_font_size_unit' => 'px',        
  'ta_sticky_preview_txt_color' => '#666666',
  'ta_sticky_preview_link_color' => '#dd9933',
  'ta_sticky_preview_border_color' => '#000000',
  'ta_sticky_preview_featured_image_size' => 'large',
  'ta_sticky_preview_featured_image_border_color' => '#444444',
  'ta_sticky_preview_show_duration' => true,
  'ta_sticky_preview_duration_bg_color' => '#000000',
  'ta_sticky_preview_duration_transparent_bg' => false,
  'ta_sticky_preview_duration_txt_color' => '#ffffff',
  'ta_sticky_preview_duration_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_duration_font_size' => '10',
  'ta_sticky_preview_duration_font_size_unit' => 'px',
  'ta_sticky_preview_duration_border_color' => '#000000',  
  'ta_sticky_preview_show_post_date' => false,
  'ta_sticky_preview_show_post_time' => false,
  'ta_sticky_preview_post_date_txt_color' => '#999999',
  'ta_sticky_preview_show_tags' => false,
  'ta_sticky_preview_tags_label' => 'Tags: ',
  'ta_sticky_preview_tags_separator' => ', ',
  'ta_sticky_preview_tags_label_color' => '#999999',
  'ta_sticky_preview_tags_txt_color' => '#1e73be',
  'ta_sticky_preview_tags_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_tags_font_size' => '14',
  'ta_sticky_preview_tags_font_size_unit' => 'px',
  'ta_sticky_preview_tags_bg_color' => '#ededc4',
  'ta_sticky_preview_tags_transparent_bg' => true,  
  'ta_sticky_preview_tags_border_color' => '#333333',
  'ta_sticky_preview_show_category' => false,
  'ta_sticky_preview_category_label' => 'Category: ',
  'ta_sticky_preview_category_separator' => ', ',
  'ta_sticky_preview_category_label_color' => '#999999',
  'ta_sticky_preview_category_txt_color' => '#1e73be',
  'ta_sticky_preview_category_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_category_font_size' => '14',
  'ta_sticky_preview_category_font_size_unit' => 'px',
  'ta_sticky_preview_category_bg_color' => '#ededc4',
  'ta_sticky_preview_category_transparent_bg' => true,  
  'ta_sticky_preview_category_border_color' => '#333333',
  'ta_sticky_preview_show_performers' => false,
  'ta_sticky_preview_performers_label' => 'Performers: ',
  'ta_sticky_preview_performers_separator' => ', ',
  'ta_sticky_preview_performers_label_color' => '#999999',
  'ta_sticky_preview_performers_txt_color' => '#1e73be',
  'ta_sticky_preview_performers_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_performers_font_size' => '14',
  'ta_sticky_preview_performers_font_size_unit' => 'px',
  'ta_sticky_preview_performers_bg_color' => '#000000',
  'ta_sticky_preview_performers_transparent_bg' => true,  
  'ta_sticky_preview_performers_border_color' => '#333333',
  'ta_sticky_preview_show_number_comments' => false,
  'ta_sticky_preview_link_to_comments' => true,
  'ta_sticky_preview_show_author' => false,
  'ta_sticky_preview_show_author_avatar' => true,
  'ta_sticky_preview_link_to_author' => true,
  'ta_sticky_preview_avatar_size' => '32',
  'ta_sticky_preview_show_rating' => true,
  'ta_sticky_preview_rating_txt_color' => '#999999',
  'ta_sticky_preview_rating_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_rating_font_size' => '12',
  'ta_sticky_preview_rating_font_size_unit' => 'px',  
  'ta_sticky_preview_show_view_count' => true,
  'ta_sticky_preview_view_count_txt_color' => '#999999',
  'ta_sticky_preview_view_count_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_sticky_preview_view_count_font_size' => '12',
  'ta_sticky_preview_view_count_font_size_unit' => 'px',  
  'ta_sticky_preview_background_image' => '',
  'ta_sticky_preview_background_image_repeat' => 'repeat',
  'ta_sticky_preview_background_image_position' => 'center',
  'ta_sticky_preview_background_image_attachment' => 'scroll',  
  'ta_sticky_preview_css' => $ta_sticky_preview_css,

  'ta_pagination_prev_bg_color' => '#333333',
  'ta_pagination_prev_transparent_bg' => false,
  'ta_pagination_prev_label' => 'Prev',
  'ta_pagination_prev_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_pagination_prev_font_size' => '16',
  'ta_pagination_prev_font_size_unit' => 'px',
  'ta_pagination_prev_txt_color' => '#cccccc',
  'ta_pagination_prev_border_color' => '#1e73be',

  'ta_pagination_current_bg_color' => '#1e73be',
  'ta_pagination_current_transparent_bg' => false,
  'ta_pagination_current_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_pagination_current_font_size' => '16',
  'ta_pagination_current_font_size_unit' => 'px',
  'ta_pagination_current_txt_color' => '#cccccc',
  'ta_pagination_current_border_color' => '#1e73be',

  'ta_pagination_num_bg_color' => '#333333',
  'ta_pagination_num_transparent_bg' => false,
  'ta_pagination_num_per_side' => '2',
  'ta_pagination_num_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_pagination_num_font_size' => '16',
  'ta_pagination_num_font_size_unit' => 'px',
  'ta_pagination_num_txt_color' => '#cccccc',
  'ta_pagination_num_border_color' => '#333333',

  'ta_pagination_num_hover_bg_color' => '#444444',
  'ta_pagination_num_hover_transparent_bg' => false,
  'ta_pagination_num_hover_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_pagination_num_hover_font_size' => '16',
  'ta_pagination_num_hover_font_size_unit' => 'px',
  'ta_pagination_num_hover_txt_color' => '#cccccc',
  'ta_pagination_num_hover_border_color' => '#444444',

  'ta_pagination_dots_bg_color' => '#333333',
  'ta_pagination_dots_transparent_bg' => true,
  'ta_pagination_dots_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_pagination_dots_font_size' => '16',
  'ta_pagination_dots_font_size_unit' => 'px',
  'ta_pagination_dots_txt_color' => '#cccccc',
  'ta_pagination_dots_border_color' => '#333333',

  'ta_pagination_next_bg_color' => '#333333',
  'ta_pagination_next_transparent_bg' => false,
  'ta_pagination_next_label' => 'Next',
  'ta_pagination_next_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_pagination_next_font_size' => '16',
  'ta_pagination_next_font_size_unit' => 'px',
  'ta_pagination_next_txt_color' => '#cccccc',
  'ta_pagination_next_border_color' => '#1e73be',

  'ta_pagination_css' => $ta_pagination_css,

  'ta_show_related' => true,
  'ta_related_label' => 'Related Videos',
  'ta_related_label_color' => '#999999',
  'ta_related_font_family' => 'Helvetica, Arial, sans-serif',
  'ta_related_font_size' => '18',
  'ta_related_font_size_unit' => 'px',
  'ta_related_num_results' => '12',



);

$tubeace_defaults = str_replace('%','%%', $tubeace_defaults); 

?>