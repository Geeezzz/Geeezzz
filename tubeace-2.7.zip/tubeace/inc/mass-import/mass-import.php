<?php

# called by tubeace-import.php:
#
# if( get_site_option( 'tubeace_ajax_import' ) == 1 ) {
# 	require_once 'inc/mass-import/mass-import-ajax.php';
# } else {
# 	require_once 'inc/mass-import/mass-import.php';
# }
#

$upload_dir = wp_upload_dir();
$import_filename = $upload_dir['basedir'].'/tubeace-import.txt';

$fh = fopen($import_filename, 'r+');
$content = fread($fh, filesize($import_filename));
fclose($fh);

$content = trim($content);

$lines = explode("\n", $content);
$size = count($lines);

$line=1;
$num_added=0;

foreach($lines as $lines_key => $lines_val){

	if( tubeace_license_status() !== true){
		if( $line >= 11 ){
			echo'Demo limit reached. ';	
		 	break;
		}			
	}	
	
	$errorInsert = null;
	
	foreach($fields = explode($delimiter, $lines[$lines_key]) as $fields_key => $fields_val) {

		$fields_val = tubeace_prepare_csv_data($fields_val);

		$fields_val_con = trim($fields_val);

		if( !isset( $field[$fields_key] ) ){
			continue;
		}

		//get title to display below
		if($field[$fields_key]=='title'){
			$title = $fields_val_con;
		}
		if($field[$fields_key]=='description'){
			$description = $fields_val_con;
		}
		if($field[$fields_key]=='duration'){
			$duration = $fields_val_con;
		}
		if($field[$fields_key]=='tags'){
			$tags = $fields_val_con;

			// if semi-colon delimiter, replace with comma
			if (strpos($tags, ';') !== false) {
				$tags = str_replace(';', ',', $tags);
			}
		}			
		if($field[$fields_key]=='performers'){
			$performers = $fields_val_con;

			// if semi-colon delimiter, replace with comma
			if (strpos($performers, ';') !== false) {
				$performers = str_replace(';', ',', $performers);
			}
		}		
		if($field[$fields_key]=='sponsor_link_url'){
			$sponsor_link_url = $fields_val_con;
		}
		if($field[$fields_key]=='sponsor_link_txt'){
			$sponsor_link_txt = $fields_val_con;
		}			
		if($field[$fields_key]=='embed_code'){
			$embed_code = $fields_val_con;
		}				
		if($field[$fields_key]=='video_url'){
			$video_url = $fields_val_con;
		}
		if($field[$fields_key]=='site'){
			$site = $fields_val_con;
		}
		if($field[$fields_key]=='misc1'){
			$misc1 = $fields_val_con;
		}
		if($field[$fields_key]=='misc2'){
			$misc2 = $fields_val_con;
		}
		if($field[$fields_key]=='misc3'){
			$misc3 = $fields_val_con;
		}
		if($field[$fields_key]=='misc4'){
			$misc4 = $fields_val_con;
		}
		if($field[$fields_key]=='misc5'){
			$misc5 = $fields_val_con;
		}						

		//check for dups
		//video_url
		if($block_dups==1 && $field[$fields_key]=="video_url"){
		
			$query = "SELECT * FROM " . $wpdb->prefix . "postmeta WHERE meta_key = 'video_url' AND meta_value = '$fields_val_con'";
			$results = $wpdb->get_results($query);

			if($wpdb->num_rows>0){
				
				echo'<span class="tubeace-warnmsg">line # '.$line.' skipped - \'<a href="post.php?post='.$results[0]->post_id.'&action=edit">'.get_the_title($results[0]->post_id).'</a>\' Video URL already in database: 
				<a href="'.$fields_val_con.'" target="_blank">'.$fields_val_con.'</a></span><br>';
				$errorInsert=1;
			}
		}
		
		//embed_code
		if($block_dups==1 && $field[$fields_key]=="embed_code"){
		
			$query = "SELECT * FROM " . $wpdb->prefix . "postmeta WHERE meta_key = 'embed_code' AND meta_value = '$fields_val_con'";
			$results = $wpdb->get_results($query);

			if($wpdb->num_rows>0){
				
				echo'<span class="tubeace-warnmsg">line # '.$line.' skipped - \'<a href="post.php?post='.$results[0]->post_id.'&action=edit">'.get_the_title($results[0]->post_id).'</a>\' Embed Code already in database</span><br>';
				$errorInsert=1;
			}
		}

		// check word filter
		$tubeace_words_filter = get_site_option( 'tubeace_words_filter' );

		$wordsFilterArray = explode(',', $tubeace_words_filter);

		foreach($wordsFilterArray as $val){

			// title
			if (stripos($title, $val) !== false && !$errorInsert) {
				echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in title.</span><br>';
				$outputAll.= $output;
				$errorInsert=1;
				ob_flush();
				flush();	
			}

			// tags
			if( isset($tags)  ){
				if (stripos($tags, $val) !== false && !$errorInsert) {
					echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in tags.</span><br>';
					$outputAll.= $output;
					$errorInsert=1;
					ob_flush();
					flush();	
				}	
			}
			
		}

		//get thumb_url to check valid image, skip if already an error
		if($field[$fields_key]=='thumb_url' && $errorInsert!=1){
			
			$thumb_url = $fields_val_con;

			// multiple thumbs is possible, so create explode into array
			// if comma delimiter
			if (strpos($thumb_url, ',http') !== false) {
				$thumbsArr = explode(',', $fields_val_con);
			} elseif (strpos($thumb_url, ';http') !== false) {// if semi-colon delimiter
				$thumbsArr = explode(';', $fields_val_con);
			} else {
				$thumbsArr = explode('|', $fields_val_con);
			}

			//check thumbs
			foreach($thumbsArr as $val){

				if(!@getimagesize($val)){
					echo'<span class="tubeace-errormsg">line # '.$line.' skipped - <b>\''.$title.'\'</b> Thumbnail URL '.$val.' invalid.</span><br>';
					$errorInsert=1;
				}
			}
		}
	}

	if(!$errorInsert){

		//description can't be empty
		if( !isset($description) ){
			$description = ' ';
		}
	
		$performersArr = null;
		if( isset($performers) ){
			$performersArr = explode(",", $performers);
		}
		
		//don't show until thumbs created
		if( $status=='publish' ){
			$post_status = 'pending';
		} else {
			$post_status = $status;
		}
		
		$post_date = null;

		if($post_status=='future'){
			$post_date = '2030-01-01 00:00:00';//must enter future date, or else will be set as 'publish'
		}

		//insert
		$my_post = array(
		  'post_title'    => $title,
		  'post_content'  => $description,
		  'post_date'  	  => $post_date,
		  'post_status'   => $post_status,
		  'post_author'   => $sponsor,
		  'post_category' => $post_category,
		  'tax_input' => array( 'performer' => $performersArr ) 
		);

		if( isset($tags) ){
			$my_post['tags_input'] = $tags;
		}

		// Insert the post into the database
		if($lastID = wp_insert_post( $my_post )){

			//$duration = null;
			if( isset($duration) ){

				// duration matches 1h2m3s format
				preg_match('/((\d+)h)?(\d+)m(\d+)s/', $duration, $matches);

				if( !empty($matches)){
				    
				    $h = $matches[2];   
				    $m = $matches[3];   
				    $s = $matches[4];

				    if($h>0){
				        $hou = $h * 60 * 60;
				    } else {
				        $hou = 0;
				    }

				    if($m>0){
				        $sec = $m * 60;
				    } else {
				        $sec = 0;
				    }

				    $duration = $hou + $sec + $s;
				}

				// duration matches 00:00:00 format
				preg_match("/((\d?\d):)?(\d?\d):(\d?\d)$/", $duration, $matches);

				$hours = 0;
				$minutes = 0;
				$seconds = 0;

				if( !empty($matches) ){

				    $hours = $matches[2];
				    $minutes = $matches[3];
				    $seconds = $matches[4];

				    $duration = $hours * 3600 + $minutes * 60 + $seconds;
				}

			}



			//add meta value
            if( !empty($video_url) ){
                add_post_meta($lastID, 'video_url', $video_url);
            }
            if( !empty($embed_code) ){
                add_post_meta($lastID, 'embed_code', $embed_code);
            }
            if( !empty($thumb_url) ){
                add_post_meta($lastID, 'thumb_url', $thumb_url);
            }	                    		
            if( !empty($duration) ){
                add_post_meta($lastID, 'duration', $duration);
            }				
            if( !empty($site) ){
                add_post_meta($lastID, 'site', $site);
            }			
            if( !empty($sponsor_link_url) ){
                add_post_meta($lastID, 'sponsor_link_url', $sponsor_link_url);
            }
            if( !empty($sponsor_link_txt) ){
                add_post_meta($lastID, 'sponsor_link_txt', $sponsor_link_txt);
            }
            if( !empty($misc1) ){
                add_post_meta($lastID, 'misc1', $misc1);
            }
            if( !empty($misc2) ){
                add_post_meta($lastID, 'misc2', $misc2);
            }
            if( !empty($misc3) ){
                add_post_meta($lastID, 'misc3', $misc3);
            }
            if( !empty($misc4) ){
                add_post_meta($lastID, 'misc4', $misc4);
            }
            if( !empty($misc5) ){
                add_post_meta($lastID, 'misc5', $misc5);
            }

			echo'<span class="tubeace-succmsg">line # '.$line.' titled <b>\''.stripslashes($title).'\'</b> added.</span><br>';

            // video post format
            if( get_site_option( 'tubeace_import_as_video_post_format' ) == '1' ){

                $format = 'video';
                set_post_format( $lastID , $format);
            }   

			if( count($thumbsArr) > 1 ){
				$featured_img = $thumbsArr[0];//first image
			} else {
				$featured_img = $thumb_url; // only one image
			}

            // save thumbs to server or store source URLs
            if( get_site_option( 'tubeace_mass_import_save_thumbs' ) == 1 ){ // save thumbs to server

				// multiple thumbs
				tubeace_create_thumbs('mass_import', $lastID, $thumbsArr, 'mass_import', 1);		            		
	            	
		        // create featured image
		        tubeace_create_featured_image($lastID, $featured_img);


            } else { // serve from CDN

            	$thumbs_src = '';

            	if( !empty($thumbsArr) ){

	            	// create string of semicolon separated thumbs
	            	foreach($thumbsArr as $val){

	            		$thumbs_src.= $val.';';
	            	}
            	}

            	$thumbs_src = rtrim($thumbs_src, ";");

            	if( !empty($thumbs_src) ){
            		add_post_meta($lastID, 'thumbs_src', $thumbs_src);
            	}
            	
            	add_post_meta($lastID, 'def_thumb_url', $featured_img);
            	add_post_meta($lastID, '_thumbnail_id', '6969TA' ); // needed for post_thumbnail_html hook to load            	

            }

            // handle set all's
            $update_post = array( 'ID' => $lastID );
            // post date
            if( !empty( $_GET['setall_post_date'] ) ){
            	$update_post['post_date'] = $_GET['setall_post_date'];
            }
            // title
            if( !empty( $_GET['setall_title'] ) ){
            	$update_post['post_title'] = $_GET['setall_title'];
            }
            // description
            if( !empty( $_GET['setall_description'] ) ){
            	$update_post['post_content'] = $_GET['setall_description'];
            }
            // taxonomies
            // tags
            if( !empty( $_GET['setall_tags'] ) ){
				$update_post['tags_input'] = $_GET['setall_tags'];
            }
            // performers
            if( !empty( $_GET['setall_performers'] ) ){
            	$performersArr = explode(",", $_GET['setall_performers']);
				$update_post['tax_input'] = array( 'performer' => $performersArr );
            }
			// post status, thumbs are now created
			if( $status=='publish' ){
				$update_post['post_status'] = 'publish';
			}

            wp_update_post( $update_post );

            //post meta
            // duration
            if( !empty( $_GET['setall_duration'] ) ){
            	update_post_meta($lastID, 'duration', $_GET['setall_duration']);
            }
            // site
            if( !empty( $_GET['setall_site'] ) ){
            	update_post_meta($lastID, 'site', $_GET['setall_site']);
            }
            // sponsor_link_url
            if( !empty( $_GET['setall_sponsor_link_url'] ) ){
            	update_post_meta($lastID, 'sponsor_link_url', $_GET['setall_sponsor_link_url']);
            }
            // sponsor_link_txt
            if( !empty( $_GET['setall_sponsor_link_txt'] ) ){
            	update_post_meta($lastID, 'sponsor_link_txt', $_GET['setall_sponsor_link_txt']);
            }
            // misc1
            if( !empty( $_GET['setall_misc1'] ) ){
            	update_post_meta($lastID, 'misc1', $_GET['setall_misc1']);
            }
            // misc2
            if( !empty( $_GET['setall_misc2'] ) ){
            	update_post_meta($lastID, 'misc2', $_GET['setall_misc2']);
            }
            // misc3
            if( !empty( $_GET['setall_misc3'] ) ){
            	update_post_meta($lastID, 'misc3', $_GET['setall_misc3']);
            }
            // misc4
            if( !empty( $_GET['setall_misc4'] ) ){
            	update_post_meta($lastID, 'misc4', $_GET['setall_misc4']);
            }
            // misc5
            if( !empty( $_GET['setall_misc5'] ) ){
            	update_post_meta($lastID, 'misc5', $_GET['setall_misc5']);
            }

            $num_added++;           

		} else {
			echo'<span class="tubeace-errormsg">line # '.$line.' titled '.stripslashes($title).' not added.</span><br>';
		}

		//auto-scheduling
		if(get_site_option('tubeace_schedule_per_day')>0){
			
			$schedDate = tubeace_auto_sched_next_date(0);

			$wpdb->update( $wpdb->prefix . 'posts', array('post_date' => "$schedDate 00:00:00", 'post_date_gmt' => "$schedDate 00:00:00"), array('id' => $lastID));
								
			echo'<span class="tubeace-succmsg">Video #'.$lastID.' Auto-Scheduled to '.$schedDate.'</span><br>';
		}

	}
	$line++;
	
	ob_flush();
	flush();
}

echo '<br><b>Import Complete. Added '.$num_added.' videos to the database.</b>';

?>