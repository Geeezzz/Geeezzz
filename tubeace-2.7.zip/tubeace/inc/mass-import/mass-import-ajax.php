<?php

# called by tubeace-import.php:
#
# if( get_site_option( 'tubeace_ajax_import' ) == 1 ) {
# 	require_once 'inc/mass-import/mass-import-ajax.php';
# } else {
# 	require_once 'inc/mass-import/mass-import.php';
# }
#
######
# $field > tubeace-import.php



// The JavaScript
function tubeace_mass_import_javascript() {
  //Set Your Nonce
  $ajax_nonce = wp_create_nonce( 'my-special-string' );
  ?>
  <script>

	jQuery(document).ready(function ($) {

		//only load if on last page
		if(typeof(jQuery('#delimiter').val()) != "undefined" && jQuery('#delimiter').val() !== null){
			//var line = 1;
			process(1,0);
		}
	});

	function process(line,num_added){
		
		var status = jQuery('#status').val();
		var delimiter = jQuery('#delimiter').val();
		var field = encodeURIComponent(jQuery('#field').val());
		var sponsor = jQuery('#sponsor').val();
		var post_category = jQuery('#post_category').val();
		var block_dups = jQuery('#block_dups').val();
		var first_id = jQuery('#first_id').val();
		
		var dataString = 'action=my_action&line='+line+'&num_added='+num_added+'&';

		dataString = dataString + 'status='+status+'&';
		dataString = dataString + 'delimiter='+delimiter+'&';
		dataString = dataString + 'field='+field+'&';
		dataString = dataString + 'sponsor='+sponsor+'&';
		dataString = dataString + 'post_category='+post_category+'&';
		dataString = dataString + 'block_dups='+block_dups+'&';
		dataString = dataString + 'first_id='+first_id+'&';
		
		var setAlls=new Array('post_date','duration','title','description','tags','performers','site','sponsor_link_url','sponsor_link_txt','misc1','misc2','misc3','misc4','misc5');
		
		jQuery.each(setAlls, function(key, value) { 
		  dataString = dataString + 'setall_'+value+'='+encodeURIComponent(jQuery('#'+value).val())+'&';
		});	
		
		jQuery.ajax({
		  type: "POST",
		  dataType: 'json',
		  url: ajaxurl,
		  data: dataString,
		  
		  success: function(json){

			jQuery('#response').append(json.response);
			
			if(json.done==1){
				jQuery('#tubeace-loading').remove();
				return;
				
			} else {
				
				//increment
				line = line+1;
				
				process(line, json.num_added);
			}
		
		  }
		});
	}

  </script>
  <?php
}
add_action( 'admin_footer', 'tubeace_mass_import_javascript' );	


 // save field order to retrieve in AJAX
update_site_option('tubeace_ajax_import_field_order', serialize($field));

$post_category = json_encode($post_category);

echo'
<input id="status" type="hidden" value="'.$status.'">
<input id="delimiter" type="hidden" value="'.$delimiter.'">
<input id="sponsor" type="hidden" value="'.$sponsor.'">
<input id="post_category" type="hidden" value=\''.$post_category.'\'>
<input id="block_dups" type="hidden" value="'.$block_dups.'">';

$setall_array = array('post_date','duration','title','description','tags','performers','site','sponsor_link_url','sponsor_link_txt','misc1','misc2','misc3','misc4','misc5');
foreach($setall_array as $value){
	
	echo'<input id="'.$value.'" type="hidden" value="'.$_GET['setall_'.$value].'">';
}

echo'<div id="response"></div>';
echo'<img id="tubeace-loading" src="'.plugins_url("tubeace/images/loading.gif").'">';

?>