<?php

// The function that handles the AJAX request
function tubeace_redtube_api_import_callback() {

    global $wpdb;
    check_ajax_referer( 'my-special-string', 'security' );

    $site = $_POST['site'];

    $keyword = $_POST['keyword'];
    $tag = $_POST['tag'];

    $start = $_POST['start'];
    $end = $_POST['end'];

    $ordering = $_POST['ordering'];

    //xhamster
    $cats = json_decode(stripslashes($_POST['cats']));
    $cnt = $_POST['cnt'];
    $resolution = $_POST['resolution'];
    $period = $_POST['period'];
    $orderby = $_POST['orderby'];
    $rating_min = $_POST['rating_min'];
    $views_min = $_POST['views_min'];
    
    $ratings_num_min = $_POST['ratings_num_min'];

    $status = $_POST['status'];
    $sponsor = $_POST['sponsor'];
    $post_date = $_POST['post_date'];
    $post_category = json_decode(stripslashes($_POST['post_category']));

    $description = $_POST['description'];
    $tags_set_all = $_POST['tags_set_all'];
    $tags_method = $_POST['tags_method'];
    $performers_set_all = $_POST['performers_set_all'];
    $performers_method = $_POST['performers_method'];
    $sponsor_link_txt = $_POST['sponsor_link_txt'];
    $sponsor_link_url = $_POST['sponsor_link_url'];
    $misc1 = $_POST['misc1'];
    $misc2 = $_POST['misc2'];
    $misc3 = $_POST['misc3'];
    $misc4 = $_POST['misc4'];
    $misc5 = $_POST['misc5'];

    $per_page = intval($_POST['per_page']);
    $page = intval($_POST['page']);
    $video_count = $_POST['video_count'];

    $report = '';
    $done = '';
    $no_results = '';

    $siteArray = tubeace_api_site_array($site);

    // replace + with space before urlencode to prevent space from becoming %2B
    $keyword = str_replace('+', ' ', $keyword);

    // urlencode for API call
    $keyword = urlencode($keyword);

    $channelStr = '';

    if(!empty($cats)){
        
        $N = count($cats);
        for($i=0; $i < $N; $i++){
          $channelStr.= '.'.$cats[$i];
        }

    }

    // make new call
    if( $video_count == 0){

        if($siteArray['site']=='redtube'){

            //tags param must not be empty in API call
            if(!empty($tag) ){
                $tags = '&tags[]='.$tag;
            } else {
                $tags = '';
            }            
            $call = 'http://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search='.$keyword.$tags.'&thumbsize='.get_site_option( 'tubeace_redtube_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
        }

        if($siteArray['site']=='pornhub'){
            $call = 'http://www.pornhub.com/webmasters/search?search='.$keyword.'&thumbsize='.get_site_option( 'tubeace_pornhub_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
        }

        if($siteArray['site']=='tube8'){
            $call = 'http://api.tube8.com/api.php?action=searchVideos&output=json&search='.$keyword.'&thumbsize='.get_site_option( 'tubeace_tube8_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
        }

        if($siteArray['site']=='youporn'){
            $call = 'http://www.youporn.com/api/webmasters/search?search='.$keyword.'&thumbsize='.get_site_option( 'tubeace_youporn_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
        }

        if($siteArray['site']=='xhamster'){
            // ch - channel
            // cnt - count
            // content-type - resolution
            // tmb - thumb size
            // tcnt - thumb count
            // pr - period
            // ord - order
            // rt - rating minimum
            // views - views minimum

            $call = 'https://partners.xhamster.com/2export.php?ch='.$channelStr.'&cnt='.$cnt.'&content-type='.$resolution.'&tmb='.get_site_option( 'tubeace_xhamster_api_thumb_size' ).'&tcnt='.get_site_option( 'tubeace_xhamster_api_num_thumbs' ).'&pr='.$period.'&ord='.$orderby.'&rt='.$rating_min.'&views='.$views_min.'&owner=all&trailer_size=320&tl=on&url=on&vid=on&ttl=on&chs=on&sz=on';
        }

        $video_data = file_get_contents($call);

        update_site_option('redtube_api_data', $video_data);

        $report.='<b>API Call URL:</b> <a href="'.$call.'" target="_blank">'.$call.'</a><br>';

        // get actual count
        if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){
            
            $video_count_data = json_decode($video_data);

            if($siteArray['site']=='youporn'){
                $videos_count = $video_count_data->video;
            } else {
                $videos_count = $video_count_data->videos;
            }
            $per_page = count($videos_count);  

            $report.='<b>Results Returned on Page '.$page.':</b> '.$per_page.'<br>';
        }        
        if($siteArray['site']=='xhamster'){

            // get actual number for count so we know when we're done cycling through dump
            $lines = explode("\n", $video_data);

            $per_page = count($lines) - 2;  // subtract 1 for first line of fields, and another for last line

            $report.='<b>Results Returned:</b> '.$per_page.'<br>';
        }
        

    } else {
        $video_data = get_site_option('redtube_api_data');
    }

    if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){
        
        $video_data = json_decode($video_data);

        // prepare title, video id, duration, tags, performers
        include 'api-import-ajax-callback-hubtraffic.php';
    }
    if($siteArray['site']=='xhamster'){

        // prepare title, video id, duration, tags, performers
        include 'api-import-ajax-callback-xhamster.php';

        if( tubeace_license_status() !== true){

            if( $video_count >= 10 ){

                $report.='Demo limit reached. '; 

                $done = 1;

                $resp = array('report' => $report, 'done' => $done);
                wp_send_json($resp);

                die(); // this is required to return a proper result

            }           
        } 
    }  



    $display_video_count = $video_count + 1;

    //check for duplicates
    $args = array(
        'meta_query' => array(
         'relation' => 'AND',
            array(
                'key' => 'video_id',
                'value' => $video_id,
            ),
            array(
                'key' => 'site',
                'value' => $siteArray['domain']
            )
        )
    );
    $query = new WP_Query( $args );
    $num_rows = $query->found_posts;

    if($num_rows>0){ // is duplicate
        $report.='<span class="tubeace-warnmsg">Video titled <b>\''.stripslashes($title).'\'</b>  of video #'.$display_video_count.' skipped. Already exists in database.</span><br>';
    } else { // not duplicate

        // xhaster rating filter done at API call
        if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){

            // check minimum rating
            if( $rating_min > $rating ){

                $report.='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$rating.' rating does not meet minimum rating.</span><br>';
                $errorInsert=1;         
            }

            // check minimum # ratings
            if( ($ratings_num_min > $ratings) && !$errorInsert ){

                $report.='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$ratings.' ratings does not meet minimum # ratings.</span><br>';
                $errorInsert=1;          
            }
        }

        // check word filter
        $tubeace_words_filter = get_site_option( 'tubeace_words_filter' );

        $wordsFilterArray = explode(',', $tubeace_words_filter);

        foreach($wordsFilterArray as $val){

            // title
            if (stripos($title, $val) !== false && !$errorInsert) {
                $report.='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in title.</span><br>';
                $errorInsert=1; 
            }

            // tags
            if (stripos($tags, $val) !== false && !$errorInsert) {
                $report.='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in tags.</span><br>';
                $errorInsert=1;   
            }               

            // categories
            if (stripos($categories, $val) !== false && !$errorInsert) {
                $report.='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in categories.</span><br>';
                $errorInsert=1;
            }   
        }        

        // check thumbs array
        if(!$errorInsert && !empty($thumbsArr)){

            //check thumbs valid
            foreach($thumbsArr as $val){

                $thumb_src = $val;

                if($site=='redtube' || $site=='pornhub' || $site=='tube8' || $site=='youporn'){


                    // redtube thumbs in object
                    if( !empty( $val->src ) ){
                        $thumb_src = $val->src;
                    }

                    // tube8 uses protocol-relative URLs, add https:// if not already there
                    if (false === strpos($thumb_src, '://')) {
                        $thumb_src = "https:" . $thumb_src;
                    }

                }

                if( !@getimagesize($thumb_src) && !$errorInsert ){
                    $report.= '<span class="tubeace-errormsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - Thumbnail URL \'<a href="'.stripslashes($thumb_src).'" target="_blank">'.stripslashes($thumb_src).'</a>\' invalid.</span><br>';
                    $errorInsert=1;
                }           
            }                   
        }

        // check single thumb only
        if(!$errorInsert && empty($thumbsArr)){             

            if(!@getimagesize($featured_img) && !$errorInsert){
                $report.= '<span class="tubeace-errormsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - Thumbnail URL \'<a href="'.stripslashes($featured_img).'" target="_blank">'.stripslashes($featured_img).'</a>\' invalid.</span><br>';
                $errorInsert=1;                 
            }
        }        

        if(!$errorInsert && !$no_results){

            // tags set all
            if( !empty($tags_set_all) ){

                if( $tags_method=='merge' ){
                    $tags = $tags.','.$tags_set_all;
                }

                if( $tags_method=='overwrite' ){
                    $tags = $tags_set_all;
                }
            }

            // performers set all
            if( !empty($performers_set_all) ){

                $performers_set_allArr = explode(',', $performers_set_all);

                // check performersArr not empty
                if( $performers_method=='merge' && is_array($performersArr) ){
                    $performersArr = array_merge($performersArr, $performers_set_allArr);
                }

                // performersArr empty
                if( $performers_method=='merge' && empty($performersArr) ){
                    $performersArr = $performers_set_allArr;
                }                   

                if( $performers_method=='overwrite' ){
                    $performersArr = $performers_set_allArr;
                }
            }
    
            // make pending until thumb generated
            if($status=="publish"){
                $status_alt = "draft";
            } 

            // insert
            $my_post = array(
              'post_title'    => $title,
              'post_content'  => $description,
              'post_status'   => $status_alt,
              'post_author'   => $sponsor,
              'post_category' => $post_category,
              'tags_input' => $tags
              //'tax_input' => array( 'performer' => $performersArr ) // won't work for cron
            );

            // Insert the post into the database
            if($lastID = wp_insert_post( $my_post )){

                //custom taxonomy must be done using wp_set_object_terms() for cron
                wp_set_object_terms($lastID, $performersArr, 'performer');                          

                //add meta value
                add_post_meta($lastID, 'video_id', $video_id);
                add_post_meta($lastID, 'url', $url);
                add_post_meta($lastID, 'duration', $duration);
                add_post_meta($lastID, 'site', $siteArray['domain']);
                if( !empty($sponsor_link_url) ){
                    add_post_meta($lastID, 'sponsor_link_url', $sponsor_link_url);
                }
                if( !empty($sponsor_link_txt) ){
                    add_post_meta($lastID, 'sponsor_link_txt', $sponsor_link_txt);
                }
                if( !empty($misc1) ){
                    add_post_meta($lastID, 'misc1', $misc1);
                }
                if( !empty($misc2) ){
                    add_post_meta($lastID, 'misc2', $misc2);
                }
                if( !empty($misc3) ){
                    add_post_meta($lastID, 'misc3', $misc3);
                }
                if( !empty($misc4) ){
                    add_post_meta($lastID, 'misc4', $misc4);
                }
                if( !empty($misc5) ){
                    add_post_meta($lastID, 'misc5', $misc5);
                }                

                $report.='<span class="tubeace-succmsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' added.</span><br>';
            } else {
                $report.='<span class="tubeace-errormsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' not added.</span><br>';
            }

            // video post format
            if( get_site_option( 'tubeace_import_as_video_post_format' ) == '1' ){

                $format = 'video';
                set_post_format( $lastID , $format);
            }   

            // save thumbs to server or store source URLs
            if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_save_thumbs' ) == 1 ){ // save thumbs to server


                // if not default thumb only, do multiple thumbs
                if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) != 1 ){

                    // detect default thumb #
                    $def_thmb = tubeace_detect_def_thmb($siteArray['site'], $featured_img, $thumbsArr, 'api');

                    // multiple thumbs
                    tubeace_create_thumbs($siteArray['site'], $lastID, $thumbsArr, 'api', $def_thmb);                           
                }

                // create featured image
                tubeace_create_featured_image($lastID, $featured_img);

            } else { // don't save thumbs, serve from cdn

                $thumbs_src = '';

                if( !empty($thumbsArr) ){

                    // create string of semicolon separated thumbs
                    foreach($thumbsArr as $val){

                        // get thumb from object
                        if( !empty( $val->src ) ){
                            $val = $val->src;
                        }

                        // tube8 uses protocol-relative URLs now for $val->src;
                        if (false === strpos($val, '://')) {
                            $val = "https:" . $val;
                        }

                        $thumbs_src.= $val.';';
                    }

                }

                $thumbs_src = rtrim($thumbs_src, ";");

                if($siteArray['site']=='xhamster'){
                    // use https
                    $thumbs_src = str_replace("http://", "https://", $thumbs_src);
                    $featured_img = str_replace("http://", "https://", $featured_img);
                }

                if( !empty($thumbs_src) ){
                    add_post_meta($lastID, 'thumbs_src', $thumbs_src);
                }
                
                add_post_meta($lastID, 'def_thumb_url', $featured_img);
                add_post_meta($lastID, '_thumbnail_id', '6969TA' ); // needed for post_thumbnail_html hook to load
            }


            //thumbs generated, now set to publish
            if($status=="publish"){

                $my_post = array(
                  'ID'           => $lastID,
                  'post_status' => 'publish'
                );
                wp_update_post( $my_post );
            }                       

            //auto-scheduling
            if(get_site_option('tubeace_schedule_per_day')>0){
                
                $schedDate = tubeace_auto_sched_next_date(0);

                $wpdb->update( $wpdb->prefix . 'posts', array('post_date' => "$schedDate 00:00:00", 'post_date_gmt' => "$schedDate 00:00:00"), array('id' => $lastID));
                                    
                $report.="<span class=\"tubeace-succmsg\">Video #$lastID Auto-Scheduled to $schedDate</span><br>";
            }
        }
    }


    $video_count++;
    // $video_count -  starts at 0 
    // $page -  current page in loop
    // $per_page -  number of video per page. varies for each API

    //check if done cycling through all pages
    if($page == $end && $video_count == $per_page+1){
        $done = 1;
    } elseif($video_count == $per_page+1) { //increment page number & reset video count
        $page++;
        $video_count=0;
    }

    $resp = array('status' => $status, 'report' => $report, 'video_page' => $page, 'per_page' => $per_page, 'video_count' => $video_count, 'video_data' => json_encode($video_data), 'no_results' => $no_results, 'done' => $done);
    wp_send_json($resp);

    die(); // this is required to return a proper result
}
add_action( 'wp_ajax_tubeace_redtube_api_import', 'tubeace_redtube_api_import_callback' );

