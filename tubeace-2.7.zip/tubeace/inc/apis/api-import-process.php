<?php 

ob_flush();
flush();

// outputAll used for cron emails
$output = $outputAll = '';

// replace + with space before urlencode to prevent space from becoming %2B
$keyword = str_replace('+', ' ', $keyword);

// urlencode for API call
$keyword = urlencode($keyword);

$channelStr = '';

if(!empty($cats)){

	$N = count($cats);

	for($i=0; $i < $N; $i++){
	  $channelStr.= '.'.$cats[$i];
	}

}

for($page=$start;$page<=$end;$page++){

	if($siteArray['site']=='pornhub'){
		$call = 'http://www.pornhub.com/webmasters/search?search='.$keyword.'&thumbsize='.get_site_option( 'tubeace_pornhub_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
	}

    if($siteArray['site']=='redtube'){
    	
    	//tags param must not be empty in API call
		if(!empty($tag) ){
			$tags = '&tags[]='.$tag;
		} else {
			$tags = '';
		}

        $call = 'http://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search='.$keyword.$tags.'&thumbsize='.get_site_option( 'tubeace_redtube_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
    }

	if($siteArray['site']=='tube8'){
		$call = 'http://api.tube8.com/api.php?action=searchVideos&output=json&search='.$keyword.'&thumbsize='.get_site_option( 'tubeace_tube8_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
	}

	if($siteArray['site']=='youporn'){
		$call = 'http://www.youporn.com/api/webmasters/search?search='.$keyword.'&thumbsize='.get_site_option( 'tubeace_youporn_api_thumb_size' ).'&page='.$page.'&ordering='.$ordering;
	}

	if($siteArray['site']=='xhamster'){
		// ch - channel
		// cnt - count
		// content-type - resolution
		// tmb - thumb size
		// tcnt - thumb count
		// pr - period
		// ord - order
		// rt - rating minimum
		// views - views minimum

		$call = 'https://partners.xhamster.com/2export.php?ch='.$channelStr.'&cnt='.$cnt.'&content-type='.$resolution.'&tmb='.get_site_option( 'tubeace_xhamster_api_thumb_size' ).'&tcnt='.get_site_option( 'tubeace_xhamster_api_num_thumbs' ).'&pr='.$period.'&ord='.$orderby.'&rt='.$rating_min.'&views='.$views_min.'&owner=all&trailer_size=320&tl=on&url=on&vid=on&ttl=on&chs=on&sz=on';
	}

	echo $output = '<div style="word-wrap:break-word;"><b>API Call URL:</b> <a href="'.$call.'" target="_blank">'.$call.'</a><br></div>';

	ob_flush();
	flush();

	$data = file_get_contents($call);

	if($siteArray['site']=='youporn'){
		$data = json_decode($data);
		$videos	= $data->video;

		$per_page = count($videos);  
		echo'<b>Results Returned on Page '.$page.':</b> '.$per_page.'<br>';
	} 
	if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='tube8'){
		$data = json_decode($data);	
		$videos	= $data->videos;

		$per_page = count($videos);  
		echo'<b>Results Returned on Page '.$page.':</b> '.$per_page.'<br>';		
	}
	if($siteArray['site']=='xhamster'){

		// trim last line before explode 
		$data = rtrim($data,"\n");

		$lines = explode("\n", $data);

		// remove first line (field order)
		array_shift($lines);

		// remove last line
		//$fruit = array_pop($lines);

        $per_page = count($lines);

		echo'<b>Results Returned:</b> '.$per_page.'<br>';

	} 

	// include process
	if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){
		//include
		require 'api-import-process-hubtraffic.php';
	}
	if($siteArray['site']=='xhamster'){
		//include
		require 'api-import-process-xhamster.php';
	} 	

	#cron update
	// if running as cron
	if(isset($tubeace_is_running_cron)==1){
	    $option_values = get_site_option($option_name);

		$cronValues = $option_values;
		$cronValues['running_current_page'] = $page;
		$cronValues['running_last_page_timestamp'] = current_time('timestamp'); // to detect stall

		if(get_site_option('tubeace_cron_set_last_page_as_start') == 1){
			$cronValues['start'] = $page;
		}

	    update_site_option($option_name, $cronValues);
	}
}
