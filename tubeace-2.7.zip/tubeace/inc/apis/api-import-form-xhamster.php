<?php

function tubeace_xham_select_all_cats() {
?>
  <script>

  jQuery(document).ready(function ($) {
    jQuery('#xham_select_all_cats').click(function() {
        jQuery(".xham_cats_chkbxs").attr( "checked" , true );
    });
  });

  </script>
  <?php
}
add_action( 'admin_footer', 'tubeace_xham_select_all_cats' ); 


function tubeace_xham_unselect_all_cats() {
?>
  <script>

  jQuery(document).ready(function ($) {
    jQuery('#xham_unselect_all_cats').click(function() {
        jQuery(".xham_cats_chkbxs").attr( "checked" , false );
    });
  });

  </script>
  <?php
}
add_action( 'admin_footer', 'tubeace_xham_unselect_all_cats' ); 

?>

<table class="form-table">
  <tbody>

    <tr>
      <th>Select categories</th>
      <td><div id="xham_cats" style="max-height: 400px;width: 400px;overflow: scroll;">
    
    <?php
    $categoriesArr = tubeace_api_export_categories_array('xhamster');

		foreach($categoriesArr as $key => $val){
		    echo '<input type="checkbox" class="xham_cats_chkbxs" id="cats_'.$key.'" name="cats[]" value="'.$key.'"> <label for="cats_'.$key.'">'.$val.'</label><br>';
		}
      	?></div>

        <br><a href ='#' id="xham_select_all_cats">Select All</a>
        <br><a href ='#' id="xham_unselect_all_cats">Unselect All</a>
      </td>
	</tr>

    <tr>
      <th><label for="cnt"># of Videos to Import</label></th>
      <td>
      	<select name="cnt" id="cnt">
      		<option value="0">100</option>
      		<option value="1">500</option>
      		<option value="2">1000</option>
      		<option value="3">5000</option>
      		<option value="4">10000</option>
      		<option value="5">50000</option>

      	</select>
      </td>
    </tr>

    <tr>
      <th><label for="resolution">Video Resolution</label></th>
      <td>
      	<select name="resolution" id="resolution">
      		<option value="0">All</option>
      		<option value="1">HD</option>
      	</select>
      </td>
    </tr>

    <tr>
      <th><label for="period">Period</label></th>
      <td>
      	<select name="period" id="period">
      		<option value="0">Any Time</option>
      		<option value="1">Last day (1 Day)</option>
      		<option value="2">Last week (7 Days)</option>
      		<option value="3">Last month (30 Days)</option>
      	</select>
      </td>
    </tr>

    <tr>
      <th><label for="orderby">Order By</label></th>
      <td>
      	<select name="orderby" id="orderby">
      		<option value="0">Added Time</option>
      		<option value="1">Rating</option>
      		<option value="2">View Count</option>
      	</select>
      </td>
    </tr>

    <tr>
      <th><label for="rating_min">Rating more than</label></th>
      <td>
      	<select name="rating_min" id="rating_min">
      		<option value="0">0%</option>
      		<option value="1">40%</option>
      		<option value="2">60%</option>
      		<option value="3">80%</option>
      	</select>
      </td>
    </tr>

    <tr>
      <th><label for="views_min">Views more than</label></th>
      <td>
      	<select name="views_min" id="views_min">
      		<option value="0">Any</option>
      		<option value="1">1000</option>
      		<option value="2">5000</option>
      		<option value="3">10000</option>
      	</select>
      </td>
    </tr>


  </tbody>
</table>
