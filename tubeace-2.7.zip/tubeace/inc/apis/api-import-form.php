<?php

// call form 
if( empty($_POST) && empty($_GET['cron']) && empty($_GET['all']) && empty($_GET['single']) && empty($_GET['single_import']) ) {

	tubeace_api_form($siteArray);
}

// form
function tubeace_api_form($siteArray, $vars=null){

	// pass $vars back to form since it's possible a cron job was attempted to be created with used name or no job name given
	$keyword = $vars['keyword'];
	$tag = $vars['tag'];

	$start = ( empty($vars['start'] ) ) ? 1 : $vars['start'];
	$end = ( empty($vars['end'] ) ) ? 20 : $vars['end'];

	if( !empty($vars['rating_min']) ){
		$rating_min = $vars['rating_min'];
	} else {

		if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){
			$rating_min = 70;
		}
	}

	if( !empty($vars['ratings_num_min']) ){
		$ratings_num_min = $vars['ratings_num_min'];
	} else {

		if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){
			$ratings_num_min = 5;
		}
	}

	if( !empty($vars['status']) ){
		$status = ucfirst($vars['status']);
		$status = '<option value="'.$vars['status'].'">'.$status.'</option>';
	}

	$post_date = ( empty($vars['post_date'] ) ) ? date("Y-m-d H:i:s") : $vars['post_date'];

	//create vars
	$selected_cats = null;

	if( isset($vars['post_category']) ){
		$selected_cats = $vars['post_category'];
	}
	
	$description = $vars['description'];
	$tags = $vars['tags'];
	$performers = $vars['performers'];
	$sponsor_link_txt = $vars['sponsor_link_txt'];
	$sponsor_link_url = $vars['sponsor_link_url'];
	$misc1 = $vars['misc1'];
	$misc2 = $vars['misc2'];
	$misc3 = $vars['misc3'];
	$misc4 = $vars['misc4'];
	$misc5 = $vars['misc5'];

	if( !empty($vars['cron_frequency']) ){

		if($vars['cron_frequency']=='hourly'){
			$cron_frequency = '<option value="hourly">Hourly</option>';
		}

		if($vars['cron_frequency']=='twicedaily'){
			$cron_frequency = '<option value="twicedaily">Twice Daily</option>';
		}

		if($vars['cron_frequency']=='daily'){
			$cron_frequency = '<option value="daily">Daily</option>';
		}
	}	
?>

<div class="wrap">

	<h2><?php echo $siteArray['site_name'] ?> API Import <span style="float:right"><small><small><span class="dashicons dashicons-paperclip"></span><a href="https://tubeace.com/docs/<?php echo $siteArray['site']; ?>-api-import/" target="_blank">Documentation</a></small></small></span></h2>

	<?php
	if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn' ){
	?>
		<div class="tubeace-api-single-video">
			<h3>Import Single Video</h3>
			<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-'.$siteArray['site'].'-api.php'); ?>" method="get">
				<table class="form-table">
				  <tbody>
				    <tr>
				    	<th><label for="video_id"><?php echo $siteArray['site_name']; ?> Video ID</label></th>
				      <td>
				        <input name="video_id" type="text" class="tubeace-input-160" id="id">
				        <small>Example: <?php echo $siteArray['single_example_id']; ?></small>
				      </td>		        	
				    </tr>	
				    <tr>
				    	<td></td>
			        <td>
			        	<input type="hidden" name="page" value="tubeace/tubeace-<?php echo $siteArray['site'] ?>-api.php">
			        	<input type="submit" value="View" class="button-primary" name="single">
			        </td>		        	
				     </tr>	
				  </tbody>
				</table>
			</form>
		</div>
	<?php
	}
	?>


	<div class="tubeace-api-all-videos">
		<h3>Import Videos by 
			<?php

			if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='youporn' ) echo 'Keyword / Tag';

			if( $siteArray['site']=='tube8' ) echo'Keyword';

			if( $siteArray['site']=='xhamster' ) echo'Category';
			?>

		</h3>
		<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-'.$siteArray['site'].'-api.php'); ?>" method="get">

			<?php 

			//include form based on site
			if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn' ){
				include('api-import-form-hubtraffic.php');
			}
			
			if( $siteArray['site']=='xhamster' ){
				include('api-import-form-xhamster.php');
			}

			?>

			<div class="tubeace-set-alls-form">
				<h3>SET ALL Values</h3>

				<table class="form-table">
	    		<tbody>
	        	<tr>
	    				<th><label for="status">Status</label></th>
	        		<td>
				  			<select name="status" id="status">
				  				<?php echo $status; ?>
									<option value="publish">Publish</option>
									<option value="pending">Pending</option>
									<option value="draft">Draft</option>
									<option value="future">Future</option>
									<option value="private">Private</option>
				  			</select>
	        		</td>		        	
	        	</tr>
	        	<tr>
	        		<th><label for="sponsor">Author / Sponsor</label></th>
	        		<td>
						  	<select name="sponsor" id="sponsor">
									<?php tubeace_get_users_with_role(array('Contributor','Administrator'), $vars['sponsor']); ?>
						  	</select>
						  	<small>To add a sponsor, <a href="user-new.php">add a new user</a> with a "Contributor" Role.</small>
	        		</td>	
		    		</tr>		        
	        	<tr>
	    				<th><label for="post_date">Post Date</label></th>
	        		<td>
	        			<input name="post_date" type="text" class="tubeace-input-160" id="post_date" value="<?php echo $post_date ?>">
	        		</td>		        	
	        	</tr>		
	        	<tr>
	    				<th><label for="start">Category</label></th>
	        		<td>
								<ul id="categorychecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
							  	<?php wp_category_checklist( 0, 0, $selected_cats ); ?>
								</ul> 		        		
	        		</td>		        	
	        	</tr>
	        	<tr>
	    				<th><label for="description">Description</label></th>
	        		<td>
	        			<textarea name="description" class="tubeace-input-400" id="description"><?php echo $description; ?></textarea>
	        		</td>		        	
	        	</tr>
		        <tr>
		    			<th><label for="tags">Tags</label></th>
		        	<td>
		        		<input name="tags" type="text" class="tubeace-input-400" id="tags" value="<?php echo $tags ?>">
		        		<small>Separate multiple tags by comma.</small>
		        		<?php

	        			// if only tags
	        			if( $siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='youporn' ){

	        				?>
	        				<br>
			        		<select name="tags_method">
			        			<option value="merge_tags_y_setall">Merge Imported Tags with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        		</select>
			        		<?php		        				
	        			}

	        			// if only channels
	        			if($siteArray['site']=='xhamster'){

	        				//import channels as tags
	        				//import channels as tags and merge with setall
	        				//only use set all
	        				?>
	        				<br>
			        		<select name="tags_method">
			        			<option value="only_channels_as_tags">Import only Channels as Tags</option>
			        			<option value="merge_channels_as_tags_y_setall" selected="selected">Import Channels as Tags and Merge with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        			<option value="none">None</option>
			        		</select>
			        		<?php
	        			}	

	        			// if both tags and channels 
	        			if($siteArray['site']=='tube8' ){

	        				?>
	        				<br>
			        		<select name="tags_method">
			        			<option value="only_channels_as_tags">Import only Channels as Tags</option>
			        			<option value="only_tags">Import only Tags</option>
			        			<option value="merge_tags_y_setall">Merge Imported Tags with Set All</option>
			        			<option value="merge_channels_as_tags_y_tags_y_setall" selected="selected">Import Channels as Tags, Import Tags, and Merge with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        		</select>
			        		<?php
	        			}
		        		?>
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="performers">Performers</label></th>
		        	<td>
		        		<input name="performers" type="text" class="tubeace-input-400" id="performers" value="<?php echo $performers ?>">
		        		<small>Separate multiple performers by comma.</small>
						<?php

	        			// these have performer value possibility, show option
	        			if($siteArray['site']=='redtube' || $siteArray['site']=='pornhub' || $siteArray['site']=='youporn'){
	        				?>
	        				<br>
			        		<select name="performers_method">
			        			<option value="merge">Merge Imported Performers with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        		</select>	
			        		<?php	        				
	        			}
						?>		        		
		        	</td>		        	
		        </tr>
		        <tr>
			    	<th><label for="sponsor_link_txt">Sponsor Link Anchor Text</label></th>
		        	<td>
		        		<input name="sponsor_link_txt" type="text" class="tubeace-input-400" id="sponsor_link_txt" value="<?php echo $sponsor_link_txt ?>">
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="sponsor_link_url">Sponsor Link URL</label></th>
		        	<td>
		        		<input name="sponsor_link_url" type="text" class="tubeace-input-400" id="sponsor_link_url" value="<?php echo $sponsor_link_url ?>">
		        	</td>		        	
		        </tr>		
		        <tr>
		    		<th><label for="misc1">Misc 1</label></th>
		        	<td>
		        		<textarea name="misc1" class="tubeace-input-400" id="misc1"><?php echo $misc1; ?></textarea>
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="misc2">Misc 2</label></th>
		        	<td>
		        		<textarea name="misc2" class="tubeace-input-400" id="misc2"><?php echo $misc2; ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="misc3">Misc 3</label></th>
		        	<td>
		        		<textarea name="misc3" class="tubeace-input-400" id="misc3"><?php echo $misc3; ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="misc4">Misc 4</label></th>
		        	<td>
		        		<textarea name="misc4" class="tubeace-input-400" id="misc4"><?php echo $misc4; ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="misc5">Misc 5</label></th>
		        	<td>
		        		<textarea name="misc5" class="tubeace-input-400" id="misc5"><?php echo $misc5; ?></textarea>
		        	</td>
		        </tr>
	    		</tbody>
				</table>
			</div>
		       
			<table class="form-table">
		    <tbody>
		    	<tr>
		    		<th></th>
		        <td>
		        	<input type="hidden" name="page" value="tubeace/tubeace-<?php echo $siteArray['site'] ?>-api.php">
					<input type="submit" value="Import All" class="button-primary" name="all">
		        </td>		        	
		       </tr>
		    </tbody>
			</table>

			<h3>Create Auto-Import (Cron) Job</h3>
			<table class="form-table">
		    <tbody>		
		    	<tr>
		    		<th><label for="cron_name">Job Name</label></th>
	        	<td>
	        		<input name="cron_name" type="text" class="tubeace-input-400" id="cron_name">
	        	</td>
		      </tr>
		    	<tr>
		    		<th><label for="cron_frequency">Frequency</label></th>
	        	<td>
						  <select name="cron_frequency" id="cron_frequency">
						  	<?php echo $cron_frequency; ?>
								<option value="hourly">Hourly</option>
								<option value="twicedaily">Twice Daily</option>
								<option value="daily">Daily</option>
						  </select>
	        	</td>		        	
		      </tr>		        
		      <tr>
		    		<th></th>
		        <td>
							<input type="submit" value="Save as Cron" class="button-primary" name="cron">
		        </td>		        	
		      </tr>		        
		    </tbody>
		</table>
	</div>
	</form>
</div>
<?php
}
