<?php

// The JavaScript
function tubeace_redtube_api_import_javascript() {
  //Set Your Nonce
  $ajax_nonce = wp_create_nonce( 'my-special-string' );
  ?>
  <script>

  jQuery( document ).ready( function( $ ) {

  	var currPage = parseInt( jQuery('#start').val() );

  	process(currPage,0,0);

  	function process(currentPage,perPage,videoCount,videoData){

	    var data = {
	      action: 'tubeace_redtube_api_import',
	      security: '<?php echo $ajax_nonce; ?>',

	      site: jQuery('#site').val(),

	      start: jQuery('#start').val(),
	      end: jQuery('#end').val(),
	      
	      ordering: jQuery('#ordering').val(),

	      keyword: jQuery('#keyword').val(),
	      tag: jQuery('#tag').val(),

	      //xhamster
	      cats: jQuery('#cats').val(),
	      cnt: jQuery('#cnt').val(),
	      resolution: jQuery('#resolution').val(),
	      period: jQuery('#period').val(),
	      orderby: jQuery('#orderby').val(),
	      rating_min: jQuery('#rating_min').val(),
	      views_min: jQuery('#views_min').val(),

	      ratings_num_min: jQuery('#ratings_num_min').val(),

	      status: jQuery('#status').val(),
	      sponsor: jQuery('#sponsor').val(),
	      post_date: jQuery('#post_date').val(),
	      post_category: jQuery('#post_category').val(),

	      description: jQuery('#description').val(),
	      tags_set_all: jQuery('#tags_set_all').val(),
	      tags_method: jQuery('#tags_method').val(),
	      performers_set_all: jQuery('#performers_set_all').val(),
	      performers_method: jQuery('#performers_method').val(),
	      sponsor_link_txt: jQuery('#sponsor_link_txt').val(),
	      sponsor_link_url: jQuery('#sponsor_link_url').val(),
	      misc1: jQuery('#misc1').val(),
	      misc2: jQuery('#misc2').val(),
	      misc3: jQuery('#misc3').val(),
	      misc4: jQuery('#misc4').val(),
	      misc5: jQuery('#misc5').val(),

	      page: currentPage,
	      per_page: perPage,
	      video_count: videoCount,
	      video_data: videoData
	    };

	    $.post( ajaxurl, data, function( response)  {

			if(response.no_results==1){
				jQuery('#tubeace-loading').remove();
				jQuery('#response').append(response.report);
				jQuery('#response').append('<span class="tubeace-errormsg">No results returned from API. This may be becuase your search returned no results or the API is down. Please try a different search query or try again later. </span><br>');
				return;
			} else if(response.done==1){
				jQuery('#tubeace-loading').remove();
				jQuery('#response').append('Importing Complete.<br><br>');
				return;
				
			} else {

				//show added/skipped or starting new page
				if(response.video_count>0){
					jQuery('#response').append(response.report);
				} else {
					var lastPg = response.video_page - 1;
					jQuery('#response').append('Finished importing page ' + lastPg +'<br><br>');
				}

				//increment
				currentPage = response.video_page++;
				videoCount = response.video_count++;

				// get value to return back
				perPage = response.per_page;

				process(currentPage, perPage, videoCount, response.video_data);
			}
	    });
	}
  });

  </script>
  <?php
}
add_action( 'admin_footer', 'tubeace_redtube_api_import_javascript' );	

$cats = json_encode($cats);
$post_category = json_encode($post_category);

echo'
  <input type="hidden" id="site" value="'.$siteArray['site'].'">

  <input type="hidden" id="start" value="'.$start.'">
  <input type="hidden" id="end" value="'.$end.'">

  <input type="hidden" id="ordering" value="'.$ordering.'">

  <input type="hidden" id="keyword" value="'.$keyword.'">
  <input type="hidden" id="tag" value="'.$tag.'">

  <input type="hidden" id="cats" value=\''.$cats.'\'>
  <input type="hidden" id="cnt" value="'.$cnt.'">
  <input type="hidden" id="resolution" value="'.$resolution.'">
  <input type="hidden" id="period" value="'.$period.'">
  <input type="hidden" id="orderby" value="'.$orderby.'">
  <input type="hidden" id="rating_min" value="'.$rating_min.'">
  <input type="hidden" id="views_min" value="'.$views_min.'">
  
  <input type="hidden" id="ratings_num_min" value="'.$ratings_num_min.'">

  <input type="hidden" id="status" value="'.$status.'">
  <input type="hidden" id="sponsor" value="'.$sponsor.'">
  <input type="hidden" id="post_date" value="'.$post_date.'">
  <input type="hidden" id="post_category" value=\''.$post_category.'\'>

  <input type="hidden" id="description" value="'.$description.'">
  <input type="hidden" id="tags_set_all" value="'.$tags_set_all.'">
  <input type="hidden" id="tags_method" value="'.$tags_method.'">
  <input type="hidden" id="performers_set_all" value="'.$performers_set_all.'">
  <input type="hidden" id="performers_method" value="'.$performers_method.'">
  <input type="hidden" id="sponsor_link_txt" value="'.$sponsor_link_txt.'">
  <input type="hidden" id="sponsor_link_url" value="'.$sponsor_link_url.'">
  <input type="hidden" id="misc1" value="'.$misc1.'">
  <input type="hidden" id="misc2" value="'.$misc2.'">
  <input type="hidden" id="misc3" value="'.$misc3.'">
  <input type="hidden" id="misc4" value="'.$misc4.'">
  <input type="hidden" id="misc5" value="'.$misc5.'">

  <div id="response"></div>
  <img id="tubeace-loading" src="'.plugins_url("tubeace/images/loading.gif").'">';

  ?>