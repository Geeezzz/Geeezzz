<?php
// called from api-import-ajax-callback.php

// get title, video id, duration, tags, performers, featured image

    if($siteArray['site']=='pornhub'){

        $videos = $video_data->videos;
        $video = $videos[$video_count];

        $title = $video->title;
        $video_id = $video->video_id;
        $url = $video->url;

        $str_time = $video->duration;
        $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $str_time);
        sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
        $duration = $hours * 3600 + $minutes * 60 + $seconds;                       
        $rating = $video->rating;
        $ratings = $video->ratings;

        if(!empty($video->tags)){

            $tags = "";
            foreach($video->tags as $tag){
                
                $tags.= $tag->tag_name.", ";
            }
            
            $tags = addslashes(rtrim($tags,", "));
        }

        if(!empty($video->pornstars)){

            $performersArr = array();
            foreach($video->pornstars as $pornstar){
                
                $performersArr[] = $pornstar->pornstar_name;
            }
        }

        # get thumbs to test before adding into db
        // If display default thumb only, get URL from object. All thumbs array not needed
        if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
            
            // it appears pornhub 'default_thumb' is always 12.jpg, 'thumb' varies but can have a filename of 0 and doesn't exist in thumbs array, so we'll use 'default_thumb'
            $featured_img = $video->default_thumb;

        } elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

            $featured_img = $video->default_thumb;

            $allThumbsArr = $video->thumbs;
            $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

            if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

                // use last thumb as default
                $featured_img = $thumbsArr[(count($thumbsArr)-1)]->src; 

                $report.='Default thumbnail was purged, using last thumbnail instead.<br>';
            }

        } else {

            // # of Thumbnails to Display and Default Thumbnail # to Display in Previews
            $featured_img = $video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

            $allThumbsArr = $video->thumbs;
            $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');                                
        }
    }

    if($siteArray['site']=='redtube'){

        $videos = $video_data->videos;
        $video = $videos[$video_count]->video;

        $title = addslashes($video->title);
        $video_id = $video->video_id;
        $url = $video->url;

        //convert duration to seconds
        $str_time = $video->duration;
        $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $str_time);
        sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
        $duration = $hours * 3600 + $minutes * 60 + $seconds;        
        $rating = $video->rating;
        $ratings = $video->ratings;

        // tags
        if(!empty($video->tags)){

            $tags = '';
            foreach($video->tags as $tag){
                
                $tags.= $tag->tag_name.", ";
            }
            
            $tags = addslashes(rtrim($tags,", "));
        }

        // performers
        if(!empty($video->stars)){

            $performersArr = array();
            foreach($video->stars as $star){
                
                $performersArr[] = $star->star_name;
            }
        }

        # get thumbs to test before adding into db
        // If display default thumb only, get URL from object. All thumbs array not needed
        if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
            
            $featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $video->default_thumb, $video->thumbs);

        } elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

            $featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $video->default_thumb, $video->thumbs);

            $allThumbsArr = $video->thumbs;
            $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

            if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

                // use last thumb as default
                $featured_img = $thumbsArr[(count($thumbsArr)-1)]->src; 

                $report.='Default thumbnail was purged, using last thumbnail instead.<br>';
            }

        } else {

            // # of Thumbnails to Display and Default Thumbnail # to Display in Previews
            $featured_img = $video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

            $allThumbsArr = $video->thumbs;
            $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');                                    
        }

    }

    if($siteArray['site']=='tube8'){

        $videos = $video_data->videos;

        if( $per_page==0 ){
            $no_results = 1;
        }

        $video = $videos[$video_count];

        $title = addslashes($video->title);
        $video_id = $video->video->video_id;
        $url = $video->video->url;

        $duration = $video->video->duration;

        $rating = $video->video->rating;
        $rating = ceil($rating * 100);

        $ratings = $video->video->ratings;    

        if(!empty($video->tags)){

            $tags = "";
            foreach($video->tags as $tag){
                
                $tags.= $tag.", ";
            }
            
            $tags = addslashes(rtrim($tags,", "));
        }

        $tube8_thumb_size = get_site_option( 'tubeace_tube8_api_thumb_size' );

        # get thumbs to test before adding into db
        // If display default thumb only, get URL from object. All thumbs array not needed
        if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
            
            // Tube8 returns default thumb size as specified in thumbsize parameter in API call
            $featured_img = $video->video->default_thumb;
            
        } elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

            $featured_img = $video->video->default_thumb;

            if($tube8_thumb_size=='small'){
                $allThumbsArr = $video->thumbs->small;
            }
            if($tube8_thumb_size=='big'){
                $allThumbsArr = $video->thumbs->big;
            }                   

            $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

            if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

                // use last thumb as default
                if($tube8_thumb_size=='small'){
                    $featured_img = $video->thumbs->small[(count($thumbsArr)-1)];
                }
                if($tube8_thumb_size=='big'){
                    $featured_img = $video->thumbs->big[(count($thumbsArr)-1)];
                }

                $report.= 'Default thumbnail was purged, using last thumbnail instead.<br>';
            }

        } else {

            // # of Thumbnails to Display and Default Thumbnail # to Display in Previews

            if($tube8_thumb_size=='small'){
                $featured_img = $video->thumbs->small[(get_site_option( 'tubeace_tube8_api_def_thumb' )-1)];
            }
            if($tube8_thumb_size=='big'){
                $featured_img = $video->thumbs->big[(get_site_option( 'tubeace_tube8_api_def_thumb' )-1)];
            }

            if($tube8_thumb_size=='small'){
                $allThumbsArr = $video->thumbs->small;
            }
            if($tube8_thumb_size=='big'){
                $allThumbsArr = $video->thumbs->big;
            }

            $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');
        }
    }
    
    if($siteArray['site']=='youporn'){

        $videos = $video_data->video;
        $video = $videos[$video_count];

        $title = addslashes($video->title);
        $video_id = $video->video_id;
        $url = $video->url;

        $str_time = $video->duration;
        $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $str_time);
        sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
        $duration = $hours * 3600 + $minutes * 60 + $seconds;   

        $rating = $video->rating;
        $rating = ceil($rating * 20);

        $ratings = $video->ratings;

        if(!empty($video->tags)){

            $tags = "";
            foreach($video->tags as $tag){
                
                $tags.= $tag->tag_name.", ";
            }
            
            $tags = addslashes(rtrim($tags,", "));
        }

        if(!empty($video->pornstars)){

            $performersArr = array();
            foreach($video->pornstars as $pornstar){
                
                $performersArr[] = $pornstar->pornstar_name;
            }
        }

        $allThumbsArr = $video->thumbs;
        $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');
        $featured_img = $video->thumbs[(get_site_option( 'tubeace_youporn_api_def_thumb' )-1)]->src;

        // make sure $featured_img exists (could not happen if tubeace_youporn_api_def_thumb is greater than number of thumbs available)
        if( count($thumbsArr) < get_site_option( 'tubeace_youporn_api_def_thumb' )){

            // use last thumb as default
            $featured_img = $video->thumbs[(count($thumbsArr)-1)]->src;
        }
    }

    // add https:// if not already there
    if (false === strpos($featured_img, '://')) {
        $featured_img = "https:" . $featured_img;
    }


?>