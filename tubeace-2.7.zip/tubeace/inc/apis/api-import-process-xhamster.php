<?php

// #ID|#THUMB|#URL|#TITLE|#CHANNEL|#DURATION|

$line=0;
//foreach line

foreach($lines as $lines_key => $lines_val){

	if( tubeace_license_status() !== true){
		if( $line >= 10 ){
			echo'Demo limit reached. ';	
		 	break;
		}			
	}

    //reset
    $errorInsert = $duration = $thumbs = '';	

    //foreach fields
    foreach(explode('|', $lines_val) as $fields_key => $fields_val) {

        $fields_val_con = trim($fields_val);

        if($fields_key==0){
            $video_id = $fields_val_con;
        }

        if($fields_key==1){
            $thumbs = $fields_val_con;
        }

        if($fields_key==2){
            $url = $fields_val_con;
        }        

        if($fields_key==3){
            $title = $fields_val_con;
        }

        if($fields_key==4){
        	$categories = $fields_val_con;
        } 

        if($fields_key==5){
            $duration = $fields_val_con;

			// duration matches 1h2m3s format
			preg_match('/((\d+)h)?(\d+)m(\d+)s/', $duration, $matches);

			if( !empty($matches)){
			    
			    $h = $matches[2];   
			    $m = $matches[3];   
			    $s = $matches[4];

			    if($h>0){
			        $hou = $h * 60 * 60;
			    } else {
			        $hou = 0;
			    }

			    if($m>0){
			        $sec = $m * 60;
			    } else {
			        $sec = 0;
			    }

			    $duration = $hou + $sec + $s;
			}
        }
    }

    $display_video_count = $line + 1;

    //check for duplicate
	$args = array(
		'meta_query' => array(
		 'relation' => 'AND',
			array(
				'key' => 'video_id',
				'value' => $video_id,
			),
			array(
				'key' => 'site',
				'value' => $siteArray['domain']
			)
		)
	);
 
	$query = new WP_Query( $args );

	$num_rows = $query->found_posts;


    if ($num_rows > 0){

		echo'<span class="tubeace-warnmsg">Video skipped! Video titled <b>\''.$title.'\'</b> of video #'.$display_video_count.' already exists in database.</span><br>';
		ob_flush();
		flush();
    } elseif(!is_numeric($duration)) { //check for corrupt lines

		echo'<span class="tubeace-errormsg">Video skipped! Video titled <b>\''.$title.'\'</b> of video #'.$display_video_count.' duration not an integer: '.$duration.'.</span><br>';
		ob_flush();
		flush(); 
    } elseif(empty($thumbs)) {

		echo'<span class="tubeace-errormsg">Video skipped! Video titled <b>\''.$title.'\'</b> of video #'.$display_video_count.' Thumbs field empty.</span><br>';
		ob_flush();
		flush();
    } else {   

        $allThumbsArr = explode(';', $thumbs);

		# get thumbs to test before adding into db
		// If display default thumb only, get URL from object. All thumbs array not needed
		if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
			
			// xhamster returns semicolon-separated string of thumbnails with default thumb first
			// get first result in array
			$featured_img = $allThumbsArr[0];

			$thumbsArr = array();

			// set array to first (default) thumb
			$thumbsArr[0] = $featured_img;

		} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

			$featured_img = $allThumbsArr[0];

			// sort
			$allThumbsArr = tubeace_sort_xhamster_thumbs($thumbs);

			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

		} else {

			// sort
			$allThumbsArr = tubeace_sort_xhamster_thumbs($thumbs);

			// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

			// get featured_img after sorting
			$featured_img = $allThumbsArr[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)];				
		}

		// check word filter
		$tubeace_words_filter = get_site_option( 'tubeace_words_filter' );

		$wordsFilterArray = explode(',', $tubeace_words_filter);

		foreach($wordsFilterArray as $val){

			// title
			if (stripos($title, $val) !== false && !$errorInsert) {
				echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in title.</span><br>';
				$outputAll.= $output;
				$errorInsert=1;
				ob_flush();
				flush();	
			}

			// tags
			if( isset($tags) ){
				if (stripos($tags, $val) !== false && !$errorInsert) {
					echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in tags.</span><br>';
					$outputAll.= $output;
					$errorInsert=1;
					ob_flush();
					flush();	
				}
			}
				

			// categories
			if (stripos($categories, $val) !== false && !$errorInsert) {
				echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in categories.</span><br>';
				$outputAll.= $output;
				$errorInsert=1;
				ob_flush();
				flush();	
			}	
		}

        //check thumbs valid
        foreach($thumbsArr as $val){

          if(!@getimagesize($val) && !@$errorInsert){
      	
            echo'<span class="tubeace-errormsg">Video \''.$title.'\' skipped - Thumbnail URL of video #'.$display_video_count.' invalid!</span><br>';
			ob_flush();
			flush();
            $errorInsert=1;
          }
        } 

        if(@!$errorInsert){

        	// Tags
			// Merge Imported Tags with Set All
			if( $tags_method=='merge_tags_y_setall' ){
				$tags = $tags.','.$tags_set_all;
			}

			// Import only Channels as Tags
			if( $tags_method=='only_channels_as_tags' ){
				$tags = $categories;
			}

			// Import Channels as Tags and Merge with Set All
			if( $tags_method=='merge_channels_as_tags_y_setall' ){
				$tags = $categories.','.$tags_set_all;
			}

			// Import only Tags
			if( $tags_method=='only_tags' ){
				$tags = $tags;
			}

			// Merge Imported Tags with Set All
			if( $tags_method=='merge_tags_y_setall' ){
				$tags = $tags.','.$tags_set_all;
			}

			// Import Channels as Tags, Import Tags, and Merge with Set All
			if( $tags_method=='merge_channels_as_tags_y_tags_y_setall' ){
				$tags = $categories.','.$tags.','.$tags_set_all;
			}

			// Set All
			if( $tags_method=='setall' ){
				$tags = $tags_set_all;
			}
			
			// replace ;
			$tags = str_replace(';', ',', $tags);

			// strtolower for consistency
			$tags = strtolower($tags);

			// Performers
			$performers = $performers_set_all;

			// explode into array
			$performersArr = explode(',', $performers);					
			
			//make pending until thumb generated
			if($status=='publish'){
				$status_alt = 'draft';
			} 

			//insert
			$my_post = array(
			  'post_title'    => $title,
			  'post_content'  => $description,
			  'post_status'   => $status_alt,
			  'post_author'   => $sponsor,
			  'post_category' => $post_category,
			  'tags_input' => $tags
			);

			// Insert the post into the database
			if($lastID = wp_insert_post( $my_post )){

				//custom taxonomy must be done using wp_set_object_terms() for cron
				wp_set_object_terms($lastID, $performersArr, 'performer');							

				//add meta value
				add_post_meta($lastID, 'video_id', $video_id);
				add_post_meta($lastID, 'url', $url);
				add_post_meta($lastID, 'duration', $duration);
				add_post_meta($lastID, 'site', $siteArray['domain']);

				if( !empty($sponsor_link_url) ){
					add_post_meta($lastID, 'sponsor_link_url', $sponsor_link_url);
				}
				
				if( !empty($sponsor_link_txt) ){
					add_post_meta($lastID, 'sponsor_link_txt', $sponsor_link_txt);
				}

				if( !empty($misc1) ){
					add_post_meta($lastID, 'misc1', $misc1);
				}

				if( !empty($misc2) ){
					add_post_meta($lastID, 'misc2', $misc2);
				}

				if( !empty($misc3) ){
					add_post_meta($lastID, 'misc3', $misc3);
				}

				if( !empty($misc4) ){
					add_post_meta($lastID, 'misc4', $misc4);
				}

				if( !empty($misc5) ){
					add_post_meta($lastID, 'misc5', $misc5);
				}
				
				if(isset($tubeace_is_running_cron)==1){
					add_post_meta($lastID, 'cron_id', $cron_id);
				}

				echo'<span class="tubeace-succmsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' added</span><br>';

			} else {
				echo'<span class="tubeace-errormsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' not added.</span><br>';
			}
			
			ob_flush();
			flush();

            // video post format
            if( get_site_option( 'tubeace_import_as_video_post_format' ) == 1 ){

	            $format = 'video';
	            set_post_format( $lastID , $format);
            }

            // save thumbs to server or store source URLs
            if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_save_thumbs' ) == 1 ){ // save thumbs to server


            	// if not default thumb only, do multiple thumbs
            	if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) != 1 ){

            		// detect default thumb #
            		$def_thmb = tubeace_detect_def_thmb($siteArray['site'], $featured_img, $thumbsArr, 'api');

					// multiple thumbs
					tubeace_create_thumbs($siteArray['site'], $lastID, $thumbsArr, 'api', $def_thmb);		            		
            	}

	            // create featured image
	            tubeace_create_featured_image($lastID, $featured_img);


            } else { // don't save thumbs, serve from cdn

            	$thumbs_src = '';

            	if( count($thumbsArr) > 1 ){

	            	// create string of semicolon separated thumbs
	            	$thumbs_src = implode(";", $thumbsArr);
            	}

            	// use https
            	$thumbs_src = str_replace("http://", "https://", $thumbs_src);
            	$featured_img = str_replace("http://", "https://", $featured_img);

            	if( !empty($thumbs_src) ){
            		add_post_meta($lastID, 'thumbs_src', $thumbs_src);
            	}
            	
            	add_post_meta($lastID, 'def_thumb_url', $featured_img);
            	add_post_meta($lastID, '_thumbnail_id', '6969TA' ); // needed for post_thumbnail_html hook to load
            }

			//thumbs generated, now set to publish
			if($status=="publish"){

				$my_post = array(
				  'ID'           => $lastID,
				  'post_status' => 'publish'
				);
				wp_update_post( $my_post );

			} 	 

			//auto-scheduling
			if(get_site_option('tubeace_schedule_per_day')>0){
				
				$schedDate = tubeace_auto_sched_next_date(0);

				$wpdb->update( $wpdb->prefix . 'posts', array('post_date' => "$schedDate 00:00:00", 'post_date_gmt' => "$schedDate 00:00:00"), array('id' => $lastID));
									
				echo $output ='<span class="tubeace-succmsg">Video #'.$lastID.' Auto-Scheduled to '.$schedDate.'</span><br>';
				ob_flush();
				flush();							
			}
        }
    }

    $line++;
}

echo"All Done.";  

?>