<table class="form-table">
  <tbody>
    <tr>
    	<th><label for="keyword">Keyword</label></th>
      <td>
      	<input name="keyword" type="text" class="tubeace-input-320" id="keyword" value="<?php echo $keyword ?>">
      </td>		        	
    </tr>

    <?php if( $siteArray['site']!='tube8' ) : ?>
	    <tr>
	      <th><label for="tag">Tag</label></th>
	      <td>
	      	<input name="tag" type="text" class="tubeace-input-320" id="tag" value="<?php echo $tag ?>">
	      </td>		        	
	    </tr>
    <?php endif ?>

    <tr>
    	<th><label for="start">Start Page</label></th>
      <td>
      	<input name="start" type="text" class="tubeace-input-60" id="start" value="<?php echo $start ?>">
      </td>		        	
    </tr>
    <tr>
    	<th><label for="end">End Page</label></th>
      <td>
        <input name="end" type="text" class="tubeace-input-60" id="end" value="<?php echo $end ?>">
        <small>Note: There are <?php echo $siteArray['videos_per_pg']; ?> videos per import page, 20 pages = <?php echo $siteArray['videos_per_pg']*20; ?> videos</small>
      </td>		        	
    </tr>

    <tr>
      <th><label for="rating_min">Minimum Rating</label></th>
      <td>
        <input name="rating_min" type="text" class="tubeace-input-40" id="rating_min" value="<?php echo $rating_min ?>">
          <small>1-100</small>
      </td>             
    </tr>
    
    <tr>
      <th><label for="ratings_num_min">Minimum # of Ratings</label></th>
      <td>
        <input name="ratings_num_min" type="text" class="tubeace-input-60" id="ratings_num_min" value="<?php echo $ratings_num_min ?>">
      </td>             
    </tr>

<?php 
if( $siteArray['site']=='pornhub' ){ ?>
    <tr>
      <th><label for="ordering">Ordering</label></th>
      <td>
        <select name="ordering" id="ordering">
          <option value="featured">Featured</option>
          <option value="newest">Newest</option>
          <option value="mostviewed">Most Viewed</option>
          <option value="rating" selected="selected">Rating</option>
        </select>        
      </td>             
    </tr>
  <?php } ?>

<?php 
if( $siteArray['site']=='redtube' ){ ?>
    <tr>
      <th><label for="ordering">Ordering</label></th>
      <td>
        <select name="ordering" id="ordering">
          <option value="newest">Newest</option>
          <option value="mostviewed">Most Viewed</option>
          <option value="rating" selected="selected">Rating</option>
        </select>        
      </td>             
    </tr>
  <?php } ?>  

<?php 
if( $siteArray['site']=='tube8' ){ ?>
    <tr>
      <th><label for="ordering">Ordering</label></th>
      <td>
        <select name="ordering" id="ordering">
          <option value="featured">Featured</option>
          <option value="newest">Newest</option>
          <option value="views">Most Viewed</option>
          <option value="rating" selected="selected">Rating</option>
          <option value="favorites">Favorites</option>
          <option value="comments">Comments</option>
          <option value="votes">Votes</option>
          <option value="longest">Longest</option>
        </select>        
      </td>             
    </tr>
  <?php } ?>

<?php 
if( $siteArray['site']=='youporn' ){ ?>
    <tr>
      <th><label for="ordering">Ordering</label></th>
      <td>
        <select name="ordering" id="ordering">
          <option value="newest">Newest</option>
          <option value="mostviewed">Most Viewed</option>
          <option value="rating" selected="selected">Rating</option>
        </select>        
      </td>             
    </tr>
  <?php } ?>  

  </tbody>
</table>
