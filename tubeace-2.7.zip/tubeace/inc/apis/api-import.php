<?php 

//import all
if(isset($_GET['all'])){

	//hubtraffic
	if( $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn' ){

		$keyword = null;
		$tag = null;

		if( isset( $_GET['keyword'] ) ){
			$keyword = urlencode($_GET['keyword']); //urlencode in case spaces in value
		}

		if( isset( $_GET['tag'] ) ){
			$tag = urlencode($_GET['tag']);
		}		

		$start = $_GET['start'];
		$end = $_GET['end'];

		$ratings_num_min = $_GET['ratings_num_min'];

		if( isset( $_GET['ordering'] ) ){
			$ordering = urlencode($_GET['ordering']);
		}			

		if( tubeace_license_status() !== true){
			$start = 1;
			$end = 1;
		}
	}


	//xhamster
	if( $siteArray['site']=='xhamster' ){

		$keyword = null;
		$start = 1;
		$end = 1;

		$cats = $_GET['cats'];
		$cnt = $_GET['cnt'];
		$resolution = $_GET['resolution'];
		$period = $_GET['period'];
		$orderby = $_GET['orderby'];
		$views_min = $_GET['views_min'];
	}


	$performers_method = null;

	$rating_min = $_GET['rating_min'];

	// set alls
	$status = $_GET['status'];
	$sponsor = $_GET['sponsor'];
	$post_date = $_GET['post_date'];

	//create vars
	$post_category = null;

	if( isset($_GET['post_category']) ){
		$post_category = $_GET['post_category'];
	}	
	
	$description = $_GET['description'];
	$tags_set_all = $_GET['tags'];
	$tags_method = $_GET['tags_method'];
	$performers_set_all = $_GET['performers'];
	//$performers_method = $_GET['performers_method']; // not created for tube8

	if( isset( $_GET['performers_method'] ) ){
		$performers_method = $_GET['performers_method'];
	}

	$sponsor_link_txt = $_GET['sponsor_link_txt'];
	$sponsor_link_url = $_GET['sponsor_link_url'];
	$misc1 = $_GET['misc1'];
	$misc2 = $_GET['misc2'];
	$misc3 = $_GET['misc3'];
	$misc4 = $_GET['misc4'];
	$misc5 = $_GET['misc5'];

	echo'
	<div class="wrap">
	  <h2>'.$siteArray['site_name'].' API Import</h2>
	  	<table class="tubeace-api-params">
	  		<tr>';

	  		// display parameters
		  	if(!empty($keyword)){
		  		echo '<td><b>Keyword:</b> '.urldecode($keyword).'</td>';
		  	}	 

		  	if(!empty($tag)){
		  		echo '<td><b>Tag:</b> '.urldecode($tag).'</td>';
		  	}

		  	if(!empty($start)){
				echo '<td><b>Start Page:</b> '.$start.'</td>';
			}

			if(!empty($end)){
				echo '<td><b>End Page:</b> '.$end.'</td>';
			}

			if(!empty($cats)){

				$categoriesArr = tubeace_api_export_categories_array('xhamster'); //only relevant at the time

				$channelsStr = '';
				$N = count($cats);
				for($i=0; $i < $N; $i++){
				 	$channelsStr.= $categoriesArr[$cats[$i]].', ';
				} 

				$channelsStr = rtrim($channelsStr, ', ');

				echo '<td><b>Categories:</b> '. $channelsStr.'</td>';
			}

			if(isset($cnt)){

      			if($cnt==0){
      				$num_to_import = 100;
      			}
      			if($cnt==1){
      				$num_to_import = 500;
      			}				
      			if($cnt==2){
      				$num_to_import = 1000;
      			}		
      			if($cnt==3){
      				$num_to_import = 5000;
      			}		
      			if($cnt==4){
      				$num_to_import = 10000;
      			}		
      			if($cnt==5){
      				$num_to_import = 50000;
      			}		

				echo '<td><b># of Videos to Import:</b> '.$num_to_import.'</td>';
			}


			if(isset($resolution)){

      			if($resolution==0){
      				$display_resolution = 'All';
      			}
      			if($resolution==1){
      				$display_resolution = 'HD';
      			}				
	
				echo '<td><b>Video Resolution:</b> '.$display_resolution.'</td>';
			}


			if(isset($period)){

      			if($period==0){
      				$display_period = 'All';
      			}
      			if($period==1){
      				$display_period = 'Last day (1 Day)';
      			}				
      			if($period==2){
      				$display_period = 'Last week (7 Days)';
      			}		
      			if($period==3){
      				$display_period = 'Last month (30 Days)';
      			}

				echo '<td><b>Period:</b> '.$display_period.'</td>';
			}

			// hubtraffic
			if(isset($ordering)){

      			if($ordering=='featured'){
      				$display_ordering = 'Featured';
      			}
      			if($ordering=='newest'){
      				$display_ordering = 'Newest';
      			}				
      			if($ordering=='mostviewed'){
      				$display_ordering = 'Most Viewed';
				}
      			if($ordering=='rating'){
      				$display_ordering = 'Rating';
				}
				echo '<td><b>Ordering:</b> '.$display_ordering.'</td>';
			}

			//xham
			if(isset($orderby)){

      			if($orderby==0){
      				$display_orderby = 'Added Time';
      			}
      			if($orderby==1){
      				$display_orderby = 'Rating';
      			}				
      			if($orderby==2){
      				$display_orderby = 'View Count';
				}

				echo '<td><b>Order By:</b> '.$display_orderby.'</td>';
			}

			if(isset($rating_min)){

				if( $siteArray['site']=='xhamster' ){

	      			if($rating_min==0){
	      				$display_rating_min = '0%';
	      			}
	      			if($rating_min==1){
	      				$display_rating_min = '40%';
	      			}				
	      			if($rating_min==2){
	      				$display_rating_min = '60%';
					}
	      			if($rating_min==3){
	      				$display_rating_min = '80%';
					}

				} else {

					$display_rating_min = $rating_min;
				}

				echo '<td><b>Minimum Rating:</b> '.$display_rating_min.'</td>';
			}

			if(isset($ratings_num_min)){

				$display_ratings_num_min = $ratings_num_min;
				
				echo '<td><b>Minimum # of Ratings:</b> '.$display_ratings_num_min.'</td>';
			}

			if(isset($views_min)){

      			if($views_min==0){
      				$display_views_min = 'Any';
      			}
      			if($rating_min==1){
      				$display_views_min = '1000';
      			}				
      			if($rating_min==2){
      				$display_views_min = '5000';
				}
      			if($rating_min==3){
      				$display_views_min = '10000';
				}

				echo '<td><b>Minimum Views:</b> '.$display_views_min.'</td>';
			}

			echo'
			<tr>
		</table>';

		if( get_site_option( 'tubeace_ajax_import' ) == 1 ) {
			require_once 'api-import-ajax.php';
		} else {
			require_once 'api-import-process.php';
		}

	echo'
	</div>';	  
}