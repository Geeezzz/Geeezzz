<?php
// included from api-import-ajax-callback.php

// get title, video id, duration, tags, performers, featured image

// using $video_count get result from $video_data

$lines = explode("\n", $video_data);

// remove first line (field order)
array_shift($lines);

//get specific line
$line = $lines[$video_count];

foreach(explode('|', $line) as $fields_key => $fields_val) {

    $fields_val_con = trim($fields_val);

    if($fields_key==0){
        $video_id = $fields_val_con;
    }

    if($fields_key==1){
        $thumbs = $fields_val_con;
    }

    if($fields_key==3){
        $title = $fields_val_con;
    }

    if($fields_key==4){
        $categories = $fields_val_con;
    } 

    if($fields_key==5){
        $duration = $fields_val_con;

        // duration matches 1h2m3s format
        preg_match('/((\d+)h)?(\d+)m(\d+)s/', $duration, $matches);

        if( !empty($matches)){
            
            $h = $matches[2];   
            $m = $matches[3];   
            $s = $matches[4];

            if($h>0){
                $hou = $h * 60 * 60;
            } else {
                $hou = 0;
            }

            if($m>0){
                $sec = $m * 60;
            } else {
                $sec = 0;
            }

            $duration = $hou + $sec + $s;
        }
    }
}

$allThumbsArr = explode(';', $thumbs);
$thumbsArr = tubeace_purge_thumbs('xhamster', $allThumbsArr, 'api');
$featured_img = $thumbsArr[(get_site_option( 'tubeace_xhamster_api_def_thumb' )-1)];

// make sure $featured_img exists (could not happen if tubeace_redtube_api_def_thumb is greater than number of thumbs available)
if( count($thumbsArr) < get_site_option( 'tubeace_xhamster_api_def_thumb' )){

    // use last thumb as default
    $featured_img = $thumbsArr[(count($thumbsArr)-1)];
}

?>