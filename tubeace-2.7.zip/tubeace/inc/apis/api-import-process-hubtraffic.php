<?php

 	//result #
 	$r=0;
 	$categories = null;//only tube8 has value?
	
	if ( is_array($videos) ){

		foreach($videos as $video) {

			//reset
			$errorInsert = $duration = $hours = $minutes = $seconds = $tags = $performersArr = '';

			if($siteArray['site']=='pornhub'){

				$title = addslashes($video->title);
				$video_id = $video->video_id;
				$url = $video->url;

				$str_time = $video->duration;
				$str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $str_time);
				sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
				$duration = $hours * 3600 + $minutes * 60 + $seconds;
				$rating = $video->rating;
				$ratings = $video->ratings;
		
				if(!empty($video->tags)){

					$tags = "";
					foreach($video->tags as $tag){
						
						$tags.= $tag->tag_name.", ";
					}
					
					$tags = addslashes(rtrim($tags,", "));
				}

				if(!empty($video->pornstars)){

					$performersArr = array();
					foreach($video->pornstars as $pornstar){
						
						$performersArr[] = $pornstar->pornstar_name;
					}
				}

				# get thumbs to test before adding into db
				// If display default thumb only, get URL from object. All thumbs array not needed
				if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
					
					// it appears pornhub 'default_thumb' is always 12.jpg, 'thumb' varies but can have a filename of 0 and doesn't exist in thumbs array, so we'll use 'default_thumb'
					$featured_img = $video->default_thumb;

				} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

					$featured_img = $video->default_thumb;

					$allThumbsArr = $video->thumbs;
					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

					if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

						// use last thumb as default
						$featured_img = $thumbsArr[(count($thumbsArr)-1)]->src;	

						echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
					}

				} else {

					// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
					$featured_img = $video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

					$allThumbsArr = $video->thumbs;
					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');								
				}
			}

		    if($siteArray['site']=='redtube'){

		    	$video = $video->video;
		        $title = addslashes($video->title);
		        $video_id = $video->video_id;
		        $url = $video->url;

		        //convert duration to seconds
		        $str_time = $video->duration;
		        $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $str_time);
		        sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
		        $duration = $hours * 3600 + $minutes * 60 + $seconds;
		        $rating = $video->rating;
		        $ratings = $video->ratings;

		        // tags
		        if(!empty($video->tags)){

		            $tags = '';
		            foreach($video->tags as $tagObj){
		                
		                $tags.= $tagObj->tag_name.", ";
		            }
		            
		            $tags = addslashes(rtrim($tags,", "));
		        }

		        // performers
		        if(!empty($video->stars)){

		            $performersArr = array();
		            foreach($video->stars as $star){
		                
		                $performersArr[] = $star->star_name;
		            }
		        }

				# get thumbs to test before adding into db
				// If display default thumb only, get URL from object. All thumbs array not needed
				if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
					
					$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $video->default_thumb, $video->thumbs);

				} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

					$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $video->default_thumb, $video->thumbs);

					$allThumbsArr = $video->thumbs;
					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

					if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

						// use last thumb as default
						$featured_img = $thumbsArr[(count($thumbsArr)-1)]->src;	

						echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
					}

				} else {

					// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
					$featured_img = $video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

					$allThumbsArr = $video->thumbs;
					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');									
				}

		    }

			if($siteArray['site']=='tube8'){

				$title = addslashes($video->title);
				$video_id = $video->video->video_id;
				$url = $video->video->url;

				//reset
				$tags="";

				$duration = $video->video->duration;

				$rating = $video->video->rating;
				$rating = ceil($rating * 100);

				$ratings = $video->video->ratings;

				if(!empty($video->tags)){

					$tags = "";
					foreach($video->tags as $tag){
						
						$tags.= $tag.", ";
					}
					
					$tags = addslashes(rtrim($tags,", "));
				}

				$categories = $video->video->category;

				$tube8_thumb_size = get_site_option( 'tubeace_tube8_api_thumb_size' );

				# get thumbs to test before adding into db
				// If display default thumb only, get URL from object. All thumbs array not needed
				if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
					
					// Tube8 returns default thumb size as specified in thumbsize parameter in API call
					$featured_img = $video->video->default_thumb;
					
				} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

					$featured_img = $video->video->default_thumb;

					if($tube8_thumb_size=='small'){
						$allThumbsArr = $video->thumbs->small;
					}
					if($tube8_thumb_size=='big'){
						$allThumbsArr = $video->thumbs->big;
					}					

					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

					if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

						// use last thumb as default
						if($tube8_thumb_size=='small'){
							$featured_img = $video->thumbs->small[(count($thumbsArr)-1)];
						}
						if($tube8_thumb_size=='big'){
							$featured_img = $video->thumbs->big[(count($thumbsArr)-1)];
						}

						echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
					}

				} else {

					// # of Thumbnails to Display and Default Thumbnail # to Display in Previews

					if($tube8_thumb_size=='small'){
						$featured_img = $video->thumbs->small[(get_site_option( 'tubeace_tube8_api_def_thumb' )-1)];
					}
					if($tube8_thumb_size=='big'){
						$featured_img = $video->thumbs->big[(get_site_option( 'tubeace_tube8_api_def_thumb' )-1)];
					}

					if($tube8_thumb_size=='small'){
						$allThumbsArr = $video->thumbs->small;
					}
					if($tube8_thumb_size=='big'){
						$allThumbsArr = $video->thumbs->big;
					}

					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');
				}

			}


			if($siteArray['site']=='youporn'){

				$title = addslashes($video->title);
				$video_id = $video->video_id;
				$url = $video->url;

				$str_time = $video->duration;
				$str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $str_time);
				sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
				$duration = $hours * 3600 + $minutes * 60 + $seconds;						
		
				$rating = $video->rating;
				$rating = ceil($rating * 20);

				$ratings = $video->ratings;

				if(!empty($video->tags)){

					$tags = "";
					foreach($video->tags as $tag){
						
						$tags.= $tag->tag_name.", ";
					}
					
					$tags = addslashes(rtrim($tags,", "));
				}

				if(!empty($video->pornstars)){

					$performersArr = array();
					foreach($video->pornstars as $pornstar){
						
						$performersArr[] = $pornstar->pornstar_name;
					}
				}

				# get thumbs to test before adding into db
				// If display default thumb only, get URL from object. All thumbs array not needed
				if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
					
					$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $video->default_thumb, $video->thumbs);

				} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

					$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $video->default_thumb, $video->thumbs);

					$allThumbsArr = $video->thumbs;
					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

					if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

						// use last thumb as default
						$featured_img = $thumbsArr[(count($thumbsArr)-1)]->src;	

						echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
					}

				} else {

					// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
					$featured_img = $video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

					$allThumbsArr = $video->thumbs;
					$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');								
				}
			}		

			// add https:// if not already there
			if (false === strpos($featured_img, '://')) {
		        $featured_img = "https:" . $featured_img;
		    }

			$display_video_count = $r + 1;

			$args = array(
				'meta_query' => array(
				 'relation' => 'AND',
					array(
						'key' => 'video_id',
						'value' => $video_id,
					),
					array(
						'key' => 'site',
						'value' => $siteArray['domain']
					)
				)
			);

			$query = new WP_Query( $args );
			$num_rows = $query->found_posts;

			if($num_rows>0){
				echo $output ='<span class="tubeace-warnmsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped. Already exists in database.</span><br>';
				$outputAll.= $output;
				ob_flush();
				flush();
			} else {

				// check minimum rating
				if( $rating_min > $rating ){

					echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$rating.' rating does not meet minimum rating.</span><br>';
					$outputAll.= $output;
					$errorInsert=1;
					ob_flush();
					flush();			
				}

				// check minimum # ratings
				if( ($ratings_num_min > $ratings) && !$errorInsert ){

					echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$ratings.' ratings does not meet minimum # ratings.</span><br>';
					$outputAll.= $output;
					$errorInsert=1;
					ob_flush();
					flush();			
				}

				// check word filter
				$tubeace_words_filter = get_site_option( 'tubeace_words_filter' );

				$wordsFilterArray = explode(',', $tubeace_words_filter);

				foreach($wordsFilterArray as $val){

					// title
					if (stripos($title, $val) !== false && !$errorInsert) {
						echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in title.</span><br>';
						$outputAll.= $output;
						$errorInsert=1;
						ob_flush();
						flush();	
					}

					// tags
					if (stripos($tags, $val) !== false && !$errorInsert) {
						echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in tags.</span><br>';
						$outputAll.= $output;
						$errorInsert=1;
						ob_flush();
						flush();	
					}				

					// categories
					if (stripos($categories, $val) !== false && !$errorInsert) {
						echo $output ='<span class="tubeace-warnmsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - '.$val.' found in categories.</span><br>';
						$outputAll.= $output;
						$errorInsert=1;
						ob_flush();
						flush();	
					}	
				}

				// check thumbs array
				if(!$errorInsert && !empty($thumbsArr)){

					// check thumbs valid
					foreach($thumbsArr as $val){

						$thumb_src = $val;

						// pornhub, redtube thumbs in objects
						if( !empty( $val->src ) ){
							$thumb_src = $val->src;
						}

						// tube8 uses protocol-relative URLs, add https:// if not already there
						if (false === strpos($thumb_src, '://')) {
					        $thumb_src = "https:" . $thumb_src;
					    }
						
						if(!@getimagesize($thumb_src) && !$errorInsert){
							echo $output ='<span class="tubeace-errormsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - Thumbnail URL \'<a href="'.stripslashes($thumb_src).'" target="_blank">'.stripslashes($thumb_src).'</a>\' invalid.</span><br>';
							$outputAll.= $output;
							$errorInsert=1;
							ob_flush();
							flush();					
						}
					}
				}

				// check single thumb only
				if(!$errorInsert && empty($thumbsArr)){				

					if(!@getimagesize($featured_img) && !$errorInsert){
						echo $output ='<span class="tubeace-errormsg">Video <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' skipped - Thumbnail URL \'<a href="'.stripslashes($featured_img).'" target="_blank">'.stripslashes($featured_img).'</a>\' invalid.</span><br>';
						$outputAll.= $output;
						$errorInsert=1;
						ob_flush();
						flush();					
					}
				}


				if(!$errorInsert){
			
		        	// Tags
					// Merge Imported Tags with Set All
					if( $tags_method=='merge_tags_y_setall' ){
						$tags = $tags.','.$tags_set_all;
					}

					// Import only Channels as Tags
					if( $tags_method=='only_channels_as_tags' ){
						$tags = $categories;
					}

					// Import Channels as Tags and Merge with Set All
					if( $tags_method=='merge_channels_as_tags_y_setall' ){
						$tags = $categories.','.$tags_set_all;
					}

					// Import only Tags
					if( $tags_method=='only_tags' ){
						$tags = $tags;
					}

					// Merge Imported Tags with Set All
					if( $tags_method=='merge_tags_y_setall' ){
						$tags = $tags.','.$tags_set_all;
					}

					// Import Channels as Tags, Import Tags, and Merge with Set All
					if( $tags_method=='merge_channels_as_tags_y_tags_y_setall' ){
						$tags = $categories.','.$tags.','.$tags_set_all;
					}

					// Set All
					if( $tags_method=='setall' ){
						$tags = $tags_set_all;
					}

					// Performers
					if( $performers_method=='merge'){

						// explode set all into array
						$performers_set_allArr = explode(',', $performers_set_all);

						// merge
						if(is_array($performersArr)){
							$performersArr = array_merge($performers_set_allArr, $performersArr);
						} else {
							$performersArr = $performers_set_allArr;
						}

					}

					if( empty($performers_method) || $performers_method=='setall' ){

						$performers = $performers_set_all;

						// explode into array
						$performersArr = explode(',', $performers);					
					}

					//make pending until thumb generated
					if($status=="publish"){
						$status_alt = "draft";
					} 

					//insert
					$my_post = array(
					  'post_title'    => $title,
					  'post_content'  => $description,
					  'post_status'   => $status_alt,
					  'post_author'   => $sponsor,
					  'post_category' => $post_category,
					  'tags_input' => $tags
					  //'tax_input' => array( 'performer' => $performersArr ) // won't work for cron
					);

					// Insert the post into the database
					if($lastID = wp_insert_post( $my_post )){

						//custom taxonomy must be done using wp_set_object_terms() for cron
						wp_set_object_terms($lastID, $performersArr, 'performer');							

						//add meta value
						add_post_meta($lastID, 'video_id', $video_id);
						add_post_meta($lastID, 'url', $url);
						add_post_meta($lastID, 'duration', $duration);
						add_post_meta($lastID, 'site', $siteArray['domain']);

						if( !empty($sponsor_link_url) ){
							add_post_meta($lastID, 'sponsor_link_url', $sponsor_link_url);
						}
						
						if( !empty($sponsor_link_txt) ){
							add_post_meta($lastID, 'sponsor_link_txt', $sponsor_link_txt);
						}

						if( !empty($misc1) ){
							add_post_meta($lastID, 'misc1', $misc1);
						}

						if( !empty($misc2) ){
							add_post_meta($lastID, 'misc2', $misc2);
						}

						if( !empty($misc3) ){
							add_post_meta($lastID, 'misc3', $misc3);
						}

						if( !empty($misc4) ){
							add_post_meta($lastID, 'misc4', $misc4);
						}

						if( !empty($misc5) ){
							add_post_meta($lastID, 'misc5', $misc5);
						}
						
						if(isset($tubeace_is_running_cron)==1){
							add_post_meta($lastID, 'cron_id', $cron_id);
						}

						echo $output ='<span class="tubeace-succmsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' added.</span><br>';
						$outputAll.= $output;
					} else {
						echo $output ='<span class="tubeace-errormsg">Video titled <b>\''.stripslashes($title).'\'</b> of video #'.$display_video_count.' not added.</span><br>';
						$outputAll.= $output;
					}

					ob_flush();
					flush();	

		            // video post format
		            if( get_site_option( 'tubeace_import_as_video_post_format' ) == 1 ){

			            set_post_format( $lastID , 'video');
		            }				

		            // save thumbs to server or store source URLs
		            if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_save_thumbs' ) == 1 ){ // save thumbs to server


		            	// if not default thumb only, do multiple thumbs
		            	if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) != 1 ){

		            		// detect default thumb #
		            		$def_thmb = tubeace_detect_def_thmb($siteArray['site'], $featured_img, $thumbsArr, 'api');

							// multiple thumbs
							tubeace_create_thumbs($siteArray['site'], $lastID, $thumbsArr, 'api', $def_thmb);		            		
		            	}

			            // create featured image
			            tubeace_create_featured_image($lastID, $featured_img);


		            } else { // don't save thumbs, serve from cdn

		            	$thumbs_src = '';

		            	if( !empty($thumbsArr) ){

			            	// create string of semicolon separated thumbs
			            	foreach($thumbsArr as $val){

								// get thumb from object
								if( !empty( $val->src ) ){
									$val = $val->src;
								}

								// tube8 uses protocol-relative URLs now for $val->src;
								if (false === strpos($val, '://')) {
							        $val = "https:" . $val;
							    }

			            		$thumbs_src.= $val.';';
			            	}

		            	}

		            	$thumbs_src = rtrim($thumbs_src, ";");

		            	if( !empty($thumbs_src) ){
		            		add_post_meta($lastID, 'thumbs_src', $thumbs_src);
		            	}
		            	
		            	add_post_meta($lastID, 'def_thumb_url', $featured_img);
		            	add_post_meta($lastID, '_thumbnail_id', '6969TA' ); // needed for post_thumbnail_html hook to load
		            }

					//thumbs generated, now set to publish
					if($status=="publish"){

						$my_post = array(
						  'ID'           => $lastID,
						  'post_status' => 'publish'
						);
						wp_update_post( $my_post );
					} 						

					//auto-scheduling
					if(get_site_option('tubeace_schedule_per_day')>0){
						
						$schedDate = tubeace_auto_sched_next_date(0);

						$wpdb->update( $wpdb->prefix . 'posts', array('post_date' => "$schedDate 00:00:00", 'post_date_gmt' => "$schedDate 00:00:00"), array('id' => $lastID));
											
						echo $output ='<span class="tubeace-succmsg">Video #$lastID Auto-Scheduled to $schedDate</span><br>';
						$outputAll.= $output;
					}
				}
			}

			$r++;

			if($r==count($videos)){
				echo $output ="<b>Imported Page $page</b><br><br>";	
				$outputAll.= $output;
			    ob_flush();
			    flush();	
			}				
		}
	} else {

		echo '<span class="tubeace-errormsg">No results returned from API. This may be because your search returned no results or the API is down. Please try a different search query or try again later. </span><br>';
	}


?>