<?php

if(isset($_GET['single_import'])){ 

	$video_id = $_GET['video_id'];
	$post_date = $_GET['post_date'];
	$post_status = $_GET['post_status'];
	$sponsor = $_GET['sponsor'];
	$title = $_GET['title'];
	$tags = $_GET['tags'];
	$duration = $_GET['duration'];
	$post_category = (isset($_GET['post_category'])) ? $_GET['post_category'] : null;
	
	$description = $_GET['description'];
	$performers = $_GET['performers'];
	$sponsor_link_txt = $_GET['sponsor_link_txt'];
	$sponsor_link_url = $_GET['sponsor_link_url'];
	$misc1 = $_GET['misc1'];
	$misc2 = $_GET['misc2'];
	$misc3 = $_GET['misc3'];
	$misc4 = $_GET['misc4'];
	$misc5 = $_GET['misc5'];
		
	$performersArr = explode(",", $performers);

	//insert
	$my_post = array(
	  'post_title'    => $title,
	  'post_content'  => $description,
	  'post_status'   => $post_status,
	  'post_author'   => $sponsor,
	  'post_category' => $post_category,
	  'tags_input' => $tags,
	  'tax_input' => array( 'performer' => $performersArr ) 
	);

	$lastID = wp_insert_post( $my_post );

	//add meta value
	add_post_meta($lastID, 'video_id', $video_id);
	add_post_meta($lastID, 'duration', $duration);
	add_post_meta($lastID, 'site', $siteArray['domain']);
	add_post_meta($lastID, 'sponsor_link_url', $sponsor_link_url);
	add_post_meta($lastID, 'sponsor_link_txt', $sponsor_link_txt);
	add_post_meta($lastID, 'misc1', $misc1);
	add_post_meta($lastID, 'misc2', $misc2);
	add_post_meta($lastID, 'misc3', $misc3);
	add_post_meta($lastID, 'misc4', $misc4);
	add_post_meta($lastID, 'misc5', $misc5);


	if($siteArray['site']=='pornhub'){

		$url = 'http://www.pornhub.com/webmasters/video_by_id?id='.$video_id.'&thumbsize='.get_site_option( 'tubeace_pornhub_api_thumb_size' );

		$data = file_get_contents($url);
		$data = json_decode($data);

		# get thumbs to test before adding into db
		// If display default thumb only, get URL from object. All thumbs array not needed
		if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
			
			// it appears pornhub 'default_thumb' is always 12.jpg, 'thumb' varies but can have a filename of 0 and doesn't exist in thumbs array, so we'll use 'default_thumb'
			$featured_img = $data->video->default_thumb;

		} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

			$featured_img = $data->video->default_thumb;

			$allThumbsArr = $data->video->thumbs;
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

			if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

				// use last thumb as default
				$featured_img = $thumbsArr[(count($thumbsArr)-1)]->src;	

				//echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
			}

		} else {

			// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
			$featured_img = $data->video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

			$allThumbsArr = $data->video->thumbs;
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');								
		}
	}	

	if($siteArray['site']=='redtube'){

		$url = 'http://api.redtube.com/?data=redtube.Videos.getVideoById&video_id='.$video_id.'&output=json&thumbsize='.get_site_option( 'tubeace_redtube_api_thumb_size' );

		$data = file_get_contents($url);
		$data = json_decode($data);

		# get thumbs to test before adding into db
		// If display default thumb only, get URL from object. All thumbs array not needed
		if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
			
			$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $data->video->default_thumb, $data->video->thumbs);

		} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

			$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $data->video->default_thumb, $data->video->thumbs);

			$allThumbsArr = $data->video->thumbs;
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

			if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

				// use last thumb as default
				$featured_img = $thumbsArr[(count($thumbsArr)-1)]->src;	

				//echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
			}

		} else {

			// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
			$featured_img = $data->video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

			$allThumbsArr = $data->video->thumbs;
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');									
		}


	}	

	if($siteArray['site']=='tube8'){

		$url = 'http://api.tube8.com/api.php?action=getvideobyid&video_id='.$video_id.'&output=json&thumbsize='.get_site_option( 'tubeace_tube8_api_thumb_size' );
	
		$data = file_get_contents($url);
		$data = json_decode($data);

		$tube8_thumb_size = get_site_option( 'tubeace_tube8_api_thumb_size' );

		# get thumbs to test before adding into db
		// If display default thumb only, get URL from object. All thumbs array not needed
		if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
			
			// Tube8 returns default thumb size as specified in thumbsize parameter in API call
			$featured_img = $data->video->default_thumb;
			
		} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

			$featured_img = $data->video->default_thumb;

			if($tube8_thumb_size=='small'){
				$allThumbsArr = $data->thumbs->small;
			}
			if($tube8_thumb_size=='big'){
				$allThumbsArr = $data->thumbs->big;
			}					

			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

			if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

				// use last thumb as default
				if($tube8_thumb_size=='small'){
					$featured_img = $data->thumbs->small[(count($thumbsArr)-1)];
				}
				if($tube8_thumb_size=='big'){
					$featured_img = $data->thumbs->big[(count($thumbsArr)-1)];
				}

				//echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
			}

		} else {

			// # of Thumbnails to Display and Default Thumbnail # to Display in Previews

			if($tube8_thumb_size=='small'){
				$featured_img = $data->thumbs->small[(get_site_option( 'tubeace_tube8_api_def_thumb' )-1)];
			}
			if($tube8_thumb_size=='big'){
				$featured_img = $data->thumbs->big[(get_site_option( 'tubeace_tube8_api_def_thumb' )-1)];
			}

			if($tube8_thumb_size=='small'){
				$allThumbsArr = $data->thumbs->small;
			}
			if($tube8_thumb_size=='big'){
				$allThumbsArr = $data->thumbs->big;
			}

			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');
		}
	}

	if($siteArray['site']=='youporn'){

		$url = 'http://www.youporn.com/api/webmasters/video_by_id/?video_id='.$video_id.'&thumbsize='.get_site_option( 'tubeace_youporn_api_thumb_size' );
	
		$data = file_get_contents($url);
		$data = json_decode($data);

		# get thumbs to test before adding into db
		// If display default thumb only, get URL from object. All thumbs array not needed
		if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) == 1 ){ // single default thumb only
			
			$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $data->video->default_thumb, $data->video->thumbs);

		} elseif( get_site_option( 'tubeace_'.$siteArray['site'].'_api_use_def_thumb' ) == 1 ) { // use default as thumbnail and rotating thumbs

			$featured_img =  tubeace_get_default_thumb_url($siteArray['site'], $data->video->default_thumb, $data->video->thumbs);

			$allThumbsArr = $data->video->thumbs;
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');

			if( tubeace_verify_featured_img_in_thumb_array($siteArray['site'], $featured_img, $thumbsArr) !== true ){

				// use last thumb as default
				$featured_img = $thumbsArr[(count($thumbsArr)-1)]->src;	

				//echo 'Default thumbnail was purged, using last thumbnail instead.<br>';
			}

		} else {

			// # of Thumbnails to Display and Default Thumbnail # to Display in Previews
			$featured_img = $data->video->thumbs[(get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb' )-1)]->src;

			$allThumbsArr = $data->video->thumbs;
			$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'api');								
		}


	}

    // video post format
    if( get_site_option( 'tubeace_import_as_video_post_format' ) == 1 ){

        set_post_format( $lastID , 'video');
    }	

    // purge unneeded thumbs
	$thumbsArr = tubeace_purge_thumbs($siteArray['site'], $thumbsArr, 'api');


/*
	// multiple thumbs
	tubeace_create_thumbs($siteArray['site'], $lastID, $thumbsArr, 'api');

    // create featured image
    tubeace_create_featured_image($lastID, $featured_img);
*/


    // video post format
    if( get_site_option( 'tubeace_import_as_video_post_format' ) == 1 ){

        set_post_format( $lastID , 'video');
    }				

    // save thumbs to server or store source URLs
    if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_save_thumbs' ) == 1 ){ // save thumbs to server


    	// if not default thumb only, do multiple thumbs
    	if( get_site_option( 'tubeace_'.$siteArray['site'].'_api_def_thumb_only' ) != 1 ){

    		// detect default thumb #
    		$def_thmb = tubeace_detect_def_thmb($siteArray['site'], $featured_img, $thumbsArr, 'api');

			// multiple thumbs
			tubeace_create_thumbs($siteArray['site'], $lastID, $thumbsArr, 'api', $def_thmb);		            		
    	}

        // create featured image
        tubeace_create_featured_image($lastID, $featured_img);


    } else { // don't save thumbs, serve from cdn

    	$thumbs_src = '';

    	if( !empty($thumbsArr) ){

        	// create string of semicolon separated thumbs
        	foreach($thumbsArr as $val){

				// get thumb from object
				if( !empty( $val->src ) ){
					$val = $val->src;
				}

				// tube8 uses protocol-relative URLs now for $val->src;
				if (false === strpos($val, '://')) {
			        $val = "https:" . $val;
			    }

        		$thumbs_src.= $val.';';
        	}

    	}

    	$thumbs_src = rtrim($thumbs_src, ";");

    	if( !empty($thumbs_src) ){
    		add_post_meta($lastID, 'thumbs_src', $thumbs_src);
    	}
    	
    	add_post_meta($lastID, 'def_thumb_url', $featured_img);
    	add_post_meta($lastID, '_thumbnail_id', '6969TA' ); // needed for post_thumbnail_html hook to load
    }




	echo'
	<div class="wrap">
		<h2>'.$siteArray['site_name'].' Import - Single Video</h2>
		<span class="tubeace-succmsg">Video titled \''.$title.'\' added! </span>
	</div>';
}
