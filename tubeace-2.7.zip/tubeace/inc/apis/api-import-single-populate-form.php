<?php 

//populate single form
if(isset($_GET['single'])){ 

	//check if video id entered		
	if( empty($_GET['video_id']) ){

		echo'<div class="error"><p><b>You must enter a Video ID to import a specific single video.</b></p></div>';
		api_form($siteArray);
		return;
	}

	$video_id = $_GET['video_id'];


	$tags = null;
	$performers = null;
	$default_thumb = null;
	$url = null;
	$title = null;
	$duration = null;

	if($siteArray['site']=='redtube'){

		$url = "http://api.redtube.com/?data=redtube.Videos.getVideoById&video_id=$video_id&output=json&thumbsize=big";
		$data = file_get_contents($url);
		$data = json_decode($data);
		
		if(!empty($data->video->tags)){

			foreach($data->video->tags as $tag){
				
				$tags.= $tag.", ";
			}
		}

		if(!empty($data->video->stars)){

			foreach($data->video->stars as $star){
				
				$performers.= $star.", ";
			}	
		}
		
		$tags = rtrim($tags,", ");
		$performers = rtrim($performers,", ");
		
		if( isset( $data->video->video_id ) ){
			$video_id = $data->video->video_id;
		}

		if( isset( $data->video->default_thumb ) ){
			$default_thumb = $data->video->default_thumb;
		}		
		
		if( isset( $data->video->url ) ){
			$url = $data->video->url;
		}		

		if( isset( $data->video->title ) ){
			$title = $data->video->title;
		}			
		
		if( isset( $data->video->duration ) ){
			$duration = $data->video->duration;
		}	
		
		sscanf($duration, "%d:%d:%d", $hours, $minutes, $seconds);
		$duration = isset($seconds) ? $hours * 3600 + $minutes * 60 + $seconds : $hours * 60 + $minutes;
	}

	if($siteArray['site']=='pornhub'){

		$url = "http://www.pornhub.com/webmasters/video_by_id?id=$video_id&thumbsize=medium";
		$data = file_get_contents($url);
		$data = json_decode($data);

		if(!empty($data->video->tags)){

			foreach($data->video->tags as $tag){
				
				$tags.= $tag->tag_name.", ";
			}
		}

		if(!empty($data->video->pornstars)){

			foreach($data->video->pornstars as $pornstar){
				
				$performers.= $pornstar->pornstar_name.", ";
			}	
		}	

		$tags = rtrim($tags,", ");
		$performers = rtrim($performers,", ");

		if( isset( $data->video->video_id ) ){
			$video_id = $data->video->video_id;
		}
		if( isset( $data->video->default_thumb ) ){
			$default_thumb = $data->video->default_thumb;
		}		
		if( isset( $data->video->url ) ){
			$url = $data->video->url;
		}		
		if( isset( $data->video->title ) ){
			$title = $data->video->title;
		}			
		if( isset( $data->video->duration ) ){
			$duration = $data->video->duration;
		}				

		sscanf($duration, "%d:%d:%d", $hours, $minutes, $seconds);
		$duration = isset($seconds) ? $hours * 3600 + $minutes * 60 + $seconds : $hours * 60 + $minutes;	
	}

	if($siteArray['site']=='tube8'){

		$url = "http://api.tube8.com/api.php?action=getvideobyid&video_id=$video_id&output=json&thumbsize=big";
		$data = file_get_contents($url);
		$data = json_decode($data);

		if(!empty($data->tags)){

			foreach($data->tags as $tag){
				
				$tags.= $tag.", ";
			}
		}

		$tags = rtrim($tags,", ");

		if( isset( $data->video->video_id ) ){
			$video_id = $data->video->video_id;
		}
		if( isset( $data->video->default_thumb ) ){
			$default_thumb = $data->video->default_thumb;
		}		
		if( isset( $data->video->url ) ){
			$url = $data->video->url;
		}		
		if( isset( $data->title ) ){
			$title = $data->title;
		}			
		if( isset( $data->video->duration ) ){
			$duration = $data->video->duration;
		}	
	}


	if($siteArray['site']=='youporn'){

		//$url = 'http://api.tube8.com/api.php?action=getvideobyid&video_id='.$video_id.'&output=json&thumbsize=big';
		$url = 'http://www.youporn.com/api/webmasters/video_by_id/?video_id='.$video_id.'&thumbsize=medium';
		
		$data = file_get_contents($url);
		$data = json_decode($data);

		if(!empty($data->video->tags)){

			foreach($data->video->tags as $tag){
				
				$tags.= $tag->tag_name.", ";
			}
		}

		if(!empty($data->video->pornstars)){

			foreach($data->video->pornstars as $pornstar){
				
				$performers.= $pornstar->pornstar_name.", ";
			}	
		}	

		$tags = rtrim($tags,", ");
		$performers = rtrim($performers,", ");

		if( isset( $data->video->video_id ) ){
			$video_id = $data->video->video_id;
		}
		if( isset( $data->video->default_thumb ) ){
			$default_thumb = $data->video->default_thumb;
		}		
		if( isset( $data->video->url ) ){
			$url = $data->video->url;
		}		
		if( isset( $data->video->title ) ){
			$title = $data->video->title;
		}			
		if( isset( $data->video->duration ) ){
			$duration = $data->video->duration;
		}			

		sscanf($duration, "%d:%d:%d", $hours, $minutes, $seconds);
		$duration = isset($seconds) ? $hours * 3600 + $minutes * 60 + $seconds : $hours * 60 + $minutes;	

		//$thumbsArr = $data->thumbs->big;
		//$featured_img = $data->thumbs->big[14];
	}


	$args = array(
		'meta_query' => array(
		 'relation' => 'AND',
			array(
				'key' => 'video_id',
				'value' => $video_id,
			),
			array(
				'key' => 'site',
				'value' => $siteArray['domain']
			)
		)
	);

	$query = new WP_Query( $args );

	$num_rows = $query->found_posts;

	if($num_rows>0){
		echo'<div class="error"><p><b>WARNING: Video already exists in database.</b></p></div>';
	}
	?>

	<div class="wrap">
		<h2><?php echo $siteArray['site_name'] ?> Import - Single Video</h2>
		<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-'.$siteArray['site'].'-api.php') ?>" method="get">
			<table class="form-table">
		    <tbody>
		      <tr>
		    		<th><label for="video_id">Thumbnail</label></th>
		        <td>
					  	<a href="<?php echo $url ?>" target="_blank"><img src="<?php echo $default_thumb ?>"><a href="<?php echo $url ?>" target="_blank"><br>
					  	<a href="<?php echo $url ?>" target="_blank">View Video Page</a>
		        </td>		        	
		      </tr>	
		    	<tr>
		    		<th><label for="post_status">Status</label></th>
	        	<td>
						  <select name="post_status" id="post_status">
								<option>publish</option>
								<option>pending</option>
								<option>draft</option>
								<option>future</option>
								<option>private</option>
						  </select>
	        	</td>	
		        </tr>	
		       <tr>
		    		<th><label for="post_date">Post Date</label></th>
		        	<td>
		        		<input type="text" class="tubeace-input-160" name="post_date" value="<?php echo date("Y-m-d H:i:s") ?>">
							</td>		        	
		        </tr>			   
		    	<tr>
		    		<th><label for="sponsor">Author / Sponsor</label></th>
		        <td>
						  <select name="sponsor" id="sponsor">
								<?php tubeace_get_users_with_role(array('Contributor','Administrator'),$vars['sponsor']); ?>
						  </select>
						  <small>To add a sponsor, <a href="user-new.php">add a new user</a> with a "Contributor" Role.</small>
		        </td>
		      </tr>
		    	<tr>
		    		<th><label for="category">Category</label></th>
		        <td>
		        	<ul id="categorychecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
								<?php wp_category_checklist( $args ); ?>
							</ul> 
		        </td>
		      </tr>	
		      <tr>
		    		<th><label for="title">Title</label></th>
	        	<td>
	        	  <input type="text" class="tubeace-input-400" name="title" value="<?php echo $title ?>">
						</td>		        	
		      </tr>	
		      <tr>
		    		<th><label for="tags">Tags</label></th>
		        <td>
		        	<input type="text" class="tubeace-input-400" name="tags" value="<?php echo $tags ?>">
						</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="performers">Performers</label></th>
		        <td>
		        	<input type="text" class="tubeace-input-400" name="performers" value="<?php echo $performers ?>">
						</td>		        	
		      </tr>	
		      <tr>
		    		<th><label for="duration">Duration</label></th>
		        <td>
		        	<input type="text" class="tubeace-input-60" name="duration" value="<?php echo $duration ?>">
						</td>		        	
		      </tr>	
		      <tr>
		    		<th><label for="description">Description</label></th>
		        	<td>
		        	  <textarea name="description" class="tubeace-input-400" rows="5" cols="40"></textarea>
						</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="sponsor_link_txt">Sponsor Link Anchor Text</label></th>
	        	<td>
	        	  <input type="text" class="tubeace-input-400" name="sponsor_link_txt">
						</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="sponsor_link_url">Sponsor Link URL</label></th>
	        	<td>
	        	  <input type="text" class="tubeace-input-400" name="sponsor_link_url">
						</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="misc1">Misc 1</label></th>
		        	<td>
		        	  <textarea class="tubeace-input-400" name="misc1"></textarea>
							</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="misc2">Misc 2</label></th>
		        <td>
		        	 <textarea class="tubeace-input-400" name="misc2"></textarea>
						</td>		        	
		      </tr>	
		      <tr>
		    		<th><label for="misc3">Misc 3</label></th>
	        	<td>
	        	  <textarea class="tubeace-input-400" name="misc3"></textarea>
						</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="misc4">Misc 4</label></th>
		        	<td>
		        	  <textarea class="tubeace-input-400" name="misc4"></textarea>
							</td>		        	
		      </tr>
		      <tr>
		    		<th><label for="misc5">Misc 5</label></th>
	        	<td>
	        	  <textarea class="tubeace-input-400" name="misc5"></textarea>
						</td>		        	
		      </tr>			 
		      <tr>
		    		<th></th>
	        	<td>
					  	<input type="hidden" name="video_id" value="<?php echo $video_id ?>">	  
					  	<input type="hidden" name="page" value="tubeace/tubeace-<?php echo $siteArray['site'] ?>-api.php">
					    <input class="button-primary" type="submit" name="single_import" value="Add Video">
						</td>		        	
		      </tr>		
		    </tbody>
			</table>
		</form>
	</div>
<?php
}