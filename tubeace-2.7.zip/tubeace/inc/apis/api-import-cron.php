<?php
// cron
if(isset($_GET['cron'])){

	// hubtraffic
	$tag = isset($_GET['tag']) ? $_GET['tag'] : '';
	$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

	$start = isset($_GET['start']) ? $_GET['start'] : '';
	$end = isset($_GET['end']) ? $_GET['end'] : '';

	$ordering = isset($_GET['ordering']) ? $_GET['ordering'] : '';

	// xhamster
	$cats = isset($_GET['cats']) ? $_GET['cats'] : '';
	$cnt = isset($_GET['cnt']) ? $_GET['cnt'] : '';
	$resolution = isset($_GET['resolution']) ? $_GET['resolution'] : '';
	$period = isset($_GET['period']) ? $_GET['period'] : '';
	$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
	$rating_min = isset($_GET['rating_min']) ? $_GET['rating_min'] : '';
	$views_min = isset($_GET['views_min']) ? $_GET['views_min'] : '';

	$ratings_num_min = isset($_GET['ratings_num_min']) ? $_GET['ratings_num_min'] : '';

	$status = isset($_GET['status']) ? $_GET['status'] : '';
	$sponsor = isset($_GET['sponsor']) ? $_GET['sponsor'] : '';
	$post_date = isset($_GET['post_date']) ? $_GET['post_date'] : '';
	$post_category = isset($_GET['post_category']) ? $_GET['post_category'] : '';	
	
	$description = $_GET['description'];
	$tags_set_all = $_GET['tags'];
	$tags_method = $_GET['tags_method'];
	$performers_set_all = $_GET['performers'];
	$performers_method = $_GET['performers_method'];
	$sponsor_link_txt = $_GET['sponsor_link_txt'];
	$sponsor_link_url = $_GET['sponsor_link_url'];
	$misc1 = $_GET['misc1'];
	$misc2 = $_GET['misc2'];
	$misc3 = $_GET['misc3'];
	$misc4 = $_GET['misc4'];
	$misc5 = $_GET['misc5'];

	$cron_name = $_GET['cron_name'];	
	$cron_frequency = $_GET['cron_frequency'];

	if( tubeace_license_status() !== true){
		echo'Cron Job creation not available in demo version. ';	
	 	return;
	}	

	// make sure cron name not empty
	if(empty($cron_name)){

		echo'<div class="error"><p><b>Job name required to create auto-import (cron) job.</b></p></div>';
		tubeace_api_form($siteArray, $categoriesArr, $_GET);
		return;
	}	

	echo'
	<div class="wrap">
	  <h2> '.$siteArray['site_name'].' Auto-Import (Cron) Setup</h2>';

            // increment
            $tubeace_cron_last_id = get_site_option('tubeace_cron_last_id');
            $tubeace_cron_last_id++;	  		
            update_site_option('tubeace_cron_last_id', $tubeace_cron_last_id);

			// assoc array of cron values to store in options
			$cronValues=array(

				'cron_id' => $tubeace_cron_last_id,

				// hubtraffic
				'keyword' => $keyword,
				'tag' => $tag,
				'start' => $start,
				'end' => $end,

				'ordering' => $ordering,

				// xhamster
				'cats' => $cats,
				'cnt' => $cnt,
				'resolution' => $resolution,
				'period' => $period,
				'orderby' => $orderby,
				'rating_min' => $rating_min,
				'views_min' => $views_min,
				
				'ratings_num_min' => $ratings_num_min,

				'status'=> $status,
				'sponsor' => $sponsor,
				'post_date' => $post_date,
				'post_category' => $post_category,
				'description' => $description,
				'tags' => $tags_set_all,
				'tags_method' => $tags_method,
				'performers' => $performers_set_all,
				'performers_method' => $performers_method,
				'sponsor_link_txt' => $sponsor_link_txt,
				'sponsor_link_url' => $sponsor_link_url,
				'misc1' => $misc1,
				'misc2' => $misc2,
				'misc3' => $misc3,
				'misc4' => $misc4,
				'misc5' => $misc5,
				'running' => 0,
				'running_current_page' => 1
			);

			// create event
			if ( ! wp_next_scheduled( 'tubeace_'.$cron_frequency ) ) {
			  wp_schedule_event( time(), $cron_frequency, 'tubeace_'.$cron_frequency );
			}

			// create event
			if ( ! wp_next_scheduled( 'tubeace_detect_stalled_cron' ) ) {
			  wp_schedule_event( time(), 'hourly', 'tubeace_detect_stalled_cron' );
			}			

			// get existing cron jobs (serialized array) for frequency
			$existingCronNames = get_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_frequency);

			// replace space with underscore
			$cron_name = str_replace(' ','_', $cron_name);

			// remove non-alphanumeric characters
			$cron_name = preg_replace("/[^A-Za-z0-9 ]/", '', $cron_name);

			if(empty($existingCronNames)){

				$cronNames = array($cron_name);

				update_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_frequency, $cronNames);	
				update_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_name.'_'.$cron_frequency, $cronValues);

				echo'<div class="updated"><p><b>Added '.tubeace_cron_frequency_label($cron_frequency).' cron named \''.$cron_name.'\'. <a href="admin.php?page=tubeace/tubeace-cron.php">View Auto-Import Page</a></b></p></div>';

			} else { // if already exists, we need to add name to tubeace_cron_redtube_{frequency}

				// make sure name doesn't exist
				if(in_array($cron_name,$existingCronNames)){

					echo'<div class="error"><p><b>Cron name \''.$cron_name.'\' already used!</b></p></div>';

				} else {

					$cron_name_arr = array($cron_name);// make array to merge
					$cronNames = array_merge($existingCronNames,$cron_name_arr);

					update_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_frequency, $cronNames);	
					update_site_option('tubeace_cron_'.$siteArray['site'].'_'.$cron_name.'_'.$cron_frequency, $cronValues);

					echo'<div class="updated"><p><b>Added another '.tubeace_cron_frequency_label($cron_frequency).' auto-import job named \''.$cron_name.'\'. <a href="admin.php?page=tubeace/tubeace-cron.php">View Auto-Import Page</a></b></p></div>';

				}
			}

	echo"
	</div>";
}