  <h2><?php echo $siteArray['site_name']; ?> Import <span style="float:right"><small><small><span class="dashicons dashicons-paperclip"></span><a href="https://tubeace.com/docs/<?php echo $siteArray['site']; ?>-import/" target="_blank">Documentation</a></small></small></span></h2>

<?php

//form
if(empty($_POST) && empty($_POST['import'])) {
?>

	<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-'.$siteArray['site'].'.php'); ?>" method="post" enctype="multipart/form-data">
		<table class="form-table">
		    <tbody>
		        <tr>
		        	<th><label for="file">Import File</label></th>
		        	<td>
						<input type="file" name="uploaded" id="file">				
		        	</td>
		        </tr>
		    </tbody>
		</table>

		<h3>SET ALL Values</h3>

		<table class="form-table">
		    <tbody>
		        <tr>
		    		<th><label for="status">Status</label></th>
		        	<td>
					  <select name="status" id="status">
						<option value="publish">Publish</option>
						<option value="pending">Pending</option>
						<option value="draft">Draft</option>
						<option value="future">Future</option>
						<option value="private">Private</option>
					  </select>
		        	</td>
		        </tr>
		        <tr>
		        	<th><label for="sponsor">Author / Sponsor</label></th>
		        	<td>
						  <select name="sponsor" id="sponsor">
							<?php tubeace_get_users_with_role(array('Contributor','Administrator'), null); ?>
						  </select>
						  <small>To add a sponsor, <a href="user-new.php">add a new user</a> with a "Contributor" Role.</small>
		        	</td>	
			    </tr>		        
		        <tr>
		    		<th><label for="post_date">Post Date</label></th>
		        	<td>
		        		<input name="post_date" type="text" class="input-160" id="post_date" value="<?php echo date("Y-m-d H:i:s"); ?>">
		        	</td>		        	
		        </tr>		
		        <tr>
		    		<th><label for="start">Category</label></th>
		        	<td>
						<ul id="categorychecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
						  <?php wp_category_checklist( ); ?>
						</ul> 		        		
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="description">Description</label></th>
		        	<td>
		        		<textarea name="description" class="tubeace-input-400" id="description"></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="tags_set_all">Tags</label></th>
		        	<td>
		        		<input name="tags_set_all" type="text" class="tubeace-input-400" id="tags_set_all">
		        		<small>Separate multiple tags by comma.</small>
		        		<?php

	        			// if only tags
	        			if($siteArray['site']=='porntube'){

	        				//overwrite
	        				//merge
	        				?>
	        				<br>
			        		<select name="tags_method">
			        			<option value="merge_tags_y_setall">Merge Imported Tags with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        		</select>
			        		<?php		        				
	        			}

	        			// if only channels
	        			if($siteArray['site']=='drtuber' || $siteArray['site']=='sunporno' || $siteArray['site']=='xhamster' || $siteArray['site']=='xvideos'){

	        				//import channels as tags
	        				//import channels as tags and merge with setall
	        				//only use set all
	        				?>
	        				<br>
			        		<select name="tags_method">
			        			<option value="only_channels_as_tags">Import only Channels as Tags</option>
			        			<option value="merge_channels_as_tags_y_setall" selected="selected">Import Channels as Tags and Merge with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        			<option value="none">None</option>
			        		</select>
			        		<?php
	        			}		        			

	        			// if both tags and channels 
	        			if($siteArray['site']=='keezmovies' || $siteArray['site']=='pornhub' || $siteArray['site']=='redtube' || $siteArray['site']=='spankwire' || $siteArray['site']=='tube8' || $siteArray['site']=='xtube' || $siteArray['site']=='youporn'){

	        				//import channels as tags only
	        				//import tags only
	        				//import channels as tags + tags + set all
	        				// set all only
	        				?>
	        				<br>
			        		<select name="tags_method">
			        			<option value="only_channels_as_tags">Import only Channels as Tags</option>
			        			<option value="only_tags">Import only Tags</option>
			        			<option value="merge_tags_y_setall">Merge Imported Tags with Set All</option>
			        			<option value="merge_channels_as_tags_y_tags_y_setall" selected="selected">Import Channels as Tags, Import Tags, and Merge with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        		</select>
			        		<?php
	        			}
		        		?>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="performers_set_all">Performers</label></th>
		        	<td>
		        		<input name="performers_set_all" type="text" class="tubeace-input-400" id="performers_set_all">
		        		<small>Separate multiple performers by comma.</small>
						<?php

	        			// these have performer value possibility, show option
	        			if($siteArray['site']=='keezmovies' || $siteArray['site']=='pornhub' || $siteArray['site']=='porntube' || $siteArray['site']=='redtube' || $siteArray['site']=='spankwire' || $siteArray['site']=='tube8' || $siteArray['site']=='youporn'){
	        				?>
	        				<br>
			        		<select name="performers_method">
			        			<option value="merge">Merge Imported Performers with Set All</option>
			        			<option value="setall">Use only Set All Value</option>
			        		</select>	
			        		<?php	        				
	        			}
						?>		        		
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="sponsor_link_txt">Sponsor Link Anchor Text</label></th>
		        	<td>
		        		<input name="sponsor_link_txt" type="text" class="tubeace-input-400" id="sponsor_link_txt">
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="sponsor_link_url">Sponsor Link URL</label></th>
		        	<td>
		        		<input name="sponsor_link_url" type="text" class="tubeace-input-400" id="sponsor_link_url">
		        	</td>		        	
		        </tr>		
		        <tr>
		    		<th><label for="misc1">Misc 1</label></th>
		        	<td>
		        		<textarea name="misc1" class="tubeace-input-400" id="misc1"></textarea>
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="misc2">Misc 2</label></th>
		        	<td>
		        		<textarea name="misc2" class="tubeace-input-400" id="misc2"></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="misc3">Misc 3</label></th>
		        	<td>
		        		<textarea name="misc3" class="tubeace-input-400" id="misc3"></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="misc4">Misc 4</label></th>
		        	<td>
		        		<textarea name="misc4" class="tubeace-input-400" id="misc4"></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="misc5">Misc 5</label></th>
		        	<td>
		        		<textarea name="misc5" class="tubeace-input-400" id="misc5"></textarea>
		        	</td>		        	
		        </tr>		        
		        <tr>
		    		<th></th>
		        	<td>
		        		<!-- <input type="hidden" name="page" value="tubeace/tubeace-redtube.php"> -->
						<input type="submit" value="Import" class="button-primary" name="import">
		        	</td>		        	
		        </tr>
		    </tbody>
		</table>
	</form>
<?php
}
?>
