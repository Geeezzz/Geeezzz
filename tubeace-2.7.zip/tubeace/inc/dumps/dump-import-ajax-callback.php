<?php

// The function that handles the AJAX request
function tubeace_dump_import_callback() {

    global $wpdb;
    check_ajax_referer( 'my-special-string', 'security' );

    $site = $_POST['site'];

	$line = $_POST['line'];
	$linekey = $line - 1;

	$num_added = $_POST['num_added'];

    $status = $_POST['status'];
    $sponsor = $_POST['sponsor'];
    $post_date = $_POST['post_date'];
    $post_category = json_decode(stripslashes($_POST['post_category']));

    $description = $_POST['description'];
    $tags_set_all = $_POST['tags_set_all'];
    $channels_as_tags = $_POST['channels_as_tags'];
    $tags_method = $_POST['tags_method'];
    $performers_set_all = $_POST['performers_set_all'];
    $performers_method = $_POST['performers_method'];
    $sponsor_link_txt = $_POST['sponsor_link_txt'];
    $sponsor_link_url = $_POST['sponsor_link_url'];
    $misc1 = $_POST['misc1'];
    $misc2 = $_POST['misc2'];
    $misc3 = $_POST['misc3'];
    $misc4 = $_POST['misc4'];
    $misc5 = $_POST['misc5'];

    $report = '';
    $done = '';

    $siteArray = tubeace_dump_site_array($site);

	$upload_dir = wp_upload_dir();
	$import_filename = $upload_dir['basedir'].'/tubeace-'.$site.'.csv';

	$fh = fopen($import_filename, 'r+');
	$content = fread($fh, filesize($import_filename));
	fclose($fh);

	//$content = addslashes($content);
	$content = trim($content);

	$lines = explode("\n", $content);
	$size = count($lines);

	$current = $lines[$linekey];

    if($siteArray['site']=='drtuber'){
        $fieldArr = array('video_id','video_url','thumbs','title','categories','duration','date_added');
    }

    if($siteArray['site']=='keezmovies'){
        $fieldArr = array('embed_code','thumbs','title','tags','categories','performers','duration');
    }

    if($siteArray['site']=='pornhub'){
        $fieldArr = array('embed_code','default_thumb','thumbs','title','tags','categories','performers','duration');
    }

    if($siteArray['site']=='porntube'){
        $fieldArr = array('video_id','title','thumbs','duration','performers','tags');
    }

    if($siteArray['site']=='redtube'){
        $fieldArr = array('video_id','thumbs','video_url','title','categories','tags','performers','duration','date_added');
    }

    if($siteArray['site']=='spankwire'){
        $fieldArr = array('embed_code','thumbs','title','tags','categories','performers','duration');
    }

    if($siteArray['site']=='sunporno'){
        $fieldArr = array('video_url','thumbs','title','embed_code','categories','duration');
    }

    if($siteArray['site']=='tube8'){
        $fieldArr = array('embed_code','thumb','thumbs','title','tags','categories','performers','duration','orientation');
    }

	if($siteArray['site']=='xhamster'){
		$fieldArr = array('video_id','video_url','embed_url','title','duration','date_added','thumbs','categories');
	}

    if($siteArray['site']=='xtube'){
        $fieldArr = array('video_id','embed_url','video_url','thumb','thumbs','title','tags','categories','user','undetermined','orientation','duration');
    }    

    if($siteArray['site']=='xvideos'){
        $fieldArr = array('video_url','title','duration','thumbs','embed_code','tags','video_id','categories');
    }  

    if($siteArray['site']=='youporn'){
        $fieldArr = array('embed_code','thumbs','title','tags','categories','performers','duration');
    }      

    //foreach fields
    foreach($fields = explode($siteArray['delimiter'], $current) as $fields_key => $fields_val) {

        if( tubeace_license_status() !== true){

            if( $line == 11 ){

                $report =' Demo limit reached. '; 

                $done = 1;

                $resp = array('report' => $report, 'done' => $done, 'num_added' => $num_added);
                wp_send_json($resp);

                die(); // this is required to return a proper result

            }           
        } 

        $fields_val_con = trim($fields_val);

        if($fieldArr[$fields_key]=="embed_code"){
            $embed_code = $fields_val_con;

            if( $siteArray['site']=='keezmovies' ){

                //get id
                $doc = new DOMDocument();
                @$doc->loadHTML($embed_code);

                $tags = $doc->getElementsByTagName('iframe');

                foreach ($tags as $tag) {
                       $src = $tag->getAttribute('src');
                }

                $srcArr = explode('/',$src);

                $video_id = $srcArr[4];
                $video_id = trim($video_id, '"'); //ajax needs to trim doublequotes
            }

            if( $siteArray['site']=='pornhub' ){

                //get id
                $doc = new DOMDocument();
                @$doc->loadHTML($embed_code);

                $tags = $doc->getElementsByTagName('iframe');

                foreach ($tags as $tag) {
                       $src = $tag->getAttribute('src');
                }

                $srcArr = explode('/',$src);
                $video_id = $srcArr[4];
                $video_id = trim($video_id, '"'); //ajax needs to trim doublequotes
            }

            if( $siteArray['site']=='spankwire' ){

                //get id
                $doc = new DOMDocument();
                @$doc->loadHTML($embed_code);

                $tags = $doc->getElementsByTagName('iframe');

                foreach ($tags as $tag) {
                       $src = $tag->getAttribute('src');
                }

                $srcArr = explode('=',$src);

                $video_id = intval($srcArr[1]);
            }

            if( $siteArray['site']=='sunporno' ){

                //get id
                $doc = new DOMDocument();
                @$doc->loadHTML($embed_code);

                $attrs = $doc->getElementsByTagName('iframe');

                foreach ($attrs as $attr) {
                       $src = $attr->getAttribute('src');
                }

                $srcArr = explode('/',$src);
                $video_id = $srcArr[4];
                $video_id = trim($video_id, '"');
            }

            if( $siteArray['site']=='tube8' ){

                //get id
                $doc = new DOMDocument();
                @$doc->loadHTML($embed_code);

                $tags = $doc->getElementsByTagName('iframe');

                foreach ($tags as $tag) {
                       $src = $tag->getAttribute('src');
                }

                $srcArr = explode('/',$src);
                $video_id = $srcArr[6];
                $video_id = trim($video_id, '"');
            }

            if( $siteArray['site']=='youporn' ){

                //get id
                $doc = new DOMDocument();
                @$doc->loadHTML($embed_code);

                $tags = $doc->getElementsByTagName('iframe');

                foreach ($tags as $tag) {
                       $src = $tag->getAttribute('src');
                }

                $srcArr = explode('/',$src);
                $video_id = $srcArr[4];
            }

        }  

        if($fieldArr[$fields_key]=="video_id"){
            $video_id = $fields_val_con;
        }
        if($fieldArr[$fields_key]=="title"){
            $title = $fields_val_con;

            if( $siteArray['site']=='porntube' ){

                // strip doublequotes around title
                $title = trim($title, '"');
            }

            if( $siteArray['site']=='youporn' ){

                // strip doublequotes around title
                $title = trim($title, '"');
            }    

        }
        if($fieldArr[$fields_key]=="thumbs"){
            $thumbs = $fields_val_con;
        }                
        if($fieldArr[$fields_key]=="duration"){
            $duration = $fields_val_con;

            if($siteArray['site']=='drtuber'){

                // duration matches 00:00:00 format
                preg_match("/((\d?\d):)?(\d?\d):(\d?\d)$/", $duration, $matches);

                if( !empty($matches) ){

                    $hours = $matches[2];
                    $minutes = $matches[3];
                    $seconds = $matches[4];

                    $duration = $hours * 3600 + $minutes * 60 + $seconds;
                }
            }			

            if($site=='redtube'){

                // duration matches 1s format
                $duration = str_replace('s', '', $duration);


            }

			if($site=='xhamster'){

				// duration matches 1h2m3s format
				preg_match('/((\d+)h)?(\d+)m(\d+)s/', $duration, $matches);

				if( !empty($matches)){
				    
				    $h = $matches[2];   
				    $m = $matches[3];   
				    $s = $matches[4];

				    if($h>0){
				        $hou = $h * 60 * 60;
				    } else {
				        $hou = 0;
				    }

				    if($m>0){
				        $sec = $m * 60;
				    } else {
				        $sec = 0;
				    }

				    $duration = $hou + $sec + $s;
				}
			}
            if($site=='xvideos'){

                $duration = str_replace(' sec', '', $duration);
            } 

            if($siteArray['site']=='youporn'){

                // duration matches 1h:2m:18s format
                preg_match('/((\d+)h:)?(\d+)m:(\d+)s/', $duration, $matches);

                if( !empty($matches)){
                    
                    $h = $matches[2];   
                    $m = $matches[3];   
                    $s = $matches[4];

                    if($h>0){
                        $hou = $h * 60 * 60;
                    } else {
                        $hou = 0;
                    }

                    if($m>0){
                        $sec = $m * 60;
                    } else {
                        $sec = 0;
                    }

                    $duration = $hou + $sec + $s;
                }           
            }

        }
        if($fieldArr[$fields_key]=="tags"){

            $tags = $fields_val_con;

            if( $siteArray['site']=='porntube' ){

                // strip doublequotes around tags
                $tags = trim($tags, '"');
            }


            // redtube modified export file with ids of categories, tags, performers possibly temporarily
            if($siteArray['site']=='redtube' && strpos($tags, '::') !== false){

                // return string of tags
                $tagsArr = explode(',', $tags);

                $tags = '';
                foreach ($tagsArr as $value) {
                    
                    $valuesArray = explode('::', $value);

                    $tags.= $valuesArray[1].',';
                }

            }

            if( $siteArray['site']=='youporn' ){

                // strip doublequotes around tags
                $tags = trim($tags, '"');
            }

        }
        if($fieldArr[$fields_key]=="performers"){
           $performers = $fields_val_con;

            if( $siteArray['site']=='porntube' ){

                // strip doublequotes around performers
                $performers = trim($performers, '"');
            }

            if( $siteArray['site']=='youporn' ){

                // strip doublequotes around performers
                $performers = trim($performers, '"');
            }

            // redtube modified export file with ids of categories, tags, performers possibly temporarily
            if($siteArray['site']=='redtube' && strpos($performers, '::') !== false ){

                // return string of tags
                $performersArr = explode(',', $performers);

                $performers = '';
                foreach ($performersArr as $value) {
                    
                    $valuesArray = explode('::', $value);

                    $performers.= $valuesArray[1].',';
                }

            }            

        }    
        if($fieldArr[$fields_key]=="categories"){
           $categories = $fields_val_con;

            // redtube modified export file with ids of categories, tags, performers possibly temporarily
            if($siteArray['site']=='redtube' && strpos($categories, '::') !== false  ){

                // return string of tags
                $categoriesArr = explode(',', $categories);


                $categories = '';
                foreach ($categoriesArr as $value) {
                    
                    $valuesArray = explode('::', $value);

                    $categories.= $valuesArray[1].',';
                }

            }


        }                
    }

    //check for duplicate
    $args = array(
        'meta_query' => array(
         'relation' => 'AND',
            array(
                'key' => 'video_id',
                'value' => $video_id,
            ),
            array(
                'key' => 'site',
                'value' => $siteArray['domain']
            )
        )
    );

    $query = new WP_Query( $args );

    $num_rows = $query->found_posts;

    if ($num_rows > 0){

      $report='<span class="tubeace-warnmsg">Video skipped! Video titled <b>\''.$title.'\'</b> already exists in database.</span><br>';
    } elseif(!is_numeric($duration)) { //check for corrupt lines

      $report='<span class="tubeace-errormsg">Video skipped! Video titled <b>\''.$title.'\'</b> duration not an integer: '.$duration.'.</span><br>';          
    } elseif(empty($thumbs)) {

      $report='<span class="tubeace-errormsg">Video skipped! Video titled <b>\''.$title.'\'</b> Thumbs field empty.</span><br>';
    } else {            






        $allThumbsArr = explode($siteArray['thumbs_delimiter'], $thumbs);

        $thumbsArr = tubeace_purge_thumbs($siteArray['site'], $allThumbsArr, 'dump');

        //check thumbs valid
        foreach($thumbsArr as $val){

          if(!@getimagesize($val) && !@$errorInsert){
            $report='<span class="tubeace-errormsg">Video \''.$title.'\' skipped - Thumbnail URL invalid!</span><br>';
            $errorInsert=1;
          }
        } 


        if(@!$errorInsert){

            // Categories
            // may need to strtolower (redtube)
            $categories = strtolower($categories); 

            // Tags
            // Merge Imported Tags with Set All
            if( $tags_method=='merge_tags_y_setall' ){
                $tags = $tags.','.$tags_set_all;
            }

            // Import only Channels as Tags
            if( $tags_method=='only_channels_as_tags' ){
                $tags = $categories;
            }

            // Import Channels as Tags and Merge with Set All
            if( $tags_method=='merge_channels_as_tags_y_setall' ){
                $tags = $categories.','.$tags_set_all;
            }

            // Import only Tags
            if( $tags_method=='only_tags' ){
                $tags = $tags;
            }

            // Merge Imported Tags with Set All
            if( $tags_method=='merge_tags_y_setall' ){
                $tags = $tags.','.$tags_set_all;
            }

            // Import Channels as Tags, Import Tags, and Merge with Set All
            if( $tags_method=='merge_channels_as_tags_y_tags_y_setall' ){
                $tags = $categories.','.$tags.','.$tags_set_all;
            }

            // Set All
            if( $tags_method=='setall' ){
                $tags = $tags_set_all;
            }
            
            // may need to replace ; (pornhub)
            $tags = str_replace(';', ',', $tags);

            // may need to strtolower (pornhub)
            $tags = strtolower($tags);

            // may have 'unknown' as category (xvideos)
            $tags = str_replace('unknown', '', $tags);

            // Performers
            if( $performers_method=='merge' ){

                $performers = $performers.','.$performers_set_all;

                // may need to replace ; (pornhub)
                $performers = str_replace(';', ',', $performers);               

                // explode into array
                $performersArr = explode(',', $performers);
            }

            if( empty($performers_method) || $performers_method=='setall' ){

                $performers = $performers_set_all;

                // explode into array
                $performersArr = explode(',', $performers);                 
            }          

            //make pending until thumb generated
            if($status=="publish"){
                $status_alt = "draft";
            } 

            //insert
            $my_post = array(
              'post_title'    => $title,
              'post_content'  => $description,
              'post_status'   => $status_alt,
              'post_author'   => $sponsor,
              'post_category' => $post_category,
              'tags_input' => $tags
            );

            // Insert the post into the database
            if($lastID = wp_insert_post( $my_post )){

                //custom taxonomy must be done using wp_set_object_terms() for cron
                wp_set_object_terms($lastID, $performersArr, 'performer');                            

                //add meta value
                add_post_meta($lastID, 'video_id', $video_id);
               
                if( !empty($duration) ){
                    add_post_meta($lastID, 'duration', $duration);
                }               

                add_post_meta($lastID, 'site', $siteArray['domain']);
                        
                if( !empty($sponsor_link_url) ){
                    add_post_meta($lastID, 'sponsor_link_url', $sponsor_link_url);
                }
                if( !empty($sponsor_link_txt) ){
                    add_post_meta($lastID, 'sponsor_link_txt', $sponsor_link_txt);
                }
                if( !empty($misc1) ){
                    add_post_meta($lastID, 'misc1', $misc1);
                }
                if( !empty($misc2) ){
                    add_post_meta($lastID, 'misc2', $misc2);
                }
                if( !empty($misc3) ){
                    add_post_meta($lastID, 'misc3', $misc3);
                }
                if( !empty($misc4) ){
                    add_post_meta($lastID, 'misc4', $misc4);
                }
                if( !empty($misc5) ){
                    add_post_meta($lastID, 'misc5', $misc5);
                }                

                $report='<span class="tubeace-succmsg">Added line# '.$line.' '.$title.'</span><br>';

            } else {
                $report='<span class="tubeace-errormsg">Line# '.$line.' '.$title.' not added.</span><br>';

            }

            // video post format
            if( get_site_option( 'tubeace_import_as_video_post_format' ) == '1' ){

                set_post_format( $lastID , 'video');
            }   

            // multiple thumbs
            $def_thmb = tubeace_create_thumbs($site, $lastID, $thumbsArr, 'dump');

            // create featured image
            tubeace_create_featured_image($lastID, $def_thmb);  

            //thumbs generated, no set to publish
            if($status=="publish"){

                $my_post = array(
                  'ID'           => $lastID,
                  'post_status' => 'publish'
                );
                wp_update_post( $my_post );

            }    

            //auto-scheduling
            if(get_site_option('tubeace_schedule_per_day')>0){
                
                $schedDate = tubeace_auto_sched_next_date(0);

                $wpdb->update( $wpdb->prefix . 'posts', array('post_date' => "$schedDate 00:00:00", 'post_date_gmt' => "$schedDate 00:00:00"), array('id' => $lastID));
                                    
                $report.='<span class="tubeace-succmsg">Video #'.$lastID.' Auto-Scheduled to '.$schedDate.'</span><br>';                          
            }

            $num_added++;
        }

    }

    if( $size == $line ){
        $done=1;
    }    

    if($done){

        $report.='<br><b>Import Complete. Added '.$num_added.' videos to the database.</b>';
    }    

    $resp = array('done' => $done, 'report' => $report, 'num_added' => $num_added);
    wp_send_json($resp);

 	die(); // this is required to return a proper result
}
add_action( 'wp_ajax_tubeace_dump_import', 'tubeace_dump_import_callback' );

