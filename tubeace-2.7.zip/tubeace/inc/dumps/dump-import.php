<?php

if(isset($_POST['import'])){

	$post_date = $_POST['post_date'];
	$status = $_POST['status'];
	$sponsor = $_POST['sponsor'];
	$post_category = tubeace_get_the_post_data('post_category');
	$description = $_POST['description'];
	$tags_set_all = $_POST['tags_set_all'];
	$channels_as_tags = tubeace_get_the_post_data('channels_as_tags'); // xhamster,drtuber
	$tags_method = $_POST['tags_method']; // xvideos
	$performers_set_all = $_POST['performers_set_all'];
	$performers_method = tubeace_get_the_post_data('performers_method');
	$sponsor_link_txt = $_POST['sponsor_link_txt'];
	$sponsor_link_url = $_POST['sponsor_link_url'];
	$misc1 = $_POST['misc1'];
	$misc2 = $_POST['misc2'];
	$misc3 = $_POST['misc3'];
	$misc4 = $_POST['misc4'];
	$misc5 = $_POST['misc5'];

	$tmpName  = $_FILES['uploaded']['tmp_name'];
	$fileSize = $_FILES['uploaded']['size'];		

	$upload_dir = wp_upload_dir();

	if(!empty($tmpName)){
		copy($tmpName, $upload_dir['basedir'].'/tubeace-'.$siteArray['site'].'.csv');
	} else {
		echo'<div class="error"><p><b>Import file not uploaded.</b></p></div>';
		$error=1;
	}

	if(empty($error)){

		if( get_site_option( 'tubeace_ajax_import' ) == 1 ) {
			require_once 'dump-import-ajax.php';
		} else {
			require_once 'dump-import-process.php';
		}
	}
}