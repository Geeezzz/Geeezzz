<?php

// The JavaScript
function tubeace_dump_import_javascript() {
  //Set Your Nonce
  $ajax_nonce = wp_create_nonce( 'my-special-string' );
  ?>
  <script>

  jQuery( document ).ready( function( $ ) {

  	var line = 1;

  	process(line,0);

  	function process(line,num_added){

	    var data = {
	      action: 'tubeace_dump_import',
	      security: '<?php echo $ajax_nonce; ?>',

	      site: jQuery('#site').val(),

	      status: jQuery('#status').val(),
	      sponsor: jQuery('#sponsor').val(),
	      post_date: jQuery('#post_date').val(),
	      post_category: jQuery('#post_category').val(),

	      description: jQuery('#description').val(),
	      tags_set_all: jQuery('#tags_set_all').val(),
	      channels_as_tags: jQuery('#channels_as_tags').val(),
	      tags_method: jQuery('#tags_method').val(),
	      performers_set_all: jQuery('#performers_set_all').val(),
	      performers_method: jQuery('#performers_method').val(),
	      sponsor_link_txt: jQuery('#sponsor_link_txt').val(),
	      sponsor_link_url: jQuery('#sponsor_link_url').val(),
	      misc1: jQuery('#misc1').val(),
	      misc2: jQuery('#misc2').val(),
	      misc3: jQuery('#misc3').val(),
	      misc4: jQuery('#misc4').val(),
	      misc5: jQuery('#misc5').val(),

	      line: line,
	      num_added: num_added,
	    };

	    $.post( ajaxurl, data, function( response)  {

			jQuery('#response').append(response.report);

			if(response.done==1){
				jQuery('#tubeace-loading').remove();
				return;
				
			} else {

				//increment
				line = line+1;
				
				process(line, response.num_added);
			}
	    });
	}
  });

  </script>
  <?php
}
add_action( 'admin_footer', 'tubeace_dump_import_javascript' );	

$post_category = json_encode($post_category);

echo'
  <input type="hidden" id="site" value="'.$siteArray['site'].'">

  <input type="hidden" id="status" value="'.$status.'">
  <input type="hidden" id="sponsor" value="'.$sponsor.'">
  <input type="hidden" id="post_date" value="'.$post_date.'">
  <input type="hidden" id="post_category" value=\''.$post_category.'\'>

  <input type="hidden" id="description" value="'.$description.'">
  <input type="hidden" id="tags_set_all" value="'.$tags_set_all.'">
  <input type="hidden" id="channels_as_tags" value="'.$channels_as_tags.'">
  <input type="hidden" id="tags_method" value="'.$tags_method.'">
  <input type="hidden" id="performers_set_all" value="'.$performers_set_all.'">
  <input type="hidden" id="performers_method" value="'.$performers_method.'">
  <input type="hidden" id="sponsor_link_txt" value="'.$sponsor_link_txt.'">
  <input type="hidden" id="sponsor_link_url" value="'.$sponsor_link_url.'">
  <input type="hidden" id="misc1" value="'.$misc1.'">
  <input type="hidden" id="misc2" value="'.$misc2.'">
  <input type="hidden" id="misc3" value="'.$misc3.'">
  <input type="hidden" id="misc4" value="'.$misc4.'">
  <input type="hidden" id="misc5" value="'.$misc5.'">

  <div id="response"></div>
  <img id="tubeace-loading" src="'.plugins_url("tubeace/images/loading.gif").'">';

  ?>