<?php

tubeace_header(1);

if(!empty($_POST['Submit'])) {

	echo'<div class="updated"><p><b>Settings saved.</b></p></div>';

	// apis
	$tubeace_pornhub_api_thumb_size = tubeace_get_post_data('tubeace_pornhub_api_thumb_size');
	$tubeace_pornhub_api_def_thumb_only = tubeace_get_post_data('tubeace_pornhub_api_def_thumb_only');
	$tubeace_pornhub_api_use_def_thumb = tubeace_get_post_data('tubeace_pornhub_api_use_def_thumb');
	$tubeace_pornhub_api_num_thumbs = tubeace_get_post_data('tubeace_pornhub_api_num_thumbs');
	$tubeace_pornhub_api_def_thumb = tubeace_get_post_data('tubeace_pornhub_api_def_thumb');
	$tubeace_pornhub_api_save_thumbs = tubeace_get_post_data('tubeace_pornhub_api_save_thumbs');

	$tubeace_redtube_api_thumb_size = tubeace_get_post_data('tubeace_redtube_api_thumb_size');
	$tubeace_redtube_api_def_thumb_only = tubeace_get_post_data('tubeace_redtube_api_def_thumb_only');
	$tubeace_redtube_api_use_def_thumb = tubeace_get_post_data('tubeace_redtube_api_use_def_thumb');
	$tubeace_redtube_api_num_thumbs = tubeace_get_post_data('tubeace_redtube_api_num_thumbs');
	$tubeace_redtube_api_def_thumb = tubeace_get_post_data('tubeace_redtube_api_def_thumb');
	$tubeace_redtube_api_save_thumbs = tubeace_get_post_data('tubeace_redtube_api_save_thumbs');

	$tubeace_tube8_api_thumb_size = tubeace_get_post_data('tubeace_tube8_api_thumb_size');
	$tubeace_tube8_api_def_thumb_only = tubeace_get_post_data('tubeace_tube8_api_def_thumb_only');
	$tubeace_tube8_api_use_def_thumb = tubeace_get_post_data('tubeace_tube8_api_use_def_thumb');
	$tubeace_tube8_api_num_thumbs = tubeace_get_post_data('tubeace_tube8_api_num_thumbs');
	$tubeace_tube8_api_def_thumb = tubeace_get_post_data('tubeace_tube8_api_def_thumb');
	$tubeace_tube8_api_save_thumbs = tubeace_get_post_data('tubeace_tube8_api_save_thumbs');

	$tubeace_youporn_api_thumb_size = tubeace_get_post_data('tubeace_youporn_api_thumb_size');
	$tubeace_youporn_api_def_thumb_only = tubeace_get_post_data('tubeace_youporn_api_def_thumb_only');
	$tubeace_youporn_api_use_def_thumb = tubeace_get_post_data('tubeace_youporn_api_use_def_thumb');
	$tubeace_youporn_api_num_thumbs = tubeace_get_post_data('tubeace_youporn_api_num_thumbs');
	$tubeace_youporn_api_def_thumb = tubeace_get_post_data('tubeace_youporn_api_def_thumb');
	$tubeace_youporn_api_save_thumbs = tubeace_get_post_data('tubeace_youporn_api_save_thumbs');

	$tubeace_xhamster_api_thumb_size = tubeace_get_post_data('tubeace_xhamster_api_thumb_size');
	$tubeace_xhamster_api_def_thumb_only = tubeace_get_post_data('tubeace_xhamster_api_def_thumb_only');
	$tubeace_xhamster_api_use_def_thumb = tubeace_get_post_data('tubeace_xhamster_api_use_def_thumb');
	$tubeace_xhamster_api_num_thumbs = tubeace_get_post_data('tubeace_xhamster_api_num_thumbs');
	$tubeace_xhamster_api_def_thumb = tubeace_get_post_data('tubeace_xhamster_api_def_thumb');
	$tubeace_xhamster_api_save_thumbs = tubeace_get_post_data('tubeace_xhamster_api_save_thumbs');

	// dumps
	$tubeace_drtuber_dump_num_thumbs = stripslashes($_POST['tubeace_drtuber_dump_num_thumbs']);
	$tubeace_drtuber_dump_def_thumb = stripslashes($_POST['tubeace_drtuber_dump_def_thumb']);

	$tubeace_keezmovies_dump_num_thumbs = stripslashes($_POST['tubeace_keezmovies_dump_num_thumbs']);
	$tubeace_keezmovies_dump_def_thumb = stripslashes($_POST['tubeace_keezmovies_dump_def_thumb']);

	$tubeace_pornhub_dump_num_thumbs = stripslashes($_POST['tubeace_pornhub_dump_num_thumbs']);
	$tubeace_pornhub_dump_def_thumb = stripslashes($_POST['tubeace_pornhub_dump_def_thumb']);

	$tubeace_porntube_dump_num_thumbs = stripslashes($_POST['tubeace_porntube_dump_num_thumbs']);
	$tubeace_porntube_dump_def_thumb = stripslashes($_POST['tubeace_porntube_dump_def_thumb']);

	$tubeace_redtube_dump_num_thumbs = stripslashes($_POST['tubeace_redtube_dump_num_thumbs']);
	$tubeace_redtube_dump_def_thumb = stripslashes($_POST['tubeace_redtube_dump_def_thumb']);

	$tubeace_spankwire_dump_num_thumbs = stripslashes($_POST['tubeace_spankwire_dump_num_thumbs']);
	$tubeace_spankwire_dump_def_thumb = stripslashes($_POST['tubeace_spankwire_dump_def_thumb']);

	$tubeace_sunporno_dump_num_thumbs = stripslashes($_POST['tubeace_sunporno_dump_num_thumbs']);
	$tubeace_sunporno_dump_def_thumb = stripslashes($_POST['tubeace_sunporno_dump_def_thumb']);

	$tubeace_tube8_dump_num_thumbs = stripslashes($_POST['tubeace_tube8_dump_num_thumbs']);
	$tubeace_tube8_dump_def_thumb = stripslashes($_POST['tubeace_tube8_dump_def_thumb']);

	$tubeace_xhamster_dump_num_thumbs = stripslashes($_POST['tubeace_xhamster_dump_num_thumbs']);
	$tubeace_xhamster_dump_def_thumb = stripslashes($_POST['tubeace_xhamster_dump_def_thumb']);

	$tubeace_xtube_dump_num_thumbs = stripslashes($_POST['tubeace_xtube_dump_num_thumbs']);
	$tubeace_xtube_dump_def_thumb = stripslashes($_POST['tubeace_xtube_dump_def_thumb']);

	$tubeace_xvideos_dump_num_thumbs = stripslashes($_POST['tubeace_xvideos_dump_num_thumbs']);
	$tubeace_xvideos_dump_def_thumb = stripslashes($_POST['tubeace_xvideos_dump_def_thumb']);

	$tubeace_youporn_dump_num_thumbs = stripslashes($_POST['tubeace_youporn_dump_num_thumbs']);
	$tubeace_youporn_dump_def_thumb = stripslashes($_POST['tubeace_youporn_dump_def_thumb']);	

	
	$tubeace_mass_import_save_thumbs = tubeace_get_post_data('tubeace_mass_import_save_thumbs');

	$tubeace_import_as_video_post_format = tubeace_get_post_data('tubeace_import_as_video_post_format');
	$tubeace_ajax_import = tubeace_get_post_data('tubeace_ajax_import');
	$tubeace_words_filter = tubeace_get_post_data('tubeace_words_filter');
	$tubeace_filter_video_position = tubeace_get_post_data('tubeace_filter_video_position');
	$tubeace_flowplayer7_code = tubeace_get_post_data('tubeace_flowplayer7_code');
	$tubeace_videojs_code = tubeace_get_post_data('tubeace_videojs_code');
	$tubeace_default_video_player = tubeace_get_post_data('tubeace_default_video_player');
	$tubeace_video_player_wrapper_css = tubeace_get_post_data('tubeace_video_player_wrapper_css');
	$tubeace_redtube_video_player_code = tubeace_get_post_data('tubeace_redtube_video_player_code');
	$tubeace_drtuber_video_player_code = tubeace_get_post_data('tubeace_drtuber_video_player_code');
	$tubeace_keezmovies_video_player_code = tubeace_get_post_data('tubeace_keezmovies_video_player_code');
	$tubeace_porntube_video_player_code = tubeace_get_post_data('tubeace_porntube_video_player_code');
	$tubeace_pornhub_video_player_code = tubeace_get_post_data('tubeace_pornhub_video_player_code');
	$tubeace_spankwire_video_player_code = tubeace_get_post_data('tubeace_spankwire_video_player_code');
	$tubeace_sunporno_video_player_code = tubeace_get_post_data('tubeace_sunporno_video_player_code');
	$tubeace_tube8_video_player_code = tubeace_get_post_data('tubeace_tube8_video_player_code');
	$tubeace_xhamster_video_player_code = tubeace_get_post_data('tubeace_xhamster_video_player_code');
	$tubeace_xvideos_video_player_code = tubeace_get_post_data('tubeace_xvideos_video_player_code');
	$tubeace_xtube_video_player_code = tubeace_get_post_data('tubeace_xtube_video_player_code');
	$tubeace_youporn_video_player_code = tubeace_get_post_data('tubeace_youporn_video_player_code');
	$tubeace_thumb_width = tubeace_get_post_data('tubeace_thumb_width');
	$tubeace_thumb_height = tubeace_get_post_data('tubeace_thumb_height');
	$tubeace_schedule_per_day = tubeace_get_post_data('tubeace_schedule_per_day');
	$tubeace_split_description_characters = tubeace_get_post_data('tubeace_split_description_characters');
	$tubeace_cron_set_last_page_as_start = tubeace_get_post_data('tubeace_cron_set_last_page_as_start');
	$tubeace_cron_email = tubeace_get_post_data('tubeace_cron_email');
	$tubeace_link_thumb_to_source = tubeace_get_post_data('tubeace_link_thumb_to_source');
	$tubeace_alternate_video_url = tubeace_get_post_data('tubeace_alternate_video_url');


	// APIs
	update_site_option('tubeace_pornhub_api_thumb_size', $tubeace_pornhub_api_thumb_size);
	update_site_option('tubeace_pornhub_api_def_thumb_only', $tubeace_pornhub_api_def_thumb_only);
	update_site_option('tubeace_pornhub_api_use_def_thumb', $tubeace_pornhub_api_use_def_thumb);
	if( isset( $_POST['tubeace_pornhub_api_num_thumbs'] ) ){ // keep value if input disabled
		update_site_option('tubeace_pornhub_api_num_thumbs', $tubeace_pornhub_api_num_thumbs);		
	}
	if( isset( $_POST['tubeace_pornhub_api_def_thumb'] ) ){ // keep value if input disabled
		update_site_option('tubeace_pornhub_api_def_thumb', $tubeace_pornhub_api_def_thumb);
	}
	update_site_option('tubeace_pornhub_api_save_thumbs', $tubeace_pornhub_api_save_thumbs);

	update_site_option('tubeace_redtube_api_thumb_size', $tubeace_redtube_api_thumb_size);
	update_site_option('tubeace_redtube_api_def_thumb_only', $tubeace_redtube_api_def_thumb_only);
	update_site_option('tubeace_redtube_api_use_def_thumb', $tubeace_redtube_api_use_def_thumb);
	if( isset( $_POST['tubeace_redtube_api_num_thumbs'] ) ){ // keep value if input disabled
		update_site_option('tubeace_redtube_api_num_thumbs', $tubeace_redtube_api_num_thumbs);		
	}
	if( isset( $_POST['tubeace_redtube_api_def_thumb'] ) ){ // keep value if input disabled
		update_site_option('tubeace_redtube_api_def_thumb', $tubeace_redtube_api_def_thumb);
	}
	update_site_option('tubeace_redtube_api_save_thumbs', $tubeace_redtube_api_save_thumbs);

	update_site_option('tubeace_tube8_api_thumb_size', $tubeace_tube8_api_thumb_size);
	update_site_option('tubeace_tube8_api_def_thumb_only', $tubeace_tube8_api_def_thumb_only);
	update_site_option('tubeace_tube8_api_use_def_thumb', $tubeace_tube8_api_use_def_thumb);
	if( isset( $_POST['tubeace_tube8_api_num_thumbs'] ) ){ // keep value if input disabled
		update_site_option('tubeace_tube8_api_num_thumbs', $tubeace_tube8_api_num_thumbs);		
	}
	if( isset( $_POST['tubeace_tube8_api_def_thumb'] ) ){ // keep value if input disabled
		update_site_option('tubeace_tube8_api_def_thumb', $tubeace_tube8_api_def_thumb);
	}
	update_site_option('tubeace_tube8_api_save_thumbs', $tubeace_tube8_api_save_thumbs);


	update_site_option('tubeace_youporn_api_thumb_size', $tubeace_youporn_api_thumb_size);
	update_site_option('tubeace_youporn_api_def_thumb_only', $tubeace_youporn_api_def_thumb_only);
	update_site_option('tubeace_youporn_api_use_def_thumb', $tubeace_youporn_api_use_def_thumb);
	if( isset( $_POST['tubeace_youporn_api_num_thumbs'] ) ){ // keep value if input disabled
		update_site_option('tubeace_youporn_api_num_thumbs', $tubeace_youporn_api_num_thumbs);		
	}
	if( isset( $_POST['tubeace_youporn_api_def_thumb'] ) ){ // keep value if input disabled
		update_site_option('tubeace_youporn_api_def_thumb', $tubeace_youporn_api_def_thumb);
	}
	update_site_option('tubeace_youporn_api_save_thumbs', $tubeace_youporn_api_save_thumbs);

	update_site_option('tubeace_xhamster_api_thumb_size', $tubeace_xhamster_api_thumb_size);
	update_site_option('tubeace_xhamster_api_def_thumb_only', $tubeace_xhamster_api_def_thumb_only);
	update_site_option('tubeace_xhamster_api_use_def_thumb', $tubeace_xhamster_api_use_def_thumb);
	if( isset( $_POST['tubeace_xhamster_api_num_thumbs'] ) ){ // keep value if input disabled
		update_site_option('tubeace_xhamster_api_num_thumbs', $tubeace_xhamster_api_num_thumbs);		
	}
	if( isset( $_POST['tubeace_xhamster_api_def_thumb'] ) ){ // keep value if input disabled
		update_site_option('tubeace_xhamster_api_def_thumb', $tubeace_xhamster_api_def_thumb);
	}
	update_site_option('tubeace_xhamster_api_save_thumbs', $tubeace_xhamster_api_save_thumbs);

	// dump files
	update_site_option('tubeace_drtuber_dump_num_thumbs', $tubeace_drtuber_dump_num_thumbs);
	update_site_option('tubeace_drtuber_dump_def_thumb', $tubeace_drtuber_dump_def_thumb);

	update_site_option('tubeace_keezmovies_dump_num_thumbs', $tubeace_keezmovies_dump_num_thumbs);
	update_site_option('tubeace_keezmovies_dump_def_thumb', $tubeace_keezmovies_dump_def_thumb);

	update_site_option('tubeace_pornhub_dump_num_thumbs', $tubeace_pornhub_dump_num_thumbs);
	update_site_option('tubeace_pornhub_dump_def_thumb', $tubeace_pornhub_dump_def_thumb);

	update_site_option('tubeace_porntube_dump_num_thumbs', $tubeace_porntube_dump_num_thumbs);
	update_site_option('tubeace_porntube_dump_def_thumb', $tubeace_porntube_dump_def_thumb);

	update_site_option('tubeace_redtube_dump_num_thumbs', $tubeace_redtube_dump_num_thumbs);
	update_site_option('tubeace_redtube_dump_def_thumb', $tubeace_redtube_dump_def_thumb);	

	update_site_option('tubeace_spankwire_dump_num_thumbs', $tubeace_spankwire_dump_num_thumbs);
	update_site_option('tubeace_spankwire_dump_def_thumb', $tubeace_spankwire_dump_def_thumb);

	update_site_option('tubeace_sunporno_dump_num_thumbs', $tubeace_sunporno_dump_num_thumbs);
	update_site_option('tubeace_sunporno_dump_def_thumb', $tubeace_sunporno_dump_def_thumb);

	update_site_option('tubeace_tube8_dump_num_thumbs', $tubeace_tube8_dump_num_thumbs);
	update_site_option('tubeace_tube8_dump_def_thumb', $tubeace_tube8_dump_def_thumb);	

	update_site_option('tubeace_xhamster_dump_num_thumbs', $tubeace_xhamster_dump_num_thumbs);
	update_site_option('tubeace_xhamster_dump_def_thumb', $tubeace_xhamster_dump_def_thumb);

	update_site_option('tubeace_xtube_dump_num_thumbs', $tubeace_xtube_dump_num_thumbs);
	update_site_option('tubeace_xtube_dump_def_thumb', $tubeace_xtube_dump_def_thumb);

	update_site_option('tubeace_xvideos_dump_num_thumbs', $tubeace_xvideos_dump_num_thumbs);
	update_site_option('tubeace_xvideos_dump_def_thumb', $tubeace_xvideos_dump_def_thumb);

	update_site_option('tubeace_youporn_dump_num_thumbs', $tubeace_youporn_dump_num_thumbs);
	update_site_option('tubeace_youporn_dump_def_thumb', $tubeace_youporn_dump_def_thumb);	


	update_site_option('tubeace_mass_import_save_thumbs', $tubeace_mass_import_save_thumbs);		

	update_site_option('tubeace_import_as_video_post_format', $tubeace_import_as_video_post_format);
	update_site_option('tubeace_ajax_import', $tubeace_ajax_import);
	update_site_option('tubeace_words_filter', $tubeace_words_filter);
	update_site_option('tubeace_filter_video_position', $tubeace_filter_video_position);
	update_site_option('tubeace_flowplayer7_code', $tubeace_flowplayer7_code);
	update_site_option('tubeace_videojs_code', $tubeace_videojs_code);
	update_site_option('tubeace_default_video_player', $tubeace_default_video_player);
	update_site_option('tubeace_video_player_wrapper_css', $tubeace_video_player_wrapper_css);
	update_site_option('tubeace_redtube_video_player_code', $tubeace_redtube_video_player_code);
	update_site_option('tubeace_drtuber_video_player_code', $tubeace_drtuber_video_player_code);
	update_site_option('tubeace_keezmovies_video_player_code', $tubeace_keezmovies_video_player_code);
	update_site_option('tubeace_porntube_video_player_code', $tubeace_porntube_video_player_code);
	update_site_option('tubeace_pornhub_video_player_code', $tubeace_pornhub_video_player_code);
	update_site_option('tubeace_spankwire_video_player_code', $tubeace_spankwire_video_player_code);
	update_site_option('tubeace_sunporno_video_player_code', $tubeace_sunporno_video_player_code);
	update_site_option('tubeace_tube8_video_player_code', $tubeace_tube8_video_player_code);
	update_site_option('tubeace_xhamster_video_player_code', $tubeace_xhamster_video_player_code);
	update_site_option('tubeace_xtube_video_player_code', $tubeace_xtube_video_player_code);
	update_site_option('tubeace_xvideos_video_player_code', $tubeace_xvideos_video_player_code);
	update_site_option('tubeace_youporn_video_player_code', $tubeace_youporn_video_player_code);
	update_site_option('tubeace_thumb_width', $tubeace_thumb_width);
	update_site_option('tubeace_thumb_height', $tubeace_thumb_height);
	update_site_option('tubeace_schedule_per_day', $tubeace_schedule_per_day);
	update_site_option('tubeace_split_description_characters', $tubeace_split_description_characters);
	update_site_option('tubeace_cron_set_last_page_as_start', $tubeace_cron_set_last_page_as_start);
	update_site_option('tubeace_cron_email', $tubeace_cron_email);
	update_site_option('tubeace_link_thumb_to_source', $tubeace_link_thumb_to_source);
	update_site_option('tubeace_alternate_video_url', $tubeace_alternate_video_url);
}

?>

<style type="text/css">
	
	.tubeace-customizations-group{background-color:#fafafa;}
	.tubeace-customizations-description{width:100%;float:left;background-color: inherit;color:#666;padding:8px;}
	.tubeace-customizations-button{width:100%;float:left;margin-bottom:30px;background-color: inherit;padding:8px;}

</style>

<?php
if( isset( $_POST['ResetCustomizations'] )) {

	foreach ($tubeace_defaults as $key => $value) {
		remove_theme_mod( $key );
	}


?>
<div class="notice notice-success is-dismissible"> 
  <p><strong><?php _e('Plugin Shortcode Customizations Reset','tubeace'); ?></strong></p>
  <button type="button" class="notice-dismiss">
    <span class="screen-reader-text"><?php _e('Dismiss this notice.','tubeace'); ?></span>
  </button>
</div>
<br />
<?php
}
?>
<div class="wrap">

	<?php //screen_icon(); ?>
	<h2>Tube Ace Settings <span style="float:right"><small><small><span class="dashicons dashicons-paperclip"></span><a href="https://tubeace.com/docs/settings/" target="_blank">Documentation</a></small></small></span></h2>

	<?php

	$tubeace_pornhub_api_thumb_size = get_site_option( 'tubeace_pornhub_api_thumb_size' );
	$tubeace_pornhub_api_def_thumb_only = get_site_option( 'tubeace_pornhub_api_def_thumb_only' );
	$tubeace_pornhub_api_use_def_thumb = get_site_option( 'tubeace_pornhub_api_use_def_thumb' );
	$tubeace_pornhub_api_num_thumbs = get_site_option( 'tubeace_pornhub_api_num_thumbs' );
	$tubeace_pornhub_api_def_thumb = get_site_option( 'tubeace_pornhub_api_def_thumb' );
	$tubeace_pornhub_api_save_thumbs = get_site_option( 'tubeace_pornhub_api_save_thumbs' );

	$tubeace_redtube_api_thumb_size = get_site_option( 'tubeace_redtube_api_thumb_size' );
	$tubeace_redtube_api_def_thumb_only = get_site_option( 'tubeace_redtube_api_def_thumb_only' );
	$tubeace_redtube_api_use_def_thumb = get_site_option( 'tubeace_redtube_api_use_def_thumb' );
	$tubeace_redtube_api_num_thumbs = get_site_option( 'tubeace_redtube_api_num_thumbs' );
	$tubeace_redtube_api_def_thumb = get_site_option( 'tubeace_redtube_api_def_thumb' );
	$tubeace_redtube_api_save_thumbs = get_site_option( 'tubeace_redtube_api_save_thumbs' );

	$tubeace_tube8_api_thumb_size = get_site_option( 'tubeace_tube8_api_thumb_size' );
	$tubeace_tube8_api_def_thumb_only = get_site_option( 'tubeace_tube8_api_def_thumb_only' );
	$tubeace_tube8_api_use_def_thumb = get_site_option( 'tubeace_tube8_api_use_def_thumb' );
	$tubeace_tube8_api_num_thumbs = get_site_option( 'tubeace_tube8_api_num_thumbs' );
	$tubeace_tube8_api_def_thumb = get_site_option( 'tubeace_tube8_api_def_thumb' );
	$tubeace_tube8_api_save_thumbs = get_site_option( 'tubeace_tube8_api_save_thumbs' );

	$tubeace_youporn_api_thumb_size = get_site_option( 'tubeace_youporn_api_thumb_size' );
	$tubeace_youporn_api_def_thumb_only = get_site_option( 'tubeace_youporn_api_def_thumb_only' );
	$tubeace_youporn_api_use_def_thumb = get_site_option( 'tubeace_youporn_api_use_def_thumb' );
	$tubeace_youporn_api_num_thumbs = get_site_option( 'tubeace_youporn_api_num_thumbs' );
	$tubeace_youporn_api_def_thumb = get_site_option( 'tubeace_youporn_api_def_thumb' );
	$tubeace_youporn_api_save_thumbs = get_site_option( 'tubeace_youporn_api_save_thumbs' );

	$tubeace_xhamster_api_thumb_size = get_site_option( 'tubeace_xhamster_api_thumb_size' );
	$tubeace_xhamster_api_def_thumb_only = get_site_option( 'tubeace_xhamster_api_def_thumb_only' );
	$tubeace_xhamster_api_use_def_thumb = get_site_option( 'tubeace_xhamster_api_use_def_thumb' );
	$tubeace_xhamster_api_num_thumbs = get_site_option( 'tubeace_xhamster_api_num_thumbs' );
	$tubeace_xhamster_api_def_thumb = get_site_option( 'tubeace_xhamster_api_def_thumb' );
	$tubeace_xhamster_api_save_thumbs = get_site_option( 'tubeace_xhamster_api_save_thumbs' );

	$tubeace_drtuber_dump_num_thumbs = get_site_option( 'tubeace_drtuber_dump_num_thumbs' );
	$tubeace_drtuber_dump_def_thumb = get_site_option( 'tubeace_drtuber_dump_def_thumb' );

	$tubeace_keezmovies_dump_num_thumbs = get_site_option( 'tubeace_keezmovies_dump_num_thumbs' );
	$tubeace_keezmovies_dump_def_thumb = get_site_option( 'tubeace_keezmovies_dump_def_thumb' );

	$tubeace_pornhub_dump_num_thumbs = get_site_option( 'tubeace_pornhub_dump_num_thumbs' );
	$tubeace_pornhub_dump_def_thumb = get_site_option( 'tubeace_pornhub_dump_def_thumb' );

	$tubeace_porntube_dump_num_thumbs = get_site_option( 'tubeace_porntube_dump_num_thumbs' );
	$tubeace_porntube_dump_def_thumb = get_site_option( 'tubeace_porntube_dump_def_thumb' );

	$tubeace_redtube_dump_num_thumbs = get_site_option( 'tubeace_redtube_dump_num_thumbs' );
	$tubeace_redtube_dump_def_thumb = get_site_option( 'tubeace_redtube_dump_def_thumb' );

	$tubeace_spankwire_dump_num_thumbs = get_site_option( 'tubeace_spankwire_dump_num_thumbs' );
	$tubeace_spankwire_dump_def_thumb = get_site_option( 'tubeace_spankwire_dump_def_thumb' );

	$tubeace_sunporno_dump_num_thumbs = get_site_option( 'tubeace_sunporno_dump_num_thumbs' );
	$tubeace_sunporno_dump_def_thumb = get_site_option( 'tubeace_sunporno_dump_def_thumb' );

	$tubeace_tube8_dump_num_thumbs = get_site_option( 'tubeace_tube8_dump_num_thumbs' );
	$tubeace_tube8_dump_def_thumb = get_site_option( 'tubeace_tube8_dump_def_thumb' );

	$tubeace_xhamster_dump_num_thumbs = get_site_option( 'tubeace_xhamster_dump_num_thumbs' );
	$tubeace_xhamster_dump_def_thumb = get_site_option( 'tubeace_xhamster_dump_def_thumb' );

	$tubeace_xtube_dump_num_thumbs = get_site_option( 'tubeace_xtube_dump_num_thumbs' );
	$tubeace_xtube_dump_def_thumb = get_site_option( 'tubeace_xtube_dump_def_thumb' );

	$tubeace_xvideos_dump_num_thumbs = get_site_option( 'tubeace_xvideos_dump_num_thumbs' );
	$tubeace_xvideos_dump_def_thumb = get_site_option( 'tubeace_xvideos_dump_def_thumb' );

	$tubeace_youporn_dump_num_thumbs = get_site_option( 'tubeace_youporn_dump_num_thumbs' );
	$tubeace_youporn_dump_def_thumb = get_site_option( 'tubeace_youporn_dump_def_thumb' );

	$tubeace_mass_import_save_thumbs = get_site_option( 'tubeace_mass_import_save_thumbs' );

	$tubeace_import_as_video_post_format = get_site_option( 'tubeace_import_as_video_post_format' );
	$tubeace_ajax_import = get_site_option( 'tubeace_ajax_import' );
	$tubeace_words_filter = get_site_option( 'tubeace_words_filter' );
	$tubeace_filter_video_position = get_site_option( 'tubeace_filter_video_position' );
	$tubeace_flowplayer7_code = get_site_option( 'tubeace_flowplayer7_code' );
	$tubeace_videojs_code = get_site_option( 'tubeace_videojs_code' );
	$tubeace_default_video_player = get_site_option( 'tubeace_default_video_player' );
	$tubeace_video_player_wrapper_css = get_site_option( 'tubeace_video_player_wrapper_css' );
	$tubeace_redtube_video_player_code = get_site_option( 'tubeace_redtube_video_player_code' );
	$tubeace_drtuber_video_player_code = get_site_option( 'tubeace_drtuber_video_player_code' );
	$tubeace_keezmovies_video_player_code = get_site_option( 'tubeace_keezmovies_video_player_code' );
	$tubeace_porntube_video_player_code = get_site_option( 'tubeace_porntube_video_player_code' );
	$tubeace_pornhub_video_player_code = get_site_option( 'tubeace_pornhub_video_player_code' );
	$tubeace_spankwire_video_player_code = get_site_option( 'tubeace_spankwire_video_player_code' );
	$tubeace_sunporno_video_player_code = get_site_option( 'tubeace_sunporno_video_player_code' );
	$tubeace_tube8_video_player_code = get_site_option( 'tubeace_tube8_video_player_code' );
	$tubeace_xhamster_video_player_code = get_site_option( 'tubeace_xhamster_video_player_code' );
	$tubeace_xtube_video_player_code = get_site_option( 'tubeace_xtube_video_player_code' );
	$tubeace_xvideos_video_player_code = get_site_option( 'tubeace_xvideos_video_player_code' );
	$tubeace_youporn_video_player_code = get_site_option( 'tubeace_youporn_video_player_code' );
	$tubeace_thumb_width = get_site_option( 'tubeace_thumb_width' );
	$tubeace_thumb_height = get_site_option( 'tubeace_thumb_height' );
	$tubeace_schedule_per_day = get_site_option( 'tubeace_schedule_per_day' );
	$tubeace_split_description_characters = get_site_option( 'tubeace_split_description_characters' );
	$tubeace_cron_set_last_page_as_start = get_site_option( 'tubeace_cron_set_last_page_as_start' );
	$tubeace_cron_email = get_site_option( 'tubeace_cron_email' );
	$tubeace_link_thumb_to_source = get_site_option( 'tubeace_link_thumb_to_source' );
	$tubeace_alternate_video_url = get_site_option( 'tubeace_alternate_video_url' );
	?>


	<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-settings.php'); ?>" method="post">

		<h2>API Imports</h2>
		<table class="form-table">
		    <tbody>
		    	<tr>
		    		<td>
		    			
		    		</td>			    		
		    		<td>
		    			Thumbnail Source Size
		    		</td>
		    		<td>
		    			Display Default Thumbnail Only <br><small>(No Rotating Thumbnails)</small>
		    		</td>
		    		<td>
		    			Use Preselected Default Thumbnail <br><small>(With Rotating Thumbnails)</small>
		    		</td>		    		
		    		<td>
		    			# of Thumbnails to Display
		    		</td>
		    		<td>
		    			Default Thumbnail # to Display in Previews
		    		</td>
		    		<td>
		    			Save Thumbnails to Server <br><small>(Leaving Unchecked will Serve Thumbnails from Source/CDN)</small>
		    		</td>			    					    		
		    	</tr>

		        <tr>
		    		<th><label>Pornhub</label></th>
		        	<td>
		        		<select name="tubeace_pornhub_api_thumb_size">
		        			<?php $sel_small = ( $tubeace_pornhub_api_thumb_size == 'small' ) ? 'selected="selected"' : ''; ?>
		        			<option value="small" <?php echo $sel_small ?>>small 180x135</option>

		        			<?php $sel_medium = ( $tubeace_pornhub_api_thumb_size == 'medium' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium" <?php echo $sel_medium ?>>medium 240x180</option>

		        			<?php $sel_large = ( $tubeace_pornhub_api_thumb_size == 'large' ) ? 'selected="selected"' : ''; ?>
		        			<option value="large" <?php echo $sel_large ?>>large 320x240</option>

		        			<?php $sel_small_hd = ( $tubeace_pornhub_api_thumb_size == 'small_hd' ) ? 'selected="selected"' : ''; ?>
		        			<option value="small_hd" <?php echo $sel_small_hd ?>>small_hd 180x101</option>

		        			<?php $sel_medium_hd = ( $tubeace_pornhub_api_thumb_size == 'medium_hd' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium_hd" <?php echo $sel_medium_hd ?>>medium_hd 240x135</option>

		        			<?php $sel_large_hd = ( $tubeace_pornhub_api_thumb_size == 'large_hd' ) ? 'selected="selected"' : ''; ?>
		        			<option value="large_hd" <?php echo $sel_large_hd ?>>large_hd 320x180</option>
		        		</select>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_pornhub_api_def_thumb_only_disabled = null;
		        		if( $tubeace_pornhub_api_use_def_thumb == 1 ){
							$tubeace_pornhub_api_def_thumb_only_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_pornhub_api_def_thumb_only" id="tubeace_pornhub_api_def_thumb_only" value="1" <?php if( $tubeace_pornhub_api_def_thumb_only == 1 ) echo 'checked'; ?> <?php echo $tubeace_pornhub_api_def_thumb_only_disabled; ?>>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_pornhub_api_use_def_thumb_disabled = null;
		        		if( $tubeace_pornhub_api_def_thumb_only == 1 ){
							$tubeace_pornhub_api_use_def_thumb_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_pornhub_api_use_def_thumb" id="tubeace_pornhub_api_use_def_thumb" value="1" <?php if( $tubeace_pornhub_api_use_def_thumb == 1 ) echo 'checked'; ?> <?php echo $tubeace_pornhub_api_use_def_thumb_disabled; ?>>
		        	</td>				        	   		    		
		        	<td>
		        		<?php 
		        		$tubeace_pornhub_api_num_thumbs_disabled = null;
		        		if( $tubeace_pornhub_api_def_thumb_only == 1 ){
							$tubeace_pornhub_api_num_thumbs_disabled = "disabled";
		        		} ?>
		        		<input type="number" name="tubeace_pornhub_api_num_thumbs" id="tubeace_pornhub_api_num_thumbs" min="1" max="16" value="<?php echo $tubeace_pornhub_api_num_thumbs; ?>" <?php echo $tubeace_pornhub_api_num_thumbs_disabled; ?>> <small>max 16</small>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_pornhub_api_def_thumb_disabled = null;
		        		if( $tubeace_pornhub_api_def_thumb_only == 1 || $tubeace_pornhub_api_use_def_thumb == 1){
							$tubeace_pornhub_api_def_thumb_disabled = "disabled";
		        		} ?>		        		
		        		<input type="number" name="tubeace_pornhub_api_def_thumb" id="tubeace_pornhub_api_def_thumb" min="1" max="16" value="<?php echo $tubeace_pornhub_api_def_thumb; ?>" <?php echo $tubeace_pornhub_api_def_thumb_disabled; ?>>
		        	</td>
		        	<td>
		        		<input type="checkbox" name="tubeace_pornhub_api_save_thumbs" value="1" <?php if( $tubeace_pornhub_api_save_thumbs == 1 ) echo 'checked'; ?>>
		        	</td>	        			        	  	
		        </tr>






		        <tr>
		    		<th><label>RedTube</label></th>
		        	<td>
		        		<select name="tubeace_redtube_api_thumb_size">
		        			<?php $sel_small = ( $tubeace_redtube_api_thumb_size == 'small' ) ? 'selected="selected"' : ''; ?>
		        			<option value="small" <?php echo $sel_small ?>>small 120x90</option>
		        			<?php $sel_medium = ( $tubeace_redtube_api_thumb_size =='medium' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium" <?php echo $sel_medium ?>>medium 180x135</option>
		        			<?php $sel_medium1 = ( $tubeace_redtube_api_thumb_size =='medium1' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium1" <?php echo $sel_medium1 ?>>medium1 240x180</option>
		        			<?php $sel_medium2 = ( $tubeace_redtube_api_thumb_size =='medium2' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium2" <?php echo $sel_medium2 ?>>medium2 320x240</option>
		        			<?php $sel_big = ( $tubeace_redtube_api_thumb_size =='big' ) ? 'selected="selected"' : ''; ?>
		        			<option value="big" <?php echo $sel_big ?>>big 432x324</option>		        			
		        		</select>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_redtube_api_def_thumb_only_disabled = null;
		        		if( $tubeace_redtube_api_use_def_thumb == 1 ){
							$tubeace_redtube_api_def_thumb_only_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_redtube_api_def_thumb_only" id="tubeace_redtube_api_def_thumb_only" value="1" <?php if( $tubeace_redtube_api_def_thumb_only == 1 ) echo 'checked'; ?> <?php echo $tubeace_redtube_api_def_thumb_only_disabled; ?>>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_redtube_api_use_def_thumb_disabled = null;
		        		if( $tubeace_redtube_api_def_thumb_only == 1 ){
							$tubeace_redtube_api_use_def_thumb_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_redtube_api_use_def_thumb" id="tubeace_redtube_api_use_def_thumb" value="1" <?php if( $tubeace_redtube_api_use_def_thumb == 1 ) echo 'checked'; ?> <?php echo $tubeace_redtube_api_use_def_thumb_disabled; ?>>
		        	</td>		        	 	
		        	<td>
		        		<?php 
		        		$tubeace_redtube_api_num_thumbs_disabled = null;
		        		if( $tubeace_redtube_api_def_thumb_only == 1 ){
							$tubeace_redtube_api_num_thumbs_disabled = "disabled";
		        		} ?>		        		
		        		<input type="number" name="tubeace_redtube_api_num_thumbs" id="tubeace_redtube_api_num_thumbs" min="1" max="16" value="<?php echo $tubeace_redtube_api_num_thumbs; ?>" <?php echo $tubeace_redtube_api_num_thumbs_disabled; ?>> <small>max 16</small>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_redtube_api_def_thumb_disabled = null;
		        		if( $tubeace_redtube_api_def_thumb_only == 1 || $tubeace_redtube_api_use_def_thumb == 1){
							$tubeace_redtube_api_def_thumb_disabled = "disabled";
		        		} ?>			        		
		        		<input type="number" name="tubeace_redtube_api_def_thumb" id="tubeace_redtube_api_def_thumb" min="1" max="16" value="<?php echo $tubeace_redtube_api_def_thumb; ?>" <?php echo $tubeace_redtube_api_def_thumb_disabled; ?>>
		        	</td>

		        	<td>
		        		<input type="checkbox" name="tubeace_redtube_api_save_thumbs" value="1" <?php if( $tubeace_redtube_api_save_thumbs == 1 ) echo 'checked'; ?>>
		        	</td>			        		        	
		        </tr>



		        <tr>
		    		<th><label>Tube8</label></th>
		        	<td>
		        		<select name="tubeace_tube8_api_thumb_size">
		        			<?php $sel_tube8_small = ( $tubeace_tube8_api_thumb_size == 'small' ) ? 'selected="selected"' : ''; ?>
		        			<option value="small" <?php echo $sel_tube8_small ?>>small 160x120</option>

		        			<?php $sel_tube8_big = ( $tubeace_tube8_api_thumb_size == 'big' ) ? 'selected="selected"' : ''; ?>
		        			<option value="big" <?php echo $sel_tube8_big ?>>big 240x180</option>
		        		</select>
		        	</td>

		        	<td>
		        		<?php 
		        		$tubeace_tube8_api_def_thumb_only_disabled = null;
		        		if( $tubeace_tube8_api_use_def_thumb == 1 ){
							$tubeace_tube8_api_def_thumb_only_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_tube8_api_def_thumb_only" id="tubeace_tube8_api_def_thumb_only" value="1" <?php if( $tubeace_tube8_api_def_thumb_only == 1 ) echo 'checked'; ?> <?php echo $tubeace_tube8_api_def_thumb_only_disabled; ?>>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_tube8_api_use_def_thumb_disabled = null;
		        		if( $tubeace_tube8_api_def_thumb_only == 1 ){
							$tubeace_tube8_api_use_def_thumb_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_tube8_api_use_def_thumb" id="tubeace_tube8_api_use_def_thumb" value="1" <?php if( $tubeace_tube8_api_use_def_thumb == 1 ) echo 'checked'; ?> <?php echo $tubeace_tube8_api_use_def_thumb_disabled; ?>>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_tube8_api_num_thumbs_disabled = null;
		        		if( $tubeace_tube8_api_def_thumb_only == 1 ){
							$tubeace_tube8_api_num_thumbs_disabled = "disabled";
		        		} ?>			        		
		        		<input type="number" name="tubeace_tube8_api_num_thumbs" id="tubeace_tube8_api_num_thumbs" min="1" max="16" value="<?php echo $tubeace_tube8_api_num_thumbs; ?>" <?php echo $tubeace_tube8_api_num_thumbs_disabled; ?>> <small>max 16</small>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_tube8_api_def_thumb_disabled = null;
		        		if( $tubeace_tube8_api_def_thumb_only == 1 || $tubeace_tube8_api_use_def_thumb == 1){
							$tubeace_tube8_api_def_thumb_disabled = "disabled";
		        		} ?>				        		
		        		<input type="number" name="tubeace_tube8_api_def_thumb" id="tubeace_tube8_api_def_thumb" min="1" max="16" value="<?php echo $tubeace_tube8_api_def_thumb; ?>" <?php echo $tubeace_tube8_api_def_thumb_disabled; ?>>
		        	</td>

		        	<td>
		        		<input type="checkbox" name="tubeace_tube8_api_save_thumbs" value="1" <?php if( $tubeace_tube8_api_save_thumbs == 1 ) echo 'checked'; ?>>
		        	</td> 	

		        </tr>


		        <tr>
		    		<th><label>YouPorn</label></th>
		        	<td>
		        		<select name="tubeace_youporn_api_thumb_size">
		        			<?php $sel_youporn_small = ( $tubeace_youporn_api_thumb_size == 'small' ) ? 'selected="selected"' : ''; ?>
		        			<option value="small" <?php echo $sel_youporn_small ?>>small 120x90</option>
		        			<?php $sel_youporn_medium = ( $tubeace_youporn_api_thumb_size == 'medium' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium" <?php echo $sel_youporn_medium ?>>medium 227x128</option>
		        			<?php $sel_youporn_medium1 = ( $tubeace_youporn_api_thumb_size == 'medium1' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium1" <?php echo $sel_youporn_medium1 ?>>medium1 240x180</option>
		        			<?php $sel_youporn_medium2 = ( $tubeace_youporn_api_thumb_size == 'medium2' ) ? 'selected="selected"' : ''; ?>
		        			<option value="medium2" <?php echo $sel_youporn_medium2 ?>>medium2 320x240</option>
		        			<?php $sel_youporn_big = ( $tubeace_youporn_api_thumb_size == 'big' ) ? 'selected="selected"' : ''; ?>
		        			<option value="big" <?php echo $sel_youporn_big ?>>big 640x480</option>	
		        		</select>
		        	</td>  
		        	<td>
		        		<?php 
		        		$tubeace_youporn_api_def_thumb_only_disabled = null;
		        		if( $tubeace_youporn_api_use_def_thumb == 1 ){
							$tubeace_youporn_api_def_thumb_only_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_youporn_api_def_thumb_only" id="tubeace_youporn_api_def_thumb_only" value="1" <?php if( $tubeace_youporn_api_def_thumb_only == 1 ) echo 'checked'; ?> <?php echo $tubeace_youporn_api_def_thumb_only_disabled; ?>>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_youporn_api_use_def_thumb_disabled = null;
		        		if( $tubeace_youporn_api_def_thumb_only == 1 ){
							$tubeace_youporn_api_use_def_thumb_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_youporn_api_use_def_thumb" id="tubeace_youporn_api_use_def_thumb" value="1" <?php if( $tubeace_youporn_api_use_def_thumb == 1 ) echo 'checked'; ?> <?php echo $tubeace_youporn_api_use_def_thumb_disabled; ?>>
		        	</td>		        	
		        	<td>
		        		<?php 
		        		$tubeace_youporn_api_num_thumbs_disabled = null;
		        		if( $tubeace_youporn_api_def_thumb_only == 1){
							$tubeace_youporn_api_num_thumbs_disabled = "disabled";
		        		} ?>			        		
		        		<input type="number" name="tubeace_youporn_api_num_thumbs" id="tubeace_youporn_api_num_thumbs" min="1" max="16" value="<?php echo $tubeace_youporn_api_num_thumbs; ?>" <?php echo $tubeace_youporn_api_num_thumbs_disabled; ?>> <small>max 16</small>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_youporn_api_def_thumb_disabled = null;
		        		if( $tubeace_youporn_api_def_thumb_only == 1 || $tubeace_youporn_api_use_def_thumb == 1){
							$tubeace_youporn_api_def_thumb_disabled = "disabled";
		        		} ?>			        		
		        		<input type="number" name="tubeace_youporn_api_def_thumb" id="tubeace_youporn_api_def_thumb" min="1" max="16" value="<?php echo $tubeace_youporn_api_def_thumb; ?>" <?php echo $tubeace_youporn_api_def_thumb_disabled; ?>>
		        	</td>

		        	<td>
		        		<input type="checkbox" name="tubeace_youporn_api_save_thumbs" value="1" <?php if( $tubeace_youporn_api_save_thumbs == 1 ) echo 'checked'; ?>>
		        	</td> 			        	
	
		        </tr>



		        <tr>
		    		<th><label>xHamster</label></th>
		        	<td>
		        		<select name="tubeace_xhamster_api_thumb_size">
		        			<?php $sel_xhamster_0 = ( $tubeace_xhamster_api_thumb_size == 0 ) ? 'selected="selected"' : ''; ?>
		        			<option value="0" <?php echo $sel_xhamster_0 ?>>160x120</option>
		        			<?php $sel_xhamster_1 = ( $tubeace_xhamster_api_thumb_size ==1  ) ? 'selected="selected"' : ''; ?>
		        			<option value="1" <?php echo $sel_xhamster_1 ?>>180x135</option>
		        			<?php $sel_xhamster_2 = ( $tubeace_xhamster_api_thumb_size == 2 ) ? 'selected="selected"' : ''; ?>
		        			<option value="2" <?php echo $sel_xhamster_2 ?>>200x150</option>
		        			<?php $sel_xhamster_3 = ( $tubeace_xhamster_api_thumb_size == 3 ) ? 'selected="selected"' : ''; ?>
		        			<option value="3" <?php echo $sel_xhamster_3 ?>>240x180</option>
		        			<?php $sel_xhamster_4 = ( $tubeace_xhamster_api_thumb_size == 4 ) ? 'selected="selected"' : ''; ?>
		        			<option value="4" <?php echo $sel_xhamster_4 ?>>320x240</option>	
		        		</select>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_xhamster_api_def_thumb_only_disabled = null;
		        		if( $tubeace_xhamster_api_use_def_thumb == 1 ){
							$tubeace_xhamster_api_def_thumb_only_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_xhamster_api_def_thumb_only" id="tubeace_xhamster_api_def_thumb_only" value="1" <?php if( $tubeace_xhamster_api_def_thumb_only == 1 ) echo 'checked'; ?> <?php echo $tubeace_xhamster_api_def_thumb_only_disabled; ?>>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_xhamster_api_use_def_thumb_disabled = null;
		        		if( $tubeace_xhamster_api_def_thumb_only == 1 ){
							$tubeace_xhamster_api_use_def_thumb_disabled = "disabled";
		        		} ?>		        		
		        		<input type="checkbox" name="tubeace_xhamster_api_use_def_thumb" id="tubeace_xhamster_api_use_def_thumb" value="1" <?php if( $tubeace_xhamster_api_use_def_thumb == 1 ) echo 'checked'; ?> <?php echo $tubeace_xhamster_api_use_def_thumb_disabled; ?>>
		        	</td>			        	    		
		        	<td>
		        		<?php 
		        		$tubeace_xhamster_api_num_thumbs_disabled = null;
		        		if( $tubeace_xhamster_api_def_thumb_only == 1){
							$tubeace_xhamster_api_num_thumbs_disabled = "disabled";
		        		} ?>			        		
		        		<input type="number" name="tubeace_xhamster_api_num_thumbs" id="tubeace_xhamster_api_num_thumbs" min="1" max="10" value="<?php echo $tubeace_xhamster_api_num_thumbs; ?>" <?php echo $tubeace_xhamster_api_num_thumbs_disabled; ?>> <small>max 10</small>
		        	</td>
		        	<td>
		        		<?php 
		        		$tubeace_xhamster_api_def_thumb_disabled = null;
		        		if( $tubeace_xhamster_api_def_thumb_only == 1 || $tubeace_xhamster_api_use_def_thumb == 1){
							$tubeace_xhamster_api_def_thumb_disabled = "disabled";
		        		} ?>			        		
		        		<input type="number" name="tubeace_xhamster_api_def_thumb" id="tubeace_xhamster_api_def_thumb" min="1" max="10" value="<?php echo $tubeace_xhamster_api_def_thumb; ?>" <?php echo $tubeace_xhamster_api_def_thumb_disabled; ?>>
		        	</td>
		        	<td>
		        		<input type="checkbox" name="tubeace_xhamster_api_save_thumbs" value="1" <?php if( $tubeace_xhamster_api_save_thumbs == 1 ) echo 'checked'; ?>>
		        	</td>  	
		        </tr>



		    </tbody>
		</table>


		<h2>Dump File Imports</h2>
		<table class="form-table">
		    <tbody>
		    	<tr>
		    		<td>
		    			
		    		</td>		    	
		    		<td>
		    			# of Thumbnails to Create
		    		</td>
		    		<td>
		    			Default thumbnail # to show in Previews
		    		</td>
		    	</tr>
		        <tr>
		    		<th><label>DrTuber</label></th>
		        	<td>
		        		<input type="number" name="tubeace_drtuber_dump_num_thumbs" min="1" max="20" value="<?php echo $tubeace_drtuber_dump_num_thumbs; ?>"> max 20
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_drtuber_dump_def_thumb" min="1" max="20" value="<?php echo $tubeace_drtuber_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>KeezMovies</label></th>
		        	<td>
		        		<input type="number" name="tubeace_keezmovies_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_keezmovies_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_keezmovies_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_keezmovies_dump_def_thumb; ?>">
		        	</td>
		        </tr>				        
		        <tr>
		    		<th><label>Pornhub</label></th>
		        	<td>
		        		<input type="number" name="tubeace_pornhub_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_pornhub_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_pornhub_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_pornhub_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>PornTube</label></th>
		        	<td>
		        		<input type="number" name="tubeace_porntube_dump_num_thumbs" min="1" max="10" value="<?php echo $tubeace_porntube_dump_num_thumbs; ?>"> max 10
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_porntube_dump_def_thumb" min="1" max="10" value="<?php echo $tubeace_porntube_dump_def_thumb; ?>">
		        	</td>
		        </tr>		        
		        <tr>
		    		<th><label>RedTube</label></th>
		        	<td>
		        		<input type="number" name="tubeace_redtube_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_redtube_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_redtube_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_redtube_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>Spankwire</label></th>
		        	<td>
		        		<input type="number" name="tubeace_spankwire_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_spankwire_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_spankwire_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_spankwire_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>Sun Porno</label></th>
		        	<td>
		        		<input type="number" name="tubeace_sunporno_dump_num_thumbs" min="1" max="1" value="<?php echo $tubeace_sunporno_dump_num_thumbs; ?>"> max 1
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_sunporno_dump_def_thumb" min="1" max="1" value="<?php echo $tubeace_sunporno_dump_def_thumb; ?>">
		        	</td>
		        </tr>		        
		        <tr>
		    		<th><label>Tube8</label></th>
		        	<td>
		        		<input type="number" name="tubeace_tube8_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_tube8_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_tube8_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_tube8_dump_def_thumb; ?>">
		        	</td>
		        </tr>		        
		        <tr>
		    		<th><label>xHamster</label></th>
		        	<td>
		        		<input type="number" name="tubeace_xhamster_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_xhamster_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_xhamster_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_xhamster_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>XTube</label></th>
		        	<td>
		        		<input type="number" name="tubeace_xtube_dump_num_thumbs" min="1" max="15" value="<?php echo $tubeace_xtube_dump_num_thumbs; ?>"> max 15
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_xtube_dump_def_thumb" min="1" max="15" value="<?php echo $tubeace_xtube_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>XVIDEOS</label></th>
		        	<td>
		        		<input type="number" name="tubeace_xvideos_dump_num_thumbs" min="1" max="1" value="<?php echo $tubeace_xvideos_dump_num_thumbs; ?>"> max 1
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_xvideos_dump_def_thumb" min="1" max="1" value="<?php echo $tubeace_xvideos_dump_def_thumb; ?>">
		        	</td>
		        </tr>
		        <tr>
		    		<th><label>YouPorn</label></th>
		        	<td>
		        		<input type="number" name="tubeace_youporn_dump_num_thumbs" min="1" max="16" value="<?php echo $tubeace_youporn_dump_num_thumbs; ?>"> max 16
		        	</td>
		        	<td>
		        		<input type="number" name="tubeace_youporn_dump_def_thumb" min="1" max="16" value="<?php echo $tubeace_youporn_dump_def_thumb; ?>">
		        	</td>
		        </tr>

		    </tbody>
		</table>


		<h2>Mass Import Tool</h2>
		<table class="form-table">
		    <tbody>
		        <tr>
		    		<th><label for="">Save Thumbnails to Server</label></th>
		        	<td>
		        		<input type="checkbox" name="tubeace_mass_import_save_thumbs" value="1" <?php if( $tubeace_mass_import_save_thumbs == 1 ) echo 'checked'; ?>>
		        		<small>(Leaving Unchecked will Serve Thumbnails from Source/CDN)</small>
		        	</td>		        	
		        </tr>	
		    </tbody>
		</table>


		<input type="submit" value="Save Changes" class="button-primary" name="Submit">



		<table class="form-table">
		    <tbody>

		        <tr>
		    		<th><label for="">Import all videos as Video Post Format</label></th>
		        	<td>
		        		<input type="checkbox" name="tubeace_import_as_video_post_format" value="1" <?php if( $tubeace_import_as_video_post_format == 1 ) echo 'checked'; ?>>
		        		<small><a href="https://codex.wordpress.org/Post_Formats" target="_blank">See Post Format Documentation</a></small>
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="">AJAX Importing</label></th>
		        	<td>
		        		<input type="checkbox" name="tubeace_ajax_import" value="1" <?php if( $tubeace_ajax_import == 1 ) echo 'checked'; ?>>
		        		<small>Slower process, but may be needed on shared web servers to display video import reporting output.</small>
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="tubeace_words_filter">Word Filter</label></th>
		        	<td>
		        		<textarea name="tubeace_words_filter" rows="4" style="width:600px"><?php echo $tubeace_words_filter;  ?></textarea>
		        		<br><small>Enter words separated by comma to exclude videos containing specified word(s) within titles, tags, categories on import.</small>
		        	</td>		        	
		        </tr>	

		        <tr>
		    		<th><label for="tubeace_filter_video_position">Video Player Position</label></th>
		        	<td>
				        <select name="tubeace_filter_video_position" id="tubeace_filter_video_position">
					        <?php

					        if( $tubeace_filter_video_position=="above" ){
					        	echo"<option value=\"above\" selected>Above Content</option>";	
					    	}
					        if( $tubeace_filter_video_position=="below" ){
					        	echo"<option value=\"below\" selected>Below Content</option>";	
					    	}				    	
					    	?>
							<option value="above">Above Content</option>      
							<option value="below">Below Content</option>      
				      	</select>
		        	</td>		        	
		        </tr>

		        <tr>
		    		<th><label for="tubeace_default_video_player">Default Video Player</label></th>
		        	<td>
				        <select name="tubeace_default_video_player" id="tubeace_default_video_player">
					        <?php

					        if( $tubeace_default_video_player=="flowplayer7" ){
					        	echo"<option value=\"flowplayer7\" selected>Flowplayer 7</option>";	
					    	}
					        if( $tubeace_default_video_player=="videojs" ){
					        	echo"<option value=\"videojs\" selected>Video.js</option>";	
					    	}				    	
					    	?>
							<option value="flowplayer7">Flowplayer 7</option>      
							<option value="videojs">Video.js</option>      
				      	</select>
		        	</td>		        	
		        </tr>


		        <tr>
		    		<th><label for="tubeace_flowplayer7_code">Flowplayer 7 Code</label></th>
		        	<td>
		        		<textarea name="tubeace_flowplayer7_code" rows="4" style="width:600px"><?php echo $tubeace_flowplayer7_code;  ?></textarea>
		        	</td>		        	
		        </tr>		

		        <tr>
		    		<th><label for="tubeace_videojs_code">Video.js Code</label></th>
		        	<td>
		        		<textarea name="tubeace_videojs_code" rows="4" style="width:600px"><?php echo $tubeace_videojs_code;  ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="tubeace_video_player_wrapper_css">Video Player Wrapper CSS</label></th>
		        	<td>
		        		<textarea name="tubeace_video_player_wrapper_css" rows="12" style="width:600px"><?php echo $tubeace_video_player_wrapper_css ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="video_player_code">RedTube Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_redtube_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_redtube_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="video_player_code">DrTuber Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_drtuber_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_drtuber_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="video_player_code">KeezMovies Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_keezmovies_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_keezmovies_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>		        
		        <tr>
		    		<th><label for="video_player_code">PornTube Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_porntube_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_porntube_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="video_player_code">Pornhub Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_pornhub_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_pornhub_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="video_player_code">SpankWire Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_spankwire_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_spankwire_video_player_code ?></textarea>
		        	</td>
		        </tr>
		        <tr>
		    		<th><label for="tubeace_sunporno_video_player_code">Sun Porno Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_sunporno_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_sunporno_video_player_code ?></textarea>
		        	</td>
		        </tr>	
		        <tr>
		    		<th><label for="video_player_code">Tube8 Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_tube8_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_tube8_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>		        	             
		        <tr>
		    		<th><label for="video_player_code">xHamster Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_xhamster_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_xhamster_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="video_player_code">XTube Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_xtube_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_xtube_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>		        
		        <tr>
		    		<th><label for="video_player_code">XVIDEOS Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_xvideos_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_xvideos_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>		        
		        <tr>
		    		<th><label for="video_player_code">YouPorn Video Player Code</label></th>
		        	<td>
		        		<textarea name="tubeace_youporn_video_player_code" rows="3" style="width:600px"><?php echo $tubeace_youporn_video_player_code ?></textarea>
		        	</td>		        	
		        </tr>
		        <tr>
		    		<th><label for="file">Saved Thumbnail Dimensions</label></th>
		        	<td>
						Width <input type="text" value="<?php echo $tubeace_thumb_width ?>" name="tubeace_thumb_width" class="small-text">
						Height <input type="text" value="<?php echo $tubeace_thumb_height ?>" name="tubeace_thumb_height" class="small-text">
		        	</td>		        	
		        </tr>	
		        <tr>
		    		<th><label for="file">Auto-Scheduling on Imported Videos</label></th>
		        	<td>
						Max videos per day <input type="text" value="<?php echo $tubeace_schedule_per_day ?>" name="tubeace_schedule_per_day" class="small-text"> (Set value to 0 to disable Auto-Scheduling.)
		        	</td>		        	
		        </tr>

		        <tr>
		    		<th><label for="tubeace_split_description_characters">Split Video Descriptions w/ 'Read More' Button</label></th>
		        	<td>
						Split video descritions after <input type="text" value="<?php echo $tubeace_split_description_characters ?>" name="tubeace_split_description_characters" class="small-text"> characters
		        	</td>		        	
		        </tr>		        

		        <tr>
		    		<th><label for="">Set Last Page Completed as new Start Page for Cron Imports</label></th>
		        	<td>
		        		<input type="checkbox" name="tubeace_cron_set_last_page_as_start" value="1" <?php if( $tubeace_cron_set_last_page_as_start == 1 ) echo 'checked'; ?>>
		        	</td>		        	
		        </tr>

		        <tr>
		    		<th><label for="file">Email Cron Output To</label></th>
		        	<td>
						<input class="tubeace-input-320" type="text" value="<?php echo $tubeace_cron_email ?>" name="tubeace_cron_email">
		        	</td>		        	
		        </tr>

		        <tr>
		    		<th><label for="">Link Thumbnail To Source Page URL</label></th>
		        	<td>
		        		<input type="checkbox" name="tubeace_link_thumb_to_source" value="1" <?php if( $tubeace_link_thumb_to_source == 1 ) echo 'checked'; ?>> Available for API Imports Only
		        	</td>		        	
		        </tr>

		        <tr>
		    		<th><label for="file">Alternate Video URL</label></th>
		        	<td>
						<input class="tubeace-input-320" type="text" value="<?php echo $tubeace_alternate_video_url ?>" name="tubeace_alternate_video_url">
						<br />Use {video_page_url} macro for original Video Page URL. Example: http://www.yoursite.com/out.php?{video_page_url}
		        	</td>		        	
		        </tr>		        
		    </tbody>
		</table>
		<input type="submit" value="Save Changes" class="button-primary" name="Submit">
	</form>

  <h2><?php _e('Reset Tube Ace Shortcode Customizations','tubeace') ?></h2>

  <div class="tubeace-customizations-group">
    <div class="tubeace-customizations-description">
      <?php _e('Restore all Tube Ace Plugin Shortcode Customization settings to their default settings. These settings can be found in Appearance > Customize > Tube Ace Post Preview Options','tubeace') ?><br>
    </div>
    <div class="tubeace-customizations-button">
      <form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-settings.php') ?>" method="post">
        <input type="submit" value="<?php _e('Reset Customizations','tubeace'); ?>" class="button-primary" name="ResetCustomizations">
      </form>      
    </div>
  </div>


</div>