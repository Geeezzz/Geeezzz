<?php tubeace_header(1); 

tubeace_license_status_message('mass_import');
?>

<div class="wrap">
  <h2>Import Videos <span style="float:right"><small><small><span class="dashicons dashicons-paperclip"></span><a href="https://tubeace.com/docs/mass-import-videos/" target="_blank">Documentation</a></small></small></span></h2>

<?php

$error = $error2 = false;
$post_category = null;

// step 3 start import
if( isset($_REQUEST['Submit2']) ){

	// hidden values
	$status = $_GET['status'];
	$delimiter = $_GET['delimiter'];
	$field = $_GET['field'];
	$data_format = $_GET['data_format'];
	$sponsor = $_GET['sponsor'];
	$post_category = (isset($_GET['post_category'])) ? $_GET['post_category'] : null;
	$block_dups = $_GET['block_dups'];

	// error checking
	if($data_format=="custom"){

		$errs = null;
	
		// make sure one field selected as title
		if ( !in_array("title", $field) && empty($_GET['setall_title']) ) {
			$errs.= '<div class="error"><p><b>Select a field as \'title\' or enter a set to all value for title.</b></p></div>';
			$error2=1;
		}
	
		// make sure one field selected as thumb_url
		if ( !in_array("thumb_url", $field) ) {
			$errs.= '<div class="error"><p><b>Select a field as \'thumb_url\'.</b></p></div>';
			$error2=1;
		}
	
		// make sure one field selected as video_url
		if ( !in_array("video_url", $field) && !in_array("embed_code", $field) ) {
			$errs.= '<div class="error"><p><b>Select a field as \'video_url\' or \'embed_code\'.</b></p></div>';
			$error2=1;
		}

		// make sure no fields selected twice
		//create $err_vals to prevent double reporting
		$existing_vals = array();
		$field2 = $field;

		foreach($field2 as $key => $val){

			if( isset( $field2[$key] ) ){

				if( $val!="none" && in_array($val, $existing_vals) ){
					$errs.= '<div class="error"><p><b>\''.$val.'\' selected more than once. Each field may only be selected once.</b></p></div>';
					$error2=1;
				}

				$existing_vals[] = $val;

			}
		}
	}

	if(!$error2){
		
		if( get_site_option( 'tubeace_ajax_import' ) == 1 ) {
			require_once 'inc/mass-import/mass-import-ajax.php';
		} else {
			require_once 'inc/mass-import/mass-import.php';
		}
	}
}

//step 2 - select fields
if(isset($_REQUEST['Submit']) || $error2){

	$status = (isset($_POST['status'])) ? $_POST['status'] : null;
	$sponsor = (isset($_POST['sponsor'])) ? $_POST['sponsor'] : null;
	$paste_data = (isset($_POST['paste_data'])) ? $_POST['paste_data'] : null;
	$post_category = (isset($_POST['post_category'])) ? $_POST['post_category'] : null;
	$delimiter = (isset($_POST['delimiter'])) ? $_POST['delimiter'] : null;
	$block_dups = (isset($_POST['block_dups'])) ? $_POST['block_dups'] : null;

	$tmpName = (isset($_FILES['uploaded']['tmp_name'])) ? $_FILES['uploaded']['tmp_name'] : null;
	$fileSize = (isset($_FILES['uploaded']['size'])) ? $_FILES['uploaded']['size'] : null;

	$import_file_url = (isset($_POST['import_file_url'])) ? $_POST['import_file_url'] : null;
	$paste_data = (isset($_POST['paste_data'])) ? $_POST['paste_data'] : null;

	//check for import file
	if( isset($_REQUEST['Submit']) && empty($tmpName) && empty($paste_data) && empty($import_file_url) ){
		$errs.= '<div class="error"><p><b>An import file source must be given.</b></p></div>';
		$error = 1;
	}

	// make path name
	$upload_dir = wp_upload_dir();
	$import_filename = $upload_dir['basedir'].'/tubeace-import.txt';	

	// file uploaded
	if(!empty($tmpName)){

		// copy to server
		copy($tmpName, $import_filename);

		$content = file_get_contents($tmpName);
	}

	// import file url
	if(!empty($import_file_url)){

		$content = file_get_contents($import_file_url);

		// Open file to write
		$fp = fopen($import_filename, 'w+');
		fwrite($fp, $content);
		fclose($fp);	
	}

	// data pasted
	if(!empty($paste_data)){
			
		$content = $paste_data;
		$content = stripslashes($content);

		// Open file to write
		$fp = fopen($import_filename, 'w+');
		fwrite($fp, $content);
		fclose($fp);

		// use htmlentities since browser may not display embed code for XSS protection
		$content = htmlentities($content);	
	}

	if(!$error){
			
		//check for errors resulted from attemping to advance to next page
		if($error2){

			echo $errs;
			
			//retrieve $content from saved file again
			$fp = fopen($import_filename, 'r');
			$content = fread($fp, filesize($import_filename));
			fclose($fp);

			$delimiter =  $_GET['delimiter'];
		}
		
		if( $delimiter == 'detect' ){
			$delimiter = tubeace_detect_delimiter($import_filename);	
			echo 'Detected delimiter: '.$delimiter;
		} else {

			if($delimiter=="tab"){
				$delimiter = "\t";
			} else if($delimiter=="comma"){
				$delimiter = ",";
			} else if($delimiter=="semicolon"){
				$delimiter = ";";
			} else if($delimiter=="pipe"){
				$delimiter = "|";
			}

			echo 'Delimiter: '.$delimiter;			
		}

		$data_format = 'custom';

		echo'<form action="'.admin_url('admin.php?page=tubeace/tubeace-import.php').'" method="get">';
		
		$field_array = array('video_url','thumb_url','embed_code','title','duration','description','tags','performers','site','sponsor_link_url','sponsor_link_txt','misc1','misc2','misc3','misc4','misc5');				
		
		if($data_format=='custom'){
			
			echo'Match the fields in each drop-down menu with the correct data values.';
			
			echo'
			<table class="tubeace-vertical-form" width="100%" border="0" cellspacing="0" cellpadding="2">
			<tr><th>Select Field</th><th>Value</th></tr>';

			$second_line = explode("\n", $content);			
			$second_line_fields = explode($delimiter, $second_line[1]);

			// match field with comma
			$second_line_fields = preg_grep("/(,|;)/", $second_line_fields);

			//remove thumbs
			function tubeace_array_filter_thumbs($string) {
			  return strpos($string, '.jpg') === false;
			}
			$second_line_fields = array_filter($second_line_fields, 'tubeace_array_filter_thumbs');

			    // reset keys starting at 0
			    array_multisort($second_line_fields, SORT_NATURAL | SORT_FLAG_CASE);

			// if 2 results likely tags and channels
			if ( count( $second_line_fields ) == 2 ) {

				// strip commas to use ctype_lower to detect tags
			    $second_line_fields2 = str_replace(';', '', $second_line_fields);
			    $second_line_fields2 = str_replace(',', '', $second_line_fields);

			    //if match 1 is lowercase
			    //if (ctype_lower($matches2[$key])) {
			    if (ctype_lower($second_line_fields2[1])) {

			        $predicted_tags = $second_line_fields[1];
			        $predicted_categories = $second_line_fields[0];
			    } else {

			        $predicted_tags = $second_line_fields[0];
			        $predicted_categories = $second_line_fields[1];
			    }
			  
			}

			// 1 result likely tags
			if ( count( $second_line_fields ) == 1 ) {

			    $predicted_tags = $second_line_fields[0];
			}

			$rowcount = 1;
			$i = 0;
			$lines = explode("\n", $content);
			$line = $lines[0];

			foreach($fields = explode($delimiter, $line) as $key => $val) {

				if( !empty($val) ){

					$val = tubeace_prepare_csv_data($val);

					echo'<tr class="tubeace-tr'.$rowcount.'">';
					echo'<td>';
					echo'<select name="field['.$i.']" id="field['.$i.']">';
					echo'<option value="none">-none-</option>';
					
					//show field values in drop-downs
					foreach($field_array as $value){
						
						//from previous post
						if($field[$i]==$value){
							$sel_field = 'selected="selected"';
						}

						// predict 
						// duration - if is numeric and less than an hour (attempt to ignore large id numbers)
						if( ctype_digit($val) && $value=='duration' && $val<=3600 && empty($duration_set) ){
							$sel_field = 'selected="selected"';
							$duration_set = 1;
						}

						// duration matches 1m2s format
						preg_match('/((\d+)h)?(\d+)m(\d+)s/', $val, $matches);

						if( !empty($matches) && $value=='duration' && empty($duration_set) ){
							$sel_field = 'selected="selected"';
							$duration_set = 1;
						}

						// duration matches 00:00:00 format
						preg_match("/((\d?\d):)?(\d?\d):(\d?\d)$/", $val, $matches);		

						if( !empty($matches) && $value=='duration' && empty($duration_set)){
							$sel_field = 'selected="selected"';
						}									

						// duration - if labled first line of file
						if(  stripos($val, 'duration') !== FALSE && $value=='duration' ){
							$sel_field = 'selected="selected"';
						}

						// video_url - if ends in mp4 or flv
						if( (  stripos($val, 'mp4') !== FALSE || stripos($val, 'flv') !== FALSE) && $value=='video_url' ){
							$sel_field = 'selected="selected"';
						}

						// embed_code - if contains iframe or embed
						if( (  stripos($val, 'iframe') !== FALSE || stripos($val, 'embed') !== FALSE) && $value=='embed_code' ){
							$sel_field = 'selected="selected"';
						}

						// thumb_url - if ends in jpg or jpeg
						if( (  stripos($val, 'jpg') !== FALSE || stripos($val, 'jpeg') || stripos($val, 'thumb') !== FALSE) && $value=='thumb_url' && empty($thumb_url_set) ){
							$sel_field = 'selected="selected"';
							$thumb_url_set = 1;
						}

						// title - if contains spaces (multiple words) and no commas or semicolons
						if( (  strpos($val, ' ') !== FALSE && strpos($val, ',') === FALSE && strpos($val, ';') === FALSE && stripos($val, 'iframe') === FALSE && strpos($val, 'embed') === FALSE ) && $value=='title' && empty($title_set) ){
							$sel_field = 'selected="selected"';
							$title_set = 1;
						}

						// title - if labled first line of file
						if(  stripos($val, 'title') !== FALSE && $value=='title' ){
							$sel_field = 'selected="selected"';
						}						

						// tags - does contain commas or semi-colons
						// all lowercase
						if( $val==$predicted_tags && $value=='tags' && empty($tags_set) ){
							$sel_field = 'selected="selected"';
							$tags_set = 1;
						}

						// tags - if labled first line of file
						if(  ( stripos($val, 'tag') !== FALSE || stripos($val, 'channel') !== FALSE ) && $value=='tags' ){
							$sel_field = 'selected="selected"';
						}							

						// performers - if labled first line of file
						if(  ( stripos($val, 'performer') !== FALSE || stripos($val, 'pornstar') !== FALSE ) && $value=='performers' ){
							$sel_field = 'selected="selected"';
						}	

						// display option values - use conditionals to determine which to show
						echo '<option value="'.$value.'"'.$sel_field.'>'.$value.'</option>';

						unset($sel_field);
					}
					$rowcount++;
					if($rowcount==3){
						$rowcount = 1;
					}	
				}   
			
				echo'</select>';
				echo'</td>';
				
				echo'<td>'.$val.'</td>';
				echo'</tr>';
			
			$i++;   
			}
			
			echo'</table>';
			
		}
		
		//Set All's 
		echo'Below you can set the same values to a field for all videos you are about to import.';
		echo'<table class="tubeace-vertical-form" width="100%" border="0" cellspacing="0" cellpadding="2">';
		echo'<tr><th class="right"></th><th class="left">Set all fields to this value or leave blank to use value from import file.</th></tr>';
	
		$setall_array = array('post_date' => '160', 'duration' => '60','title' => '320t','description' => '320','tags' => '320','performers' => '320','site' => '160',
							  'sponsor_link_url' => '320t','sponsor_link_txt' => '320t','misc1' => '320','misc2' => '320','misc3' => '320','misc4' => '320',
							  'misc5' => '320');
		$rowcount = 1;		
		
		foreach($setall_array as  $fieldName => $class){

			$fill_val = null;
			if($fieldName=="sponsor_link_txt"){
				$fill_val = "Click Here for Full Video";
			} 
			
			if($fieldName=="post_date"){
				$fill_val = date("Y-m-d H:i:s");
			} 		
		
			echo'<tr class="tubeace-tr'.$rowcount.'"><td class="right"><b>'.$fieldName.'</b></td><td class="left">';
			
			if($class=="60" || $class=="160" || $class=="320t"){
				
				//strip t from 320 text type field
				$class=str_replace('t','',$class);
				
				echo'<input type="text" class="tubeace-input-'.$class.'" name="setall_'.$fieldName.'" value="'.$fill_val.'">';
			} else {
				echo'<textarea class="tubeace-input-'.$class.'" name="setall_'.$fieldName.'">'.$fill_val.'</textarea>';
			}
			
			if($fieldName=="duration"){
				echo'(in seconds)';
			}

			if($fieldName=="tags" || $fieldName=="performers"){
				echo'(separate by comma)';
			}
			echo'</td></tr>';
			$rowcount++;
			if($rowcount==3){
				$rowcount = 1;
			}	
		} 
		echo'</table>';
		
		echo'<input name="status" type="hidden" value="'.$status.'">';
		echo'<input name="delimiter" type="hidden" value="'.$delimiter.'">';
		echo'<input name="paste_data" type="hidden" value="'.urlencode($paste_data).'">';
		echo'<input name="data_format" type="hidden" value="'.$data_format.'">';
		echo'<input name="sponsor" type="hidden" value="'.$sponsor.'">';

		if(!empty($post_category)){
			foreach($post_category as $value){
				echo '<input type="hidden" name="post_category[]" value="'. $value. '">';
			}
		}

		echo'<input name="block_dups" type="hidden" value="'.$block_dups.'">';

		echo'<input type="hidden" name="page" value="tubeace/tubeace-import.php">';

		echo'<input class="button-primary" name="Submit2" type="submit" value="Import File">';
		echo'</form>';
	}
}

//step 1 - set options and enter import data
// The JavaScript
function tubeace_mass_import_select_file_javascript() {
  //Set Your Nonce
  $ajax_nonce = wp_create_nonce( 'my-special-string' );
  ?>
  <script>

	jQuery(document).ready(function ($) {

		// upload form
		$( "#file" ).change(function() {

		  $( "#pre-import-instruct" ).hide();

		  $( "#pre-import-info" ).fadeIn( "slow", function() {
		    // Animation complete
		  });
		});

		// file URL / Paste Data
		$( "#import_file_url, #paste_data" ).keyup(function() {

		  $( "#pre-import-instruct" ).hide();

		  $( "#pre-import-info" ).fadeIn( "slow", function() {
		    // Animation complete
		  });
		});
	});

  </script>
  <?php
}
add_action( 'admin_footer', 'tubeace_mass_import_select_file_javascript' );	


if (!isset($_REQUEST['Submit']) && !isset($_REQUEST['Submit2']) || $error) { 

	if($error){
		echo $errs;
	} ?>

	<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-import.php'); ?>" method="post" enctype="multipart/form-data">

	  <span id="pre-import-instruct">Enter one of the following import sources: Import File, Import File URL or Paste Import File Data</span>

	  <table id="tubeace-import-file-source" class="form-table">
	    <tbody>
		  <tr>
        	<th><label for="file">Import File</label></th>
        	<td>
			  <input type="file" name="uploaded" id="file"><br />		
        	</td>
		  </tr>
		  <tr class="tubeace-import-file-source-or-row">
		  	<th></th>
		    <td>OR</td>
		  </tr>				  
		  <tr>
        	<th><label for="import_file_url">Import File URL</label></th>
        	<td>			
			  <input type="text" name="import_file_url" id="import_file_url" class="tubeace-input-400" placeholder="http://"> 	
        	</td>
		  </tr>
		  <tr class="tubeace-import-file-source-or-row">
		  	<th></th>
		    <td>OR</td>
		  </tr>			  
		  <tr>
            <th><label for="paste_data">Paste Import File Data</label></th>
        	<td>			
			  <textarea name="paste_data" id="paste_data" rows="20" style="width:90%"></textarea>	  	
        	</td>
		  </tr>	  
		</tbody>
	  </table>

	  <table id="tubeace-pre-import-info" class="form-table" style="displayX: none;">
	    <tbody>
		  <tr>
			<th><label for="status">Status</label></th>
			<td>
			  <select name="status" id="status">
				<option value="publish">Publish</option>
			 	<option value="pending">Pending</option>
			 	<option value="draft">Draft</option>
			 	<option value="future">Future</option>
			 	<option value="private">Private</option>
			  </select>
			</td>
		  </tr>	  
		  <tr>
			<th><label for="sponsor">Author / Sponsor</label></th>
			<td>
			  <select name="sponsor" id="sponsor">
				<?php tubeace_get_users_with_role(array('Contributor','Administrator'),0); ?>
			  </select>
			  <small>To add a sponsor, <a href="user-new.php">add a new user</a> with a "Contributor" Role.</small>
			</td>
		  </tr>
		  <tr>
			<th><label for="categorychecklist">Category</label></th>
			<td><ul id="categorychecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
			  <?php wp_category_checklist( 0,0,$post_category ); ?></ul> 
			</td>
		  </tr>
		  <tr>
			<th><label for="file">Field Separator (delimiter)</label></th>
			<td>
			  <select name="delimiter" name="delimiter">
				<option value="detect" selected="selected">Auto detect</option>
				<option value="pipe">Pipe |</option>
				<option value="comma" >Comma ,</option>
				<option value="tab" >Tab</option>
				<option value="semicolon" >Semicolon ;</option>
			  </select>
			</td>
		  </tr>				  
		  <tr>
			<th><label for="block_dups">Block Duplicates</label></th>
			<td>
			  <input name="block_dups" type="checkbox" class="checkbox" id="block_dups" value="1" checked/> 
			</td>
		  </tr>
		  <tr>
		  	<th></th>
		    <td><input type="submit" value="Next Step" class="button-primary" name="Submit"></td>
		  </tr>
		</tbody>
	  </table>
	</form>
	
	<?php
	}
	?>
</div>