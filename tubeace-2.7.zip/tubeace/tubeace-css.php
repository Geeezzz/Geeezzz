<?php

// We'll be outputting CSS
header('Content-type: text/css');

require_once('../../../wp-config.php'); 
include_once('../../../wp-includes/option.php');
echo $custom_css = get_site_option( 'tubeace_video_player_wrapper_css' );

?>

#tubeace-more-description-txt {display: none;}