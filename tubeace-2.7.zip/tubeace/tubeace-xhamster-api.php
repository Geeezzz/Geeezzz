<?php
set_time_limit(0);

tubeace_header(1);

tubeace_license_status_message('xhamster_api');

$siteArray = tubeace_api_site_array('xhamster');
      	
require_once 'inc/apis/api-import-form.php'; 
  // -> api-import-form-xhamster.php

require_once 'inc/apis/api-import.php';
  // -> api-import-ajax.php
  // -> api-import-process.php

require_once 'inc/apis/api-import-cron.php';
