<?php
set_time_limit(0);

tubeace_header(1);

?>
<h1>Quality Control</h1>
<?php
set_time_limit(0);

?>

<div class="wrap">
	<h3>Delete Videos with Missing Thumbnails</h3>
	<p>

	<?php

	if(!empty($_POST['check_thumbs'])) {

		// The JavaScript
		function tubeace_dump_import_javascript() {
		  //Set Your Nonce
		  $ajax_nonce = wp_create_nonce( 'my-special-string' );
		  ?>
		  <script>

		  jQuery( document ).ready( function( $ ) {

		  	var page = 1;

		  	process(page);

		  	function process(page){

			    var data = {
			      action: 'tubeace_missing_thumbnails',
			      security: '<?php echo $ajax_nonce; ?>',
			      page: page

			    };

			    $.post( ajaxurl, data, function( response)  {

					jQuery('#response').append(response.report);

					if(response.done==1){
						jQuery('#tubeace-loading').remove();
						return;
						
					} else {

						//increment
						page = page+1;
						
						process(page);
					}
			    });
			}
		  });

		  </script>
		  <?php
		}
		add_action( 'admin_footer', 'tubeace_dump_import_javascript' );	

		echo'

		  <input type="hidden" id="status" value="">

		  <div id="response"></div>
		  <img id="tubeace-loading" src="'.plugins_url("tubeace/images/loading.gif").'">';

	} else {

?>
	<form action="<?php echo admin_url('admin.php?page=tubeace/tubeace-quality-control.php'); ?>" method="post">

		<input type="submit" value="Check Video Thumbnails" class="button-primary" name="check_thumbs">
	</form>

<?php
}
?>
	</p>
</div>